<?php
error_reporting(0);
set_time_limit(0);

require_once 'config.php';

$domain = 'http://localhost';

if (php_sapi_name() != 'cli') {
    
    if (isset($_SERVER['HTTP_HOST']) && !empty($_SERVER['HTTP_HOST'])) {
        $domain = 'http://' . $_SERVER['HTTP_HOST'];
    }
} else {
    
    if (isset($userSetHost) && !empty($userSetHost)) {
        $domain = 'http://' . $userSetHost;
    }
}

$basePath = '/'; 

// If the script is not running in CLI mode, set the base path
if (php_sapi_name() != 'cli') {
    $basePath = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/') . '/';
}

$proxyUrl = $domain . $basePath . "hls_proxy.php";

function fetchContent($url, $additionalHeaders = []) {

$decodedData = base64_decode($_GET['data']);
$parts = explode('|', $decodedData);

	$httpOptions = [
		'http' => [
			'method' => 'GET',
			'follow_location' => 1,
			'max_redirects' => 5,
			'header' => []
		]
	];

	foreach ($parts as $headerData) {
		// Find the position of the first '=' character
		$equalPos = strpos($headerData, '=');
		if ($equalPos !== false) {
			// Extract the header name and value
			$header = substr($headerData, 0, $equalPos);
			$value = substr($headerData, $equalPos + 1);

			// Remove single or double quotes from the value
			$value = trim($value, "'\"");

			// Add the header to the options
			$httpOptions['http']['header'][] = "$header: $value";
		}
	}

    if (isset($_SERVER['HTTP_RANGE'])) {
        $httpOptions['http']['header'][] = "Range: " . $_SERVER['HTTP_RANGE'];
    }

    $context = stream_context_create($httpOptions);

    $headers = get_headers($url, 1, $context);

     header($headers[0]);
    if (isset($headers['Content-Type'])) {
        header('Content-Type: ' . $headers['Content-Type']);
    }
	
    /*if (isset($headers['Content-Length'])) {
        header('Content-Length: ' . $headers['Content-Length']);
    }
    if (isset($headers['Accept-Ranges'])) {
        header('Accept-Ranges: ' . $headers['Accept-Ranges']);
    }
    if (isset($headers['Content-Range'])) {
        header('Content-Range: ' . $headers['Content-Range']);
    }

    if ($_SERVER['REQUEST_METHOD'] == 'HEAD') {
        exit;
    } */
	
	$context = stream_context_create($httpOptions);
	
    // Fetch the content from the URL using the context
    return file_get_contents($url, false, $context);
	
}

function isMasterRequest($queryParams) {
   
    return isset($queryParams['url']) && !isset($queryParams['url2']);
}

function rewriteUrls($content, $baseUrl, $proxyUrl, $data, $domain) {
    $lines = explode("\n", $content);
    $rewrittenLines = [];
    $isNextLineUri = false; // Flag for lines following #EXT-X-STREAM-INF

    foreach ($lines as $line) {
        // Add HLS tags and empty lines directly
        if (empty(trim($line)) || $line[0] === '#') {
            // Check for URI within HLS tags
            if (preg_match('/URI="([^"]+)"/i', $line, $matches)) {
                $uri = $matches[1];
                if (strpos($uri, $domain) === false) {
                    $rewrittenUri = $proxyUrl . '?url=' . urlencode($uri) . '&data=' . urlencode($data);
                    $line = str_replace($uri, $rewrittenUri, $line);
                }
            }
            $rewrittenLines[] = $line;

            if (strpos($line, '#EXT-X-STREAM-INF') !== false) {
                $isNextLineUri = true; // The next line is expected to be a URI for a nested playlist
            }
            continue;
        }

        // Decide whether to use 'url' or 'url2' based on the context
        $urlParam = $isNextLineUri ? 'url' : 'url2';

        // Construct absolute URL from base URL and relative path if needed
        if (!filter_var($line, FILTER_VALIDATE_URL)) {
            $line = rtrim($baseUrl, '/') . '/' . ltrim($line, '/');
        }

        // Rewrite the URL to go through the proxy if it doesn't contain the domain
        if (strpos($line, $domain) === false) {
            $rewrittenLines[] = $proxyUrl . "?$urlParam=" . urlencode($line) . '&data=' . urlencode($data);
        } else {
            // Add the line as is if it contains the domain
            $rewrittenLines[] = $line;
        }

        $isNextLineUri = false;
    }

    return implode("\n", $rewrittenLines);
}

$isMaster = isMasterRequest($_GET);

$data = $_GET['data'] ?? '';

$requestUrl = $isMaster ? ($_GET['url'] ?? '') : ($_GET['url2'] ?? '');
$content = fetchContent($requestUrl, $data);
$baseUrl = dirname($requestUrl);

if ($isMaster) {
    $content = rewriteUrls($content, $baseUrl, $proxyUrl, $data, $domain);
}

echo $content;



?>
