<?php
function getDaddyLiveSource($url){
   $url = str_replace(["/cast/", "/stream/"], "/embed/", $url);

   // Create cURL session
   $ch = curl_init($url);

   // Set cURL options for headers
   $headers = [
       'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0',
       'Referer: https://dlhd.sx/'
   ];

   curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // Return the response as a string
   curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Follow redirects

   // Execute the cURL request
   $response = curl_exec($ch);

   preg_match('/<iframe src="([^"]+)"/', $response, $matches);
   if (!isset($matches[1])) {
       echo "Src attribute not found in the iframe tag.";
       exit();
   }

   $iframe_src = $matches[1];
   // Extract the host for the Referer
   $parsed_host = parse_url($iframe_src, PHP_URL_SCHEME) . '://' . parse_url($iframe_src, PHP_URL_HOST) . '/';

   // Create cURL session
   $ch = curl_init($iframe_src);

   // Set cURL options for headers
   $headers = [
       'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0',
       'Referer: https://dlhd.sx/'
   ];

   curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // Return the response as a string
   curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Follow redirects

   // Execute the cURL request
   $response2 = curl_exec($ch);

   preg_match('/(?<=source:\').*?\.m3u8(?=\')/', $response2, $matches);

   if (!isset($matches[0])) {
       echo "Couldn't find the m3u8 link.";
       exit();
   }

   $parsedUrl = $matches[0];
   
   return $parsedUrl . '|Referer="' . $parsed_host . '"';
}

function getBaseAndReferer($url) {
    // This function fetches the video source and Referer
    $result = getDaddyLiveSource($url);
    
    // Split on '|Referer='
    $parts = explode('|Referer="', $result);
    
    // Extract the base URL and Referer
    $baseUrlWithNumber = rtrim($parts[0], '/index.m3u8'); // remove the '/index.m3u8' part
    $baseUrl = preg_replace('/\d+/', '', $baseUrlWithNumber); // remove any digits (i.e., the number)
    $referer = rtrim($parts[1], '"'); // remove the closing '"'

    return [$baseUrl, $referer];
}

function constructNewUrl($originalUrl, $baseUrl, $referer) {
    preg_match('/stream-(\d+)\.php/', $originalUrl, $matches);
    
    if (isset($matches[1])) {
        $number = $matches[1];
        return "{$baseUrl}{$number}/index.m3u8|Referer=\"{$referer}\"";
    }

    return false;
}

list($baseUrl, $referer) = getBaseAndReferer("https://d.daddylivehd.sx/stream/stream-597.php");

// Step 1: Fetch the M3U8 file.
$originalContent = file_get_contents('https://magnetic.website/jet/DADDYLIVE.m3u8');

// Step 2: Get base URL and Referer.
list($baseUrl, $referer) = getBaseAndReferer("https://d.daddylivehd.sx/stream/stream-597.php");  // You can choose any URL from the M3U8 for this

// Step 3: Replace URLs.
$pattern = '/(https:\/\/d\.daddylivehd\.sx\/stream\/stream-\d+\.php)/';
$replacedContent = preg_replace_callback($pattern, function ($matches) use ($baseUrl, $referer) {
    return constructNewUrl($matches[1], $baseUrl, $referer);
}, $originalContent);

$prefixToRemove = 'plugin://plugin.video.madtitansports/sportjetextractors/play?urls=';
$replacedContent = str_replace($prefixToRemove, '', $replacedContent);
$replacedContent = str_replace('#EXTM3U', '#EXTM3U url-tvg="https://magnetic.website/jet/epg.xml"', $replacedContent);

// Step 4: Output the modified content
header('Content-Type: application/vnd.apple.mpegurl');
echo $replacedContent;
exit();

?>
