<?php

$epgUrl = "http://m3u4u.com/epg/j67zn62vwgum75r4nd1w";
$epgFile = "channels/epg.xml";
$lastUpdatedFile = "channels/last_updated.txt";

if (!file_exists($lastUpdatedFile) || (time() - file_get_contents($lastUpdatedFile)) > 86400) {
	
    $epgContent = file_get_contents($epgUrl);

    if ($epgContent) {
        
        $unzippedContent = gzdecode($epgContent);
        
        file_put_contents($epgFile, $unzippedContent);
        
        file_put_contents($lastUpdatedFile, time());
    }
}

echo @file_get_contents($epgFile);

?>
