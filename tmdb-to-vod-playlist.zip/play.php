<?php
// Created By gogetta.teams@gmail.com
// Please leave this in this script.
//https://github.com/gogetta69/TMDB-To-VOD-M3U8-Movie-List

require_once 'JavaScriptUnpacker.php';
require_once 'config.php';
accessLog();

if (isset($_GET['dev']) && $_GET['dev'] === 'true') {
$GLOBALS['DEBUG'] = true;	
}	
if (!$GLOBALS['DEBUG']) {
    error_reporting(0);	
} 	

////////////////////////////// Run Script ///////////////////////////////

cleanupCacheFiles(); // Check cache cleanup
//Run the script.
$expirationDuration = $expirationHours * 3600;

if (isset($_GET['movieId']) && !empty($_GET['movieId'])) {
    $movieId = $_GET['movieId'];

    $type = $_GET['type'] ?? 'movies';
    $episodeData = isset($_GET['data']) ? base64_decode($_GET['data']) : '';
} else {
    echo 'The movieId parameter was not passed or is empty!';
    exit();
}

$globalTitle = '';
$torrentData = [];
//Run movies
if ($type == 'movies') {	
if (movieDetails_TMDB($movieId, $apiKey, $useRealDebrid) !== false) {
    http_response_code(404);
    echo "The requested resource was not found.";
	exit();
} else {
    echo "Should have redirected to the video.";
	exit();
}
//Run series
} elseif ($type == 'series'){
	$episodeData = explode(':', $episodeData);
	$subEpData = explode('/', $episodeData[1]);
	
	$movieId = $subEpData[0];
	
	//Store season number
	$seasonNoPad = $subEpData[2];
	$subEpData[2] = str_pad($subEpData[2], 2, "0", STR_PAD_LEFT);
	$season = $subEpData[2];
	//Store episode number
	$episodeNoPad = $subEpData[4];
	$subEpData[4] = str_pad($subEpData[4], 2, "0", STR_PAD_LEFT);
	$episode = $subEpData[4];
	$episodeId = 's'.$subEpData[2].'e'.$subEpData[4];
	seriesDetails_TMDB($movieId, $apiKey, $useRealDebrid, $episodeData);
}

////////////////////////////// List of Functions ///////////////////////////////

////////////////////////////// The Movie Database ///////////////////////////////

function movieDetails_TMDB($movieId, $apiKey, $useRealDebrid)
{
    global $userDefinedOrder, $language;

    // Define the cache key
    $key = $movieId . '_tmdb_url';

	
		
	// Try to read the URL from cache
	$cachedUrl = readFromCache($key);

	// If the URL is found in cache and hasn't expired, perform a 301 redirect
	if ($cachedUrl !== null) {
		if ($GLOBALS['DEBUG']) {
			echo "Service: Pulled from the cache - Url: " . $cachedUrl . "</br></br>";
			echo 'Debugging: Redirection to the video would have taken place here.</br></br>';
		} else {
			header("HTTP/1.1 301 Moved Permanently");
			header("Location: $cachedUrl");
			exit();
		}
	}

	
    $baseUrl = 'https://api.themoviedb.org/3/movie/';
    $url = $baseUrl . $movieId . '?api_key=' . $apiKey . '&language=' . $language;

    $response = @file_get_contents($url);

    if ($response !== false) {
        $movieData = json_decode($response, true);
        $imdbId = $movieData['imdb_id'];
        $title = $movieData['title'];
        $year = substr($movieData['release_date'], 0, 4);		
		$GLOBALS['globalTitle'] .= $title . ' ' . $year;

        if ($imdbId) {
            if ($GLOBALS['DEBUG']) {
                // Log the extracted information
                echo 'IMDb ID: ' . $imdbId . "</br></br>";
                echo 'Title: ' . $title . "</br></br>";
                echo 'Year: ' . $year . "</br></br>";
            }

            $predefinedFunctions = ['theMovieArchive_site', 'shegu_net_links', 'primewire_tf', 'torrentSites', 'goMovies_sx', 'upMovies_to', 'superEmbed_stream', 'smashyStream_com'];

            $successfulFunctionName = '';

            // Iterate through the user-defined order and execute functions accordingly
            foreach ($userDefinedOrder as $functionName) {
                if (in_array($functionName, $predefinedFunctions) && function_exists($functionName)) {
                    // Check if Real Debrid functions should run
                    if (!$useRealDebrid && in_array($functionName, ['torrentSites'])) {
                        continue; // Skip Real Debrid functions if not needed
                    }

                    // Define an array of parameters to pass to the function
                    $params = [$movieId, $imdbId, $title, $year];

                    if ($functionName == 'torrentSites') {
                        $params = [$movieId, $imdbId, $title, $year];
                    }

                    if ($functionName == 'shegu_net_links') {
                        $params = [$title, $year];
                    }


                    if ($functionName == 'theMovieArchive_site') {
                        $params = [$movieId, $title];
                    }
					
					if ($functionName == 'goMovies_sx') {
                        $params = [$title, $year];
                    }
					
					if ($functionName == 'upMovies_to') {
                        $params = [$title, $year];
                    }		

					if ($functionName == 'superEmbed_stream') {
                        $params = [$imdbId, $title, $year];
                    }
					if ($functionName == 'smashyStream_com') {
                        $params = [$movieId, $imdbId, $title];
                    }	

					if ($functionName == 'primewire_tf') {
                        $params = [$title, $year, $movieId, $imdbId];
                    }					

                    // Call the function with appropriate arguments
                    $result = call_user_func_array($functionName, $params);

                    // Check the result and continue or stop based on success
                    if ($result !== false) {
                        // Store the successful function name
                        $successfulFunctionName = $functionName;

                        if ($functionName !== 'torrentSites') {
							if (strpos($result, 'video_proxy.php') === false){
								$lCheck = checkLinkStatusCode($result);
							} else {
								$lCheck = true;
							}
                        } else {
                            $lCheck = true;
                        }

                        if ($GLOBALS['DEBUG']) {
                            // Log the extracted information with the successful function name
                            if ($lCheck !== false) {
                                echo "Service: " . $successfulFunctionName . ' - Url: ' . $result . "</br></br>";
                                echo 'Debugging: Redirection to the video would have taken place here.</br></br>';
                                writeToCache($key, $result);
                                exit();
                            }
                        } else {
                            // Put write to the cache here
                            if ($lCheck !== false) {
                                writeToCache($key, $result);
                                header("HTTP/1.1 301 Moved Permanently");
                                header("Location: $cachedUrl");
                                exit();
                            }
                        }
                    }
                }
            }
            http_response_code(404);
            echo "The requested resource was not found.";
            exit();

        } else {
            if ($GLOBALS['DEBUG']) {
                echo 'IMDb ID not found for the movie.' . "</br></br>";
            }
            http_response_code(404);
            echo "The requested resource was not found.";
            exit();
        }
    } else {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: Unable to retrieve movie details.' . "</br></br>";
        }
        http_response_code(404);
        echo "The requested resource was not found.";
        exit();
    }
}

function seriesDetails_TMDB($movieId, $apiKey, $useRealDebrid, $episodeData)
{	
    global $userDefinedOrder, $episodeId, $language;
	

    // Define the cache key
    $key = $movieId . '_series_' . $episodeId . '_url';

    // Try to read the URL from cache
    $cachedUrl = readFromCache($key);

    // If the URL is found in cache and hasn't expired, perform a 301 redirect
    if ($cachedUrl !== null) {
        if ($GLOBALS['DEBUG']) {
            echo "Service: Pulled from the cache - Url: " . $cachedUrl . "</br></br>";
            echo 'Debugging: Redirection to the video would have taken place here.</br></br>';
        } else {
            header("HTTP/1.1 301 Moved Permanently");
            header("Location: $cachedUrl");
            exit();
        }
    }

    $baseUrl = 'https://api.themoviedb.org/3/tv/';
    $url = $baseUrl . $movieId . '?api_key=' . $apiKey . '&language=' . $language;

    $response = @file_get_contents($url);

    if ($response !== false) {
        $seriesData = json_decode($response, true);
        $imdbId = $episodeData[0];
		$title = $seriesData['name'];
        $setitle = $seriesData['name'].' '.$episodeId;
        $year = substr($seriesData['first_air_date'], 0, 4);
		$GLOBALS['globalTitle'] .= $setitle;

        if ($imdbId) {
            if ($GLOBALS['DEBUG']) {
                // Log the extracted information
                echo 'IMDb ID: ' . $imdbId . "</br></br>";
                echo 'Title: ' . $title . "</br></br>";
                echo 'Year: ' . $year . "</br></br>";
            }	

            $predefinedFunctions = ['superEmbed_stream', 'shegu_net_links',
                'torrentSites', 'goMovies_sx', 'smashyStream_com', 'upMovies_to', 'primewire_tf'];

            $successfulFunctionName = '';

            // Iterate through the user-defined order and execute functions accordingly
            foreach ($userDefinedOrder as $functionName) {
                if (in_array($functionName, $predefinedFunctions) && function_exists($functionName)) {
                    // Check if Real Debrid functions should run
                    if (!$useRealDebrid && in_array($functionName, ['torrentSites'])) {
                        continue; // Skip Real Debrid functions if not needed
                    }

                    // Define an array of parameters to pass to the function
                    $params = [$movieId, $imdbId, $setitle, $year];

                    if ($functionName == 'torrentSites') {
                        $params = [$movieId, $imdbId, $setitle];
                    }

                    if ($functionName == 'shegu_net_links') {
                        $params = [$title, $year];
                    }

					
					if ($functionName == 'goMovies_sx') {
                        $params = [$title, $year];
                    }
					
					if ($functionName == 'upMovies_to') {
                        $params = [$title, $year];
                    }
					
					if ($functionName == 'superEmbed_stream') {
                        $params = [$imdbId, $title, $year];
                    }	
					
					if ($functionName == 'smashyStream_com') {
                        $params = [$movieId, $imdbId, $title];
                    }	
					
					if ($functionName == 'primewire_tf') {
                        $params = [$title, $year, $movieId, $imdbId];
                    }	

                    // Call the function with appropriate arguments
                    $result = call_user_func_array($functionName, $params);

                    // Check the result and continue or stop based on success
                    if ($result !== false) {
                        // Store the successful function name
                        $successfulFunctionName = $functionName;

                        if ($functionName !== 'torrentSites') {
                            $lCheck = checkLinkStatusCode($result);
                        } else {
                            $lCheck = true;
                        }

                        if ($GLOBALS['DEBUG']) {
                            // Log the extracted information with the successful function name
                            if ($lCheck !== false) {
                                echo "Service: " . $successfulFunctionName . ' - Url: ' . $result . "</br></br>";
                                echo 'Debugging: Redirection to the video would have taken place here.</br></br>';
                                writeToCache($key, $result);
                                exit();
                            }
                        } else {
                            // Put write to the cache here
                            if ($lCheck !== false) {
                                writeToCache($key, $result);
                                header("HTTP/1.1 301 Moved Permanently");
                                header("Location: $cachedUrl");
                                exit();
                            }
                        }
                    }
                }
            }
            http_response_code(404);
            echo "The requested resource was not found.";
            exit();

        } else {
            if ($GLOBALS['DEBUG']) {
                echo 'IMDb ID not found for the movie.' . "</br></br>";
            }
            http_response_code(404);
            echo "The requested resource was not found.";
            exit();
        }
    } else {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: Unable to retrieve movie details.' . "</br></br>";
        }
        http_response_code(404);
        echo "The requested resource was not found.";
        exit();
    }
}

////////////////////////////// Real Debrid ///////////////////////////////

function addMagnetLink_RD($torrents, $magnetLink, $tSite)
{
    global $PRIVATE_TOKEN;

    try {
        $url = 'https://api.real-debrid.com/rest/1.0/torrents/addMagnet';
        $postData = 'magnet=' . urlencode($magnetLink);
        $headers = ['Authorization: Bearer ' . $PRIVATE_TOKEN,
            'Content-Type: application/x-www-form-urlencoded', ];
        $options = ['http' => ['method' => 'POST', 'header' => implode("\r\n", $headers),
            'content' => $postData, ], ];
        $context = stream_context_create($options);
        $response = file_get_contents($url, false, $context);
        $statusCode = http_response_code();
        if ($statusCode !== 200 && $statusCode !== 201) {
            if ($GLOBALS['DEBUG']) {
                echo 'HTTP Error Code: ' . $statusCode . "</br></br>";
                echo 'Error Response: ' . $response . "</br></br>";
            }
            return;
        }
        $data = json_decode($response, true);
        $id = $data['id'];
        $uri = urldecode($data['uri']);
        if ($GLOBALS['DEBUG']) {
            echo 'ID: ' . $id . "</br></br>";
            echo 'URI: ' . $uri . "</br></br>";
        }
        return selectMultipleFiles_RD($torrents, $id, $tSite);
    }
    catch (exception $e) {
        if ($GLOBALS['DEBUG']) {
            echo "Error in addMagnetLink_RD: " . $e->getMessage() . "</br></br>";
        }
        return; // Continue execution of the script
    }
}

function selectFile_RD($torrentId, $fileId)
{
    global $PRIVATE_TOKEN;	

    try {
        $url = 'https://api.real-debrid.com/rest/1.0/torrents/selectFiles/' . $torrentId;
        $postData = 'files=' . $fileId;
        $headers = ['Authorization: Bearer ' . $PRIVATE_TOKEN,
            'Content-Type: application/x-www-form-urlencoded', ];
        $options = ['http' => ['method' => 'POST', 'header' => implode("\r\n", $headers),
            'content' => $postData, ], ];
        $context = stream_context_create($options);
        $response = file_get_contents($url, false, $context);
        $statusCode = http_response_code();
        // Define the array of error codes
        $errorCodes = [202 => 'Action already done', 400 =>
            'Bad Request (see error message)', 401 => 'Bad token (expired, invalid)', 403 =>
            'Permission denied (account locked, not premium)', 404 =>
            'Wrong parameter (invalid file id(s)) / Unknown resource (invalid id)',
            // Add more error codes as needed
            ];



        // Check if the status code is in the array of error codes
        if (array_key_exists($statusCode, $errorCodes)) {
            if ($GLOBALS['DEBUG']) {
                echo 'HTTP Error Code: ' . $statusCode . "</br></br>";
            }

            // Output the error description
            echo 'Reason: ' . $errorCodes[$statusCode] . "</br></br>";

            echo 'Error Response: ' . $response . "</br></br>";
        }

		if ($GLOBALS['DEBUG']) {				
			print_r('selectFile_RD - Response: ' .  $statusCode . "</br></br>");
		}

    }
    catch (exception $e) {
        if ($GLOBALS['DEBUG']) {
            echo "Error in selectFile_RD: " . $e->getMessage() . "</br></br>";
        }
        return; // Continue execution of the script
    }
}

function selectMultipleFiles_RD($torrents, $torrentId, $tSite)
{
    global $PRIVATE_TOKEN, $type, $episodeId;

    try {
        $url = 'https://api.real-debrid.com/rest/1.0/torrents/info/' . $torrentId;
        $headers = ['Authorization: Bearer ' . $PRIVATE_TOKEN,
            'Content-Type: application/x-www-form-urlencoded', ];
        $options = ['http' => ['method' => 'GET', 'header' => implode("\r\n", $headers), ], ];
        $context = stream_context_create($options);
        $response = file_get_contents($url, false, $context);
        $statusCode = http_response_code();
        if ($statusCode === 200) {
            if ($GLOBALS['DEBUG']) {
                echo 'HTTP Response Content: ' . $response . "</br></br>";
            }
        } else {
            if ($GLOBALS['DEBUG']) {
                echo 'HTTP Error Code: ' . $statusCode . "</br></br>";
                echo 'Error Response: ' . $response . "</br></br>";
            }
            return;
        }
        $data = json_decode($response, true);
        $files = $data['files'];
		
		// Exclude files with the word 'sample' in their path
		$files = array_filter($files, function($file) {
			return stripos($file['path'], 'sample') === false;
		});
				
		//Select the file by $episodeId (s01e03) 
		if ($type == 'series'){
			$files = array_filter($files, function($file) use ($episodeId) {
				// Convert both strings to lowercase for a case-insensitive check
				return stripos(strtolower($file['path']), strtolower($episodeId)) !== false;
			});
		}
		

        $mp4FileIndex = findMp4FileIndex($files);
        if ($mp4FileIndex !== -1) {
            selectFile_RD($torrentId, $files[$mp4FileIndex]['id']);
        } else {
            $videoFileIndex = findAnyVideoFileIndex($files);
            if ($videoFileIndex !== -1) {
                selectFile_RD($torrentId, $files[$videoFileIndex]['id']);
            } else {
                if ($GLOBALS['DEBUG']) {
                    echo 'No video files found in the torrent.' . "</br></br>";
                }
            }
        }
        return getDlLink_RD($torrents, $torrentId, $tSite);
    }
    catch (exception $e) {
        if ($GLOBALS['DEBUG']) {
            echo "Error in selectMultipleFiles_RD: " . $e->getMessage() . "</br></br>";
        }
        return; // Continue execution of the script
    }
}

function getDlLink_RD($torrents, $torrentId, $tSite)
{
    global $PRIVATE_TOKEN, $type;

    try {
        $url = 'https://api.real-debrid.com/rest/1.0/torrents/info/' . $torrentId;
        $headers = ['Authorization: Bearer ' . $PRIVATE_TOKEN,
            'Content-Type: application/x-www-form-urlencoded', ];
        $options = ['http' => ['method' => 'GET', 'header' => implode("\r\n", $headers), ], ];
        $context = stream_context_create($options);
        $response = file_get_contents($url, false, $context);
        $statusCode = http_response_code();
        if ($statusCode === 200) {
            $data = json_decode($response, true);
            $linksArray = $data['links'];
            if ($linksArray && count($linksArray) > 0) {
                $firstLink = $linksArray[0];
                $payload = ['link' => $firstLink, 'remote' => 0, ];
                $context = stream_context_create(['http' => ['method' => 'POST', 'header' =>
                    implode("\r\n", $headers), 'content' => http_build_query($payload), ], ]);
                $unrestrictResponse = file_get_contents('https://api.real-debrid.com/rest/1.0/unrestrict/link', false,
                    $context);
                $unrestrictData = json_decode($unrestrictResponse, true);
                $downloadLink = $unrestrictData['download'];
                if ($GLOBALS['DEBUG']) {				
                    echo 'getDlLink_RD - Video link: ' . $downloadLink . "</br></br>";
                }
                $fileNameMatch = preg_match('#/([^/]+)$#', $downloadLink, $fileNameMatches);
                if ($fileNameMatch) {
                    $filenameNoExt = urldecode($fileNameMatches[1]);
                } else {
                    $filenameNoExt = 'Unknown';
                }

                return $downloadLink;
            } else {
                if ($GLOBALS['DEBUG']) {
					//print_r($response . "</br></br>");
                    echo 'getDlLink_RD: No links found in the array.' . "</br></br>";
                }

                return false;
            }
        } else {
            if ($GLOBALS['DEBUG']) {
                echo 'HTTP Error Code: ' . $statusCode . "</br></br>";
                echo 'Error Response: ' . $response . "</br></br>";
            }
        }
    }
    catch (exception $e) {
        if ($GLOBALS['DEBUG']) {
            echo "Error in getDlLink_RD: " . $e->getMessage() . "</br></br>";
        }

        return false;
    }
}

////////////////////////////// Processing ///////////////////////////////

function torrentSites($movieId, $imdbId, $title, $year=null){
global $timeOut, $maxResolution, $torrentData, $type, $season, $episode, $seasonNoPad, $episodeNoPad;

magnetdl_com($movieId, $imdbId, $title, $year);
bitLordSearch_com($movieId, $imdbId, $title, $year);	
thepiratebay_org($movieId, $imdbId, $title, $year);
torrentDownload_info($movieId, $imdbId, $title, $year);
popcornTime($movieId, $imdbId, $title);	
torrentGalaxy_to($movieId, $imdbId, $title); //Finish settingup filter
glodls_to($movieId, $imdbId, $title, $year);

if($type == "series"){
ezTV_re($movieId, $imdbId, $title);	
}
if($type == "movies"){
yts_mx($movieId, $imdbId, $title);
}
if (!empty($torrentData)){
	
$RealDebridLink = selectHashByPreferences($torrentData, $maxResolution, 'torrentSites');	
if($RealDebridLink !== false){
	logDetails($title, 'https://real-debrid.com/', $RealDebridLink, $type, $imdbId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
	return $RealDebridLink;
} else {
	logDetails($title, 'https://real-debrid.com/', 'n/a', $type, $imdbId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
	return false;
}	

} else {
	logDetails($title, 'https://real-debrid.com/', 'n/a', $type, $imdbId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
return false;	
}
}

function checkLinkStatusCode($url)
{
	//The link was was already checked so return true.
	if (strpos($url, 'video_proxy.php') !== false || strpos($url, 'hls_proxy.php') !== false) {
		return true;
	}	
	
	    // Check if the URL is empty
    if (empty($url)) {
        if ($GLOBALS['DEBUG']) {
            echo 'Link Checker - URL is empty.</br></br>';
        }
        return false;
    }
    // Check if the URL contains headers (i.e., "|")
    if (strpos($url, '|') !== false) {
        // Split the URL into the actual URL and headers (if "|" is present)
        list($actualUrl, $headersStr) = explode('|', $url, 2);

        // Trim any leading or trailing spaces from the headers
        $headersStr = trim($headersStr);

        // Initialize the headers array
        $headers = [];

        if (!empty($headersStr)) {
            // Convert headers to the correct format
            $headersArr = explode('|', $headersStr);

            foreach ($headersArr as $header) {
                list($headerName, $headerValue) = explode('=', $header, 2);
                $headers[] = $headerName . ': ' . $headerValue;
            }
        }

        // Create context options for the stream context
        $contextOptions = ['http' => ['header' => implode("\r\n", $headers)]];
        $context = stream_context_create($contextOptions);

        // Send a HEAD request to the actual URL with the extracted headers
        $responseHeaders = get_headers($actualUrl, 1, $context);
		
		sleep(1);

        if ($responseHeaders !== false) {
            // Extract the HTTP status code from the first header
            $httpStatus = explode(' ', $responseHeaders[0], 3);

            if (isset($httpStatus[1]) && ($httpStatus[1] == '404' || $httpStatus[1] == '503' ||
                $httpStatus[1] == '500' || $httpStatus[1] == '400')) {
                if ($GLOBALS['DEBUG']) {
                    echo 'Link Checker - The URL returned a ' . $httpStatus[1] .
                        ' status (Not Found).';
                }
                return false;
            } else {
                if ($GLOBALS['DEBUG']) {
                    echo 'Link Checker - Successful: The URL is accessible.</br></br>';
                }
                return true;
            }
        }

        if ($GLOBALS['DEBUG']) {
            echo 'Link Checker - Failed to fetch the URL or an error occurred.</br></br>';
        }
        return false;
    } else {
        // No headers, send a HEAD request to the URL without headers
        $responseHeaders = get_headers($url);

        if ($responseHeaders !== false) {
            // Extract the HTTP status code from the first header
            $httpStatus = explode(' ', $responseHeaders[0], 3);

            if (isset($httpStatus[1]) && ($httpStatus[1] == '404' || $httpStatus[1] == '503' ||
                $httpStatus[1] == '500' || $httpStatus[1] == '400' || $httpStatus[1] == '403')) {
                if ($GLOBALS['DEBUG']) {
                    echo 'Link Checker - The URL returned a ' . $httpStatus[1] .
                        ' status (Not Found).</br></br>';
                }
                return false;
            } else {
                if ($GLOBALS['DEBUG']) {
                    echo 'Link Checker - Successful: The URL is accessible.</br></br>';
                }
                return true;
            }
        }

        if ($GLOBALS['DEBUG']) {
            echo 'Link Checker - Failed to fetch the URL or an error occurred. </br></br>';
        }
        return false;
    }
}

function selectHashByPreferences($torrents, $maxResolution, $tSite)
{
    global $PRIVATE_TOKEN;

    $selectedHash = null;
    $highestResolutionBelowMax = 0;
    $lowestResolutionAboveMax = INF;

	// Extract hashes from the torrents array
	$hashes = array_map(function ($torrent) {
		if (isset($torrent['hash'])) {
			return strtolower($torrent['hash']);
		}
		return null;
	}, $torrents);
	
	$hashes = array_filter($hashes, function($value) {
    return $value !== null; //
	});

    // Form the hash string for the API request
    $hashString = implode("/", $hashes);

    // Define the API URL
    $url = "https://api.real-debrid.com/rest/1.0/torrents/instantAvailability/{$hashString}";
    if ($GLOBALS['DEBUG']) {
        echo "Combine hashes to send to RD - The formed url: " . $url . "</br></br>";
    }
    // Define the headers for the API request
    $headers = ["Authorization: Bearer {$PRIVATE_TOKEN}", ];

    // Create context for file_get_contents with headers
    $context = stream_context_create(['http' => ['method' => "GET", 'header' =>
        implode("\r\n", $headers), ]]);

    // Send the API request and decode the JSON response
    $response = file_get_contents($url, false, $context);
    $availabilityData = json_decode($response, true);

    // Filter the torrents array based on availability and video file extension
    $torrents = array_filter($torrents, function ($torrent)use ($availabilityData)
    {
		if (isset($torrent['hash'])) {
			$hash = strtolower($torrent['hash']);
		}
            // Convert the hash from the torrents array to lowercase
            $availabilityData = array_change_key_case($availabilityData, CASE_LOWER);
            // Convert all keys in availabilityData to lowercase

		if (isset($hash) && isset($availabilityData[$hash]['rd']) && is_array($availabilityData[$hash]['rd'])) {
			foreach ($availabilityData[$hash]['rd'] as $files) {
				if (is_array($files)) {
					foreach ($files as $file) {
						if (isset($file['filename']) && is_string($file['filename'])) {
							$filename = $file['filename'];
							$extension = pathinfo($filename, PATHINFO_EXTENSION);
							if (in_array($extension, ['mkv', 'mp4', 'avi', 'mov', 'flv', 'wmv', 'mpeg', 'mpg'])) { 
								return true;
							}
						}
					}
				}
			}
		}
        return false; }
    );

    foreach ($torrents as $torrent) {		

		$stripLongTitle = preg_replace('/[^a-zA-Z0-9 ]/', '', str_replace('.', ' ', $torrent['title_long']));
		$stripGlobaltitle = preg_replace('/[^a-zA-Z0-9 ]/', '', str_replace('.', ' ', $GLOBALS['globalTitle']));
		if ($GLOBALS['DEBUG']) {
			echo "Compare: " . $stripLongTitle . ' to ' . $stripGlobaltitle . "<br>";
		}
		// Filter results by title.
		if (strpos($stripLongTitle, $stripGlobaltitle) === false) {
			continue;
		} 
			
        $resolution = extractResolution($torrent['quality']);
        if ($GLOBALS['DEBUG']) {
            echo $resolution . ' vs ' . $maxResolution . "</br></br>";
        }
        // If resolution matches maxResolution, select the hash and exit the loop
        if ($resolution === $maxResolution) {
            $selectedHash = $torrent['hash'];
            if ($GLOBALS['DEBUG']) {
                echo 'Checking Details | Resolution: ' . $resolution . ' - Hash: ' . $selectedHash .
                    "</br></br>";
            }
            return addMagnetLink_RD($torrents, 'magnet:?xt=urn:btih:' . $torrent['hash'], $tSite);
        }

        // If the resolution is less than maxResolution but greater than highestResolutionBelowMax
        if ($resolution < $maxResolution && $resolution > $highestResolutionBelowMax) {
            $selectedHash = $torrent['hash'];
            $highestResolutionBelowMax = $resolution;
            if ($GLOBALS['DEBUG']) {
                echo 'Checking Details | Resolution: ' . $resolution . ' - Hash: ' . $selectedHash .
                    "</br></br>";
            }
        }

        // If the resolution is above maxResolution but less than lowestResolutionAboveMax
        if ($resolution > $maxResolution && $resolution < $lowestResolutionAboveMax) {
            $selectedHash = $torrent['hash'];
            $lowestResolutionAboveMax = $resolution;
            if ($GLOBALS['DEBUG']) {
                echo 'Selected Details | Resolution: ' . $resolution . ' - Hash: ' . $selectedHash .
                    "</br></br>";
            }
        }
    }

    // If a hash with the desired resolution was found, return it
    if ($selectedHash) {
        if ($GLOBALS['DEBUG']) {
            echo 'Chosen Hash: ' . $selectedHash . "</br></br>";
        }
        return addMagnetLink_RD($torrents, 'magnet:?xt=urn:btih:' . $selectedHash, $tSite);
    }

    // If no torrents were found with a resolution below the maxResolution, select the lowest available resolution.
    $lowestAvailableResolution = INF;
    foreach ($torrents as $torrent) {
		
		$stripLongTitle = preg_replace('/[^a-zA-Z0-9 ]/', '', str_replace('.', ' ', $torrent['title_long']));
		$stripGlobaltitle = preg_replace('/[^a-zA-Z0-9 ]/', '', str_replace('.', ' ', $GLOBALS['globalTitle']));
		if ($GLOBALS['DEBUG']) {
			echo "Compare: " . $stripLongTitle . ' to ' . $stripGlobaltitle . "<br>";
		}
		// Filter results by title.
		if (strpos($stripLongTitle, $stripGlobaltitle) === false) {
			continue;
		}
        $resolution = extractResolution($torrent['quality']);
        if ($resolution < $lowestAvailableResolution) {
            $selectedHash = $torrent['hash'];
            $lowestAvailableResolution = $resolution;
        }
    }
	if($selectedHash){
		if ($GLOBALS['DEBUG']) {
			echo 'Selected Hash: ' . $selectedHash . "</br></br>";
		}
		return addMagnetLink_RD($torrents, 'magnet:?xt=urn:btih:' . $selectedHash, $tSite);
	} else {
		if ($GLOBALS['DEBUG']) {			
			echo "No hash was found to be suitable.</br></br>";
		}
		return false;
	}
}

function extractResolution($quality)
{
    $regex = '/(\d+)P/i';
    preg_match($regex, $quality, $match);

    if ($match && $match[1]) {
        return intval($match[1]);
    }
    return null;
}

function findMp4FileIndex($files)
{
    foreach ($files as $index => $file) {
        if (substr($file['path'], -4) === '.mp4') {
            return $index; // Return the index of the MP4 file
        }
    }
    return - 1; // Return -1 if no MP4 file is found
}

function findAnyVideoFileIndex($files)
{
    foreach ($files as $index => $file) {
        if (isVideoFile($file['path'])) {
            return $index; // Return the index of the video file
        }
    }
    return - 1; // Return -1 if no video file is found
}

function isVideoFile($filePath)
{
    $videoExtensions = ['mkv', 'mp4', 'avi', 'mov', 'flv', 'wmv', '.mpeg', '.mpg'];
    foreach ($videoExtensions as $extension) {
        if (substr($filePath, -strlen($extension)) === $extension) {
            return true;
        }
    }
    return false;
}

function extractUpCloudKey($version = null) {
    $timeOut = 20;
    $context = stream_context_create(['http' => ['timeout' => $timeOut]]);
	$url = 'https://rabbitstream.net/js/player/prod/e4-player.min.js';
    $response = @file_get_contents($url, false, $context);
    
    if ($response === FALSE) {
        return json_encode(['error' => 'Could not retrieve the script.']); // Error in JSON format
    }

    $script = $response;

    $startOfSwitch = strrpos($script, "switch");
    $endOfCases = strpos($script, "partKeyStartPosition", $startOfSwitch);
    if ($startOfSwitch === false || $endOfCases === false) {
        return json_encode(['error' => 'Required patterns not found in the script.']); // Error in JSON format
    }
    $switchBody = substr($script, $startOfSwitch, $endOfCases - $startOfSwitch);

    $nums = [];
    preg_match_all('/:[a-zA-Z0-9]+=([a-zA-Z0-9]+),[a-zA-Z0-9]+=([a-zA-Z0-9]+);/', $switchBody, $matches, PREG_SET_ORDER);
    
    foreach ($matches as $match) {
        $innerNumbers = [];
        foreach (array_slice($match, 1) as $varMatch) {
            preg_match_all("/$varMatch=0x([a-zA-Z0-9]+)/", $script, $varMatches);
            $lastMatch = end($varMatches[1]);
            if (!$lastMatch) return json_encode(['error' => 'Failed to match the pattern in the script.']); // Error in JSON format
            $number = hexdec($lastMatch);
            $innerNumbers[] = $number;
        }

        $nums[] = $innerNumbers;
    }

    return json_encode($nums);
}

//Function for Primewire.tf (search key).
function generatePWSearchKey($query) {	
    $hardcodedKey = "hx4NNrPLs688H9x";
    $combinedString = $query . $hardcodedKey;
    $hashedString = sha1($combinedString);
    return substr($hashedString, 0, 10);
}

//Function for Primewire.tf (user data).
function decryptPWuserData($encryptedData) {
    // Check if encryptedData is provided
    if (!$encryptedData) {
        return false;
    }

    // Extract the last 10 characters as the key
    $key = substr($encryptedData, -10);

    // Remove the last 10 characters from encryptedData
    $encryptedData = substr($encryptedData, 0, -10);

    // Decode the remaining encryptedData
    $data = base64_decode($encryptedData);
    if ($data === false) {
        // Return false if base64_decode fails
        return false;
    }

    // Set decryption options
    $opts = OPENSSL_RAW_DATA | OPENSSL_DONT_ZERO_PAD_KEY | OPENSSL_ZERO_PADDING;

    // Decrypt the data
    $decrypted = openssl_decrypt($data, 'BF-ECB', $key, $opts);
    if ($decrypted === false) {
        // Return false if decryption fails
        return false;
    }

    // Split the decrypted string into parts of 5 characters each
    $keys = str_split($decrypted, 5);

    return $keys;
}

function getLastRedirectUrl($url) {
	
	global $timeOut;
	
    $ch = curl_init($url);

    // Set cURL options
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Follow redirects
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // Return the transfer as a string
    curl_setopt($ch, CURLOPT_HEADER, true);         // Include the header in the output
    curl_setopt($ch, CURLOPT_NOBODY, true);         // No need to download the body
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeOut);    // Set timeout

    // Set User-Agent
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0");

    // Execute the request
    curl_exec($ch);

    // Check if any error occurred
    if (!curl_errno($ch)) {
        $lastUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL); // Get the last effective URL
    } else {
        // Handle error, e.g., by throwing an exception or returning null
        $lastUrl = null;
    }

    // Close the cURL session
    curl_close($ch);

    return $lastUrl;
}

////////////////////////////// Video Link Extractors ///////////////////////////////

function vidmolyExtract($url, $tSite, $referer)
{
	  global $timeOut;
	  
    try {
        $context = stream_context_create([
            'http' => [
                'timeout' => $timeOut,
                'header' => 
                    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0\r\n" .
                    "Referer: " . $referer
            ]
        ]);

        $content = file_get_contents($url, false, $context);

        if ($content === false) {
            throw new Exception('HTTP Error: vidmolyExtract');
        }

        if (preg_match('/(?<=file:").*?(?=")/', $content, $matches)) {    
            $DirectLink = $matches[0];             

			$urlData = "|Origin='https://vidmoly.to/'|Referer='https://vidmoly.to/'|User-Agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0'";
			
			$checkData = $DirectLink . "|Referer='https://vidmoly.to/'|User-Agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0'";

            $lCheck = checkLinkStatusCode($checkData);
            if ($lCheck == true) {

				if ($GLOBALS['DEBUG']) {
					echo "Video link: " . $DirectLink . "<br><br>";
				}
                return 'hls_proxy.php?url=' . urlencode($DirectLink) . '&data=' . base64_encode($urlData);

            } else {
                return false;
            }
		}
    } catch (Exception $error) {
        if ($debug) {
            echo 'Error: ' . $error->getMessage() . "<br><br>";
        }
        return false;
    }
	return false;
}

function StreamwishExtract($url, $tSite, $referer)
{
    global $timeOut;

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, 'header' =>
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0\r\n" .
            "Referer: " . $referer, ], ]);

        $content = @file_get_contents($url, false, $context);


        if ($content === false) {
            throw new Exception('HTTP Error: StreamwishExtract');      
        }

       if (preg_match('/(?<=file:").*?(?=")/', $content, $matches)) {	

			$StreamwishDirect = $matches[0];				
		
			if ($GLOBALS['DEBUG']) {
				echo "Video link: " . $StreamwishDirect . "<br><br>";
			}				
								
			return $StreamwishDirect;
			
	
		} else {
			throw new Exception('Couldn\'t extract the source links on Streamwish');
		}

    } catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running StreamwishExtract. </br></br>';
        }
        return false;
    }
    if ($GLOBALS['DEBUG']) {
        echo 'Finished running StreamwishExtract. </br></br>';
    }
    return false;

}

function MixdropExtract($url, $tSite, $referer)
{
    global $timeOut;

    $url = str_replace('/f/', '/e/', $url);

    if ($GLOBALS['DEBUG']) {
        echo "Started MixdropExtract for $tSite. </br></br>";
    }
    $url = getLastRedirectUrl($url);


    try {
        $contextOptions = ['http' => ['timeout' => $timeOut, 'header' =>
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0\r\n" .
            "Referer: " . $referer]];

        $context = stream_context_create($contextOptions);
        $response = file_get_contents($url, false, $context);


        if ($response === false) {
            throw new Exception('HTTP Error: MixdropExtract');
        }


        if (preg_match('#\beval\(function\(p,a,c,k,e,d\).*?\}\)\)#', $response, $matches)) {
            $unpacker = new JavaScriptUnpacker();

            // Use the methods of the JavaScriptUnpacker class as needed
            $unpackedCode = $unpacker->unpack($matches[0]);

        } else {
            throw new Exception('Couldn\'t find javscript code for MixdropExtract');
        }

        if (!empty($unpackedCode) && preg_match('/MDCore\.wurl="([^"]+)"/', $unpackedCode,
            $matches)) {

            $DirectLink = 'https:' . $matches[1];

            //Run link checker before returning.
            $urlData = $DirectLink . "|Referer='" . $referer .
                "'|User-Agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0'";

            $lCheck = checkLinkStatusCode($urlData);
            if ($lCheck == true) {

            if ($GLOBALS['DEBUG']) {
                echo "Video link: " . $DirectLink . "<br><br>";
            }
                return 'video_proxy.php?data=' . base64_encode($urlData);

            } else {
                return false;
            }

        } else {
            throw new Exception('Couldn\'t extract the source links on Mixdrop');
        }

    }
    catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running MixdropExtract. </br></br>';
        }
        return false;
    }
    if ($GLOBALS['DEBUG']) {
        echo 'Finished running MixdropExtract. </br></br>';
    }
    return false;

}

function primewire_tf($title, $year, $movieId, $imdbId,)
{
	$primeWireDomain = 'https://www.primewire.tf';
	
    if ($GLOBALS['DEBUG']) {
        echo 'Started running primewire_tf </br></br>';
    }
	global $timeOut, $maxResolution, $type, $seasonNoPad, $episodeNoPad, $movieId;
	
    $tSite = 'primewire_tf';
	
	$apiUrl = $primeWireDomain . '/filter?s=' . $imdbId . '&ds=' . generatePWSearchKey($imdbId);		

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, 'header' =>
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0', ], ]);

        $response = @file_get_contents($apiUrl, false, $context);

        if ($response === false) {
            throw new Exception('HTTP Error: primewire_tf');
        }

    }
    catch (exception $error) {

        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
        }
			logDetails($title, $apiUrl, 'n/a', $type, $movieId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
        return false;
    }

    try {
        // Perform pattern matching to extract movie data
        if(preg_match('/(?<=<div class="index_item)[\s\S]*?(?=<\/div>)/', $response, $matches) && preg_match('/(?<=<a href=").*?(?=")/', $matches[0], $urlMatches)){			
			
			$detailsPage = $primeWireDomain . $urlMatches[0];
			
           if ($GLOBALS['DEBUG']) {
                echo "Details page found: <br>" . $detailsPage . "</br></br>";
            }				
			
		} else {
			throw new Exception("No search results found on primewire_tf");
		}

        $response = @file_get_contents($detailsPage, false, $context);
		
		if ($response === false) {
            throw new Exception('HTTP Error: primewire_tf');
        }
		
		//Get Season and episode page here if the type is series.
		
		if ($type == 'series'){
			if (preg_match('/(?<=<h2 class="tv_season_header">)[\s\S]*?(?=>)/', $response, $seBlock) && 
			preg_match('/(?<=data-id=").*?(?=")/', $seBlock[0], $seId)) {
				
				if (is_numeric($seId[0]) && strlen((string)$seId[0]) == 4) {
					$seIdNumber = is_numeric($seId[0]) ? (int)$seId[0] : 0;
					$seIdNumber = $seIdNumber + $seasonNoPad;
					$detailsPage = $detailsPage . '-season-' . $seIdNumber . '-episode-' . $episodeNoPad;
				} else {
					$detailsPage = $detailsPage . '-season-' . $seasonNoPad . '-episode-' . $episodeNoPad;
				}
				$pos = strpos($detailsPage, '-');
				$detailsPage = substr_replace($detailsPage, '/', $pos, 1);
				$response = @file_get_contents($detailsPage, false, $context);
				
				if ($response === false) {
					throw new Exception('HTTP Error: primewire_tf');
				}
			    if ($GLOBALS['DEBUG']) {
					echo "Series subpage found: <br>" . $detailsPage . "</br></br>";
				}				

			} else {
				throw new Exception("Couldn't get the series subpage on primewire_tf.");
			}				
		} 
		
		 if(preg_match('/(?<="user-data" v=").*?(?=")/', $response, $userData) && preg_match_all('/(?<=class="movie_version">)[\s\S]*?(?=<\/table>)/', $response, $textBlock)){
			 
			if ($GLOBALS['DEBUG']) {
                echo "Encrypted user-data string: <br>" . $userData[0] . "</br></br>";
            }
			
			$keys = decryptPWuserData($userData[0]);	
			
			if($keys === false){
				throw new Exception("user-data decryption failed on primewire_tf.");
			}	
			 
		 }	else {
				throw new Exception("No links found on primewire_tf.");
		 }


		$counter = 0; 
        foreach ($textBlock[0] as $divBlock) {
			
            
            if ($GLOBALS['DEBUG']) {
                echo "Looking for a match in textBlock: " . $counter . "</br></br>";
            }
			
			//Run filelions extract
            if (strpos($divBlock, 'filelions') !== false) {
                
				if(isset($keys[$counter])){
					$hostUrl = $primeWireDomain . '/links/go/' . $keys[$counter];
					if ($GLOBALS['DEBUG']) {
                        echo 'Page containing filelions: ' . $hostUrl . "</br></br>";
                    }
				} else {
				 continue;
				}
                 $extractorReturn = FilelionsExtract($hostUrl, $tSite);
				 
				if ($extractorReturn !== false) {
						logDetails($title, $apiUrl, $extractorReturn, $type, $movieId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');						
                    return $extractorReturn;
                }
            }
			
			//Run voe extract
			if (strpos($divBlock, 'voe') !== false) {
                
				if(isset($keys[$counter])){
					$hostUrl = $primeWireDomain . '/links/go/' . $keys[$counter];
					if ($GLOBALS['DEBUG']) {
                        echo 'Page containing voe: ' . $hostUrl . "</br></br>";
                    }
				} else {
				 continue;
				}
                 $extractorReturn = VoeExtract($hostUrl, $tSite);
				 
				if ($extractorReturn !== false) {
						logDetails($title, $apiUrl, $extractorReturn, $type, $movieId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');						
                    return $extractorReturn;
                }
            }
			
			//Run Upstream extract
			if (strpos($divBlock, 'upstream') !== false) {
                
				if(isset($keys[$counter])){
					$hostUrl = $primeWireDomain . '/links/go/' . $keys[$counter];
					if ($GLOBALS['DEBUG']) {
                        echo 'Page containing upstream: ' . $hostUrl . "</br></br>";
                    }
				} else {
				 continue;
				}
                 $extractorReturn = UpstreamExtract($hostUrl, $tSite);
				 
				if ($extractorReturn !== false) {
						logDetails($title, $apiUrl, $extractorReturn, $type, $movieId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');						
                    return $extractorReturn;
                }
            }
			
			//Run MixDrop extract
			if (strpos($divBlock, 'mixdrop') !== false) {
                
				if(isset($keys[$counter])){
					
					$hostUrl = $primeWireDomain . '/links/go/' . $keys[$counter];
					$hostUrl = getLastRedirectUrl($hostUrl);
					
					if ($GLOBALS['DEBUG']) {
                        echo 'Page containing mixdrop: ' . $hostUrl . "</br></br>";
                    }
				} else {
				 continue;
				}
                 $extractorReturn = MixdropExtract($hostUrl, $tSite, $primeWireDomain);
				 
				if ($extractorReturn !== false) {
						logDetails($title, $apiUrl, $extractorReturn, $type, $movieId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');						
                    return $extractorReturn;
                }
            }
			
			 //Run Streamwish extract
			if (strpos($divBlock, 'streamwish') !== false) {
                
				if(isset($keys[$counter])){
					
					$hostUrl = $primeWireDomain . '/links/go/' . $keys[$counter];
					$hostUrl = getLastRedirectUrl($hostUrl);
					
					if ($GLOBALS['DEBUG']) {
                        echo 'Page containing streamwish: ' . $hostUrl . "</br></br>";
                    }
				} else {
				 continue;
				}
                 $extractorReturn = StreamwishExtract($hostUrl, $tSite, $primeWireDomain);
				 
				if ($extractorReturn !== false) {
						logDetails($title, $apiUrl, $extractorReturn, $type, $movieId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');						
                    return $extractorReturn;
                }
            }
			
			//Run vidmoly extract
			if (strpos($divBlock, 'vidmoly') !== false) {

				if(isset($keys[$counter])){
					
					$hostUrl = $primeWireDomain . '/links/go/' . $keys[$counter];
					$hostUrl = getLastRedirectUrl($hostUrl);
					
					if ($GLOBALS['DEBUG']) {
                        echo 'Page containing vidmoly: ' . $hostUrl . "</br></br>";
                    }
				} else {
				 continue;
				}
                 $extractorReturn = vidmolyExtract($hostUrl, $tSite, $primeWireDomain);
				 
				if ($extractorReturn !== false) {
						logDetails($title, $apiUrl, $extractorReturn, $type, $movieId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');						
                    return $extractorReturn;
                }
            }
			
			//Run Streamvid extract
			if (strpos($divBlock, 'streamvid') !== false) {

				if(isset($keys[$counter])){
					
					$hostUrl = $primeWireDomain . '/links/go/' . $keys[$counter];
					$hostUrl = getLastRedirectUrl($hostUrl);
					
					if ($GLOBALS['DEBUG']) {
                        echo 'Page containing streamvid: ' . $hostUrl . "</br></br>";
                    }
				} else {
				 continue;
				}
                 $extractorReturn = StreamvidExtract($hostUrl, $tSite, $primeWireDomain);
				 
				if ($extractorReturn !== false) {
						logDetails($title, $apiUrl, $extractorReturn, $type, $movieId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');						
                    return $extractorReturn;
                }
            }

		$counter++;
        }


    }
    catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo "Couldn't locate an extractor for primewire_tf. </br></br>";
        }
			logDetails($title, $apiUrl, 'n/a', $type, $movieId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');		
        return false;
    }
    if ($GLOBALS['DEBUG']) {
        echo "Couldn't locate a link on primewire_tf. </br></br>";
    }
	logDetails($title, $apiUrl, 'n/a', $type, $movieId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');		
	return false;
}

function goMovies_sx($title, $year)
{
	    global $timeOut, $maxResolution, $type, $seasonNoPad, $episodeNoPad, $movieId;
		
    if ($GLOBALS['DEBUG']) {
        echo 'Started running goMovies_sx </br></br>';
    }
    global $timeOut;
    global $maxResolution;
    $tSite = 'goMovies_sx';

    $apiUrl = 'https://gomovies.sx/ajax/search';

    try {
        $postData = json_encode(['keyword' => $title, ]);

        $ch = curl_init();

        // Set cURL options
        curl_setopt($ch, CURLOPT_URL, $apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeOut);
        curl_setopt($ch, CURLOPT_USERAGENT,
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0');
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

        $response = curl_exec($ch);


        if ($response === false) {
            throw new Exception('HTTP Error: goMovies_sx');
        }


        $doc = new DOMDocument();
        $doc->loadHTML($response);

        $divElements = $doc->getElementsByTagName('div');
        $matchingHref = null;

        $divElements = $doc->getElementsByTagName('a');


        foreach ($divElements as $a) {
            // Check if this <a> element has the expected class "nav-item"
            if ($a->getAttribute('class') == 'nav-item') {
                // Find the title and year elements within this <a> element
                $titleElement = $a->getElementsByTagName('h3')->item(0);
                $yearElement = $a->getElementsByTagName('span')->item(0);				

                if ($GLOBALS['DEBUG']) {
                    echo "Looking for a match by class: nav-item </br></br>";
                }

                // Check if the title and year match your criteria
				if (strtolower(trim($title)) == strtolower(trim($titleElement->textContent)) &&
					($type != 'movies' || strtolower(trim($year)) == strtolower(trim($yearElement->textContent)))){

                    // Get the href link
                    if ($a->getAttribute('href')) {
                        $Pagehref = "https://gomovies.sx" . $a->getAttribute('href');
                        if (preg_match('/(\d+)$/', $Pagehref, $matches)) {
                            $number = $matches[0];
                            if ($GLOBALS['DEBUG']) {
                                echo "Located watch id $number on goMovies_sx </br></br>";
                            }
							
							if ($type == "movies"){

								$url = "https://gomovies.sx/ajax/movie/episodes/" . $number;
							} else {
								
								$url = "https://gomovies.sx/ajax/season/list/" . $number;
							}
                            $context = stream_context_create(['http' => ['timeout' => $timeOut, 'header' =>
                                "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0\r\n",
                                "X-Requested-With: XMLHttpRequest"], ]);

                            $response = @file_get_contents($url, false, $context);					
													
							if ($type == "series"){
								$pattern = '/<a\s+data-id="(\d+)"\s*[^>]*\s*>Season\s+' . $seasonNoPad . '<\/a>/';
							if(!preg_match($pattern, $response, $matches)){
								throw new Exception('Couldn\'t locate season id on goMovies_sx');						 
							} else {
							if ($GLOBALS['DEBUG']) {
								 echo 'Located season id: ' . $matches[1] . "</br></br>";
							 }
							 $url ='https://gomovies.sx/ajax/season/episodes/' . $matches[1];
							 $response = @file_get_contents($url, false, $context);
							 $pattern = '/<a\s+id="episode-(\d+)"\s*[^>]*\s*Eps\s+' .$episodeNoPad.'\:/';
							if(!preg_match($pattern, $response, $matches)){
								throw new Exception('Couldn\'t episode id on goMovies_sx');						 
							} else {
							if ($GLOBALS['DEBUG']) {
								 echo 'Located episode id: ' . $matches[1] . "</br></br>";
							 }
							 $url ='https://gomovies.sx/ajax/episode/servers/' . $matches[1];
							 $response = @file_get_contents($url, false, $context);
							}								
							}
							}
							
                            if ($GLOBALS['DEBUG']) {
                                print_r('Video servers located: ' . $response . "</br></br>");
                            }
                            if ($response === false) {
                                throw new Exception('HTTP Error: goMovies_sx');
                            }
                            $doc = new DOMDocument();
                            $doc->loadHTML($response);

                            $xpath = new DOMXPath($doc);

                            $liElements = $xpath->query('//li[@class="nav-item"]');

                            if ($liElements !== null) {
                                foreach ($liElements as $li) {
                                    // Find the <a> element within the current <li> element
                                    $aElement = $xpath->query('.//a', $li)->item(0);

                                    if ($aElement !== null) {
                                        $title = $aElement->getAttribute('title');
										
										if($type == 'movies'){
											$dataLinkid = $aElement->getAttribute('data-linkid');
										} else {
											 $dataLinkid = $aElement->getAttribute('data-id');
										}
                                        // Check if the title matches "UpCloud" and perform actions accordingly
										if (strpos($title, 'UpCloud') !== false) {
                                            
                                            if ($GLOBALS['DEBUG']) {
                                                echo 'Page containing UpCloud: ' . $dataLinkid . "</br></br>";

                                            }
                                            $url = "https://gomovies.sx/ajax/sources/" . $dataLinkid;
                                            $response = @file_get_contents($url, false, $context);
                                            if ($response === false) {
                                                throw new Exception('HTTP Error: goMovies_sx');
                                            }

                                            // Decode the JSON data into an associative array
                                            $data = json_decode($response, true);

                                            if ($data !== null && isset($data['link'])) {
                                                if ($GLOBALS['DEBUG']) {
                                                    print_r('The returned Json for UpCloud: ' . $response . "</br></br>");
                                                }
                                                //Run UpCloud extractor here.
                                                $returnExtractor = UpCloudExtract($data['link'], $tSite);
                                                if ($returnExtractor !== false) {
														logDetails($GLOBALS['globalTitle'], $url, $returnExtractor, $type, $movieId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
                                                    return $returnExtractor;
                                                }

                                            } else {
                                                throw new Exception('Couldn\'t find the Json on UpCloud for goMovies_sx');
                                            }

                                        }
                                        // Check if the title matches "Upstream" and perform actions accordingly
										if (strpos($title, 'Upstream') !== false) {
                                            if ($GLOBALS['DEBUG']) {
                                                echo 'Page containing Upstream: ' . $dataLinkid . "</br></br>";

                                            }
                                            $url = "https://gomovies.sx/ajax/sources/" . $dataLinkid;
                                            $response = @file_get_contents($url, false, $context);
                                            if ($response === false) {
                                                throw new Exception('HTTP Error: goMovies_sx');
                                            }

                                            // Decode the JSON data into an associative array
                                            $data = json_decode($response, true);


                                            if ($data !== null && isset($data['link'])) {
                                                if ($GLOBALS['DEBUG']) {
                                                    print_r('The returned Json for Upstream: ' . $response . "</br></br>");
                                                }
                                                //Run Upstream extractor here.
                                                $returnExtractor = UpstreamExtract($data['link'], $tSite);

                                                if ($returnExtractor !== false) {
														logDetails($GLOBALS['globalTitle'], $url, $returnExtractor, $type, $movieId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
                                                    return $returnExtractor;
                                                }


                                            } else {
                                                throw new Exception('Couldn\'t find the Json on Upstream for goMovies_sx');
                                            }

                                        }
										
										// Check if the title matches "MixDrop" and perform actions accordingly
                                        if (strpos($title, 'MixDrop') !== false) {
                                            if ($GLOBALS['DEBUG']) {
                                                echo 'Page containing MixDrop: ' . $dataLinkid . "</br></br>";

                                            }
                                            $url = "https://gomovies.sx/ajax/sources/" . $dataLinkid;
                                            $response = @file_get_contents($url, false, $context);
                                            if ($response === false) {
                                                throw new Exception('HTTP Error: goMovies_sx');
                                            }

                                            // Decode the JSON data into an associative array
                                            $data = json_decode($response, true);
												 
                                            if ($data !== null && isset($data['link'])) {
                                                if ($GLOBALS['DEBUG']) {
                                                    print_r('The returned Json for MixDrop: ' . $response . "</br></br>");
                                                }
                                                //Run MixDrop extractor here.
												$response = @file_get_contents($data['link'], false, $context);																	
												if (preg_match('#\beval\(function\(p,a,c,k,e,d\).*?\}\)\)#', $response, $matches)) {
													$unpacker = new JavaScriptUnpacker();
													
													// Use the methods of the JavaScriptUnpacker class as needed
													$unpackedCode = $unpacker->unpack($matches[0]);

												} 
												if (!empty($unpackedCode) && preg_match('/MDCore\.wurl="([^"]+)"/', $unpackedCode, $matches)){
													
													$mixdropDirect = 'https:' . $matches[1];								

													//Run link checker before returning.
													$urlData = $mixdropDirect .
														"|Referer='" . $data['link'] . "'|User-Agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0'";
														
													$lCheck = checkLinkStatusCode($urlData);
													if ($lCheck == true){									
					
														$returnExtractor = 'video_proxy.php?data=' . base64_encode($urlData);
													} else {
														$returnExtractor = false;
													}
													
												} else {
														$returnExtractor = false;

												}												

                                                if ($returnExtractor !== false) {
														logDetails($GLOBALS['globalTitle'], $url, $returnExtractor, $type, $movieId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
                                                    return $returnExtractor;
                                                }


                                            } else {
                                                throw new Exception('Couldn\'t find the Json on MixDrop for goMovies_sx');
                                            }

                                        }

                                    } else {
                                        throw new Exception('Couldn\'t locate links on goMovies_sx');
                                    }
                                }
                            } else {
                                if ($GLOBALS['DEBUG']) {
                                    echo "No <li> elements with class 'nav-item' found.\n";
                                }
                            }


                        } else {
                            throw new Exception('Couldn\'t get the watch id on goMovies_sx');
                        }

                    }
                }
            }
        }

    }
    catch (exception $error) {

        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
        }
			logDetails($title, $url, 'n/a', $type, $movieId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
        return false;
    }
		logDetails($title, $url, 'n/a', $type, $movieId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
    return false;
}

function StreamvidExtract($url, $tSite)
{
    global $timeOut;

    $unpacker = new JavaScriptUnpacker();
    if ($GLOBALS['DEBUG']) {
        echo "Started StreamvidExtract for $tSite. </br></br>";
    }

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, 'header' =>
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0\r\n" .
            "Referer: https://" . str_replace('_', '.', strtolower($tSite)), ], ]);

        $response = @file_get_contents($url, false, $context);


        if ($response === false) {
            throw new Exception('HTTP Error: StreamvidExtract');      
        }

        if (preg_match('#\beval\(function\(p,a,c,k,e,d\).*?\)\)\)#', $response, $matches)) {

            // Use the methods of the JavaScriptUnpacker class as needed
            $unpackedCode = $unpacker->unpack($matches[0]);	
			
			if (!empty($unpackedCode) && preg_match('/(?<=src:").*?(?=")/', $unpackedCode, $matches)){
				
				$StreamvidDirect = $matches[0];				
			
				if ($GLOBALS['DEBUG']) {
					echo "Video link: " . $StreamvidDirect . "<br><br>";
				}				
									
				return $StreamvidDirect;
				
			} else {
				throw new Exception('Couldn\'t extract the unpackedCode on Streamvid');
			}

		} else {
			throw new Exception('Couldn\'t extract the source links on Streamvid');
		}

    } catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running StreamvidExtract. </br></br>';
        }
        return false;
    }
    if ($GLOBALS['DEBUG']) {
        echo 'Finished running StreamvidExtract. </br></br>';
    }
    return false;

}

function FilelionsExtract($url, $tSite)
{
    global $timeOut;

    $unpacker = new JavaScriptUnpacker();
    if ($GLOBALS['DEBUG']) {
        echo "Started FilelionsExtract for $tSite. </br></br>";
    }

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, 'header' =>
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0\r\n" .
            "Referer: https://" . str_replace('_', '.', strtolower($tSite)), ], ]);

        $response = @file_get_contents($url, false, $context);


        if ($response === false) {
            throw new Exception('HTTP Error: FilelionsExtract');      
        }

        if (preg_match('#\beval\(function\(p,a,c,k,e,d\).*?\)\)\)#', $response, $matches)) {

            // Use the methods of the JavaScriptUnpacker class as needed
            $unpackedCode = $unpacker->unpack($matches[0]);		

			
			if (!empty($unpackedCode) && preg_match('/(?<=file:").*?(?=")/', $unpackedCode, $matches)){
				
				$filelionsDirect = $matches[0];				
			
				if ($GLOBALS['DEBUG']) {
					echo "Video link: " . $filelionsDirect . "<br><br>";
				}				
									
				return $filelionsDirect;
				
			} else {
				throw new Exception('Couldn\'t extract the unpackedCode on Filelions');
			}

		} else {
			throw new Exception('Couldn\'t extract the source links on Filelions');
		}

    } catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running FilelionsExtract. </br></br>';
        }
        return false;
    }
    if ($GLOBALS['DEBUG']) {
        echo 'Finished running FilelionsExtract. </br></br>';
    }
    return false;

}

function VoeExtract($url, $tSite)
{
    global $timeOut;

    if ($GLOBALS['DEBUG']) {
        echo "Started VoeExtract for $tSite. </br></br>";
    }

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, 'header' =>
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0\r\n" .
            "Referer: https://" . str_replace('_', '.', strtolower($tSite)), ], ]);

        $response = @file_get_contents($url, false, $context);


        if ($response === false) {
            throw new Exception('HTTP Error: VoeExtract');      
        }

        if (preg_match('/(?<=prompt\("Node", ").*?(?=")/', $response, $matches)) {		
			
			$DirectLink = $matches[0];				
		
			if ($GLOBALS['DEBUG']) {
				echo "Video link: " . $DirectLink . "<br><br>";
			}				
								
			return $DirectLink;			


		} else {
			throw new Exception('Couldn\'t extract the source links on Voe');
		}

    } catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running VoeExtract. </br></br>';
        }
        return false;
    }
    if ($GLOBALS['DEBUG']) {
        echo 'Finished running VoeExtract. </br></br>';
    }
    return false;

}

function UpstreamExtract($url, $tSite)
{
    global $timeOut;

    $unpacker = new JavaScriptUnpacker();
    if ($GLOBALS['DEBUG']) {
        echo "Started UpstreamExtract for $tSite. </br></br>";
    }

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, 'header' =>
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0\r\n" .
            "Referer: https://" . str_replace('_', '.', strtolower($tSite)), ], ]);

        $response = @file_get_contents($url, false, $context);


        if ($response === false) {
            throw new Exception('HTTP Error: UpstreamExtract');
            if ($GLOBALS['DEBUG']) {
                echo 'Error: ' . $error->getMessage() . "</br></br>";
            }
        }

        if (preg_match('#\beval\(function\(p,a,c,k,e,d\).*?\)\)\)#', $response, $matches)) {

            // Use the methods of the JavaScriptUnpacker class as needed
            $unpackedCode = $unpacker->unpack($matches[0]);			


		if (preg_match('#(?<=sources:\[{file:").*?upstream.*?(?="}])#', $unpackedCode, $matches)) {
			$sourceUrl = $matches[0];

			// Check if the URL starts with 'http' indicating it's a complete URL
			if (strpos($sourceUrl, 'http') !== 0) {  // It's not a full URL, so we will try to extract the domain
				if (preg_match('#image:"(https?://[^/]+)#', $unpackedCode, $imageMatches)) {
					$domain = $imageMatches[1];
					$sourceUrl = $domain . $sourceUrl;  // Append the relative URL to the domain to form the full URL
				} else {
					throw new Exception('Couldn\'t extract the domain from image URL on Upstream');
				}
			}

			if ($GLOBALS['DEBUG']) {
				echo "Video link: " . $sourceUrl . "<br><br>";
			}
			return $sourceUrl;

		} else {
			throw new Exception('Couldn\'t extract the source links on Upstream');
		}

    }
	}
    catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running UpstreamExtract. </br></br>';
        }
        return false;
    }
    if ($GLOBALS['DEBUG']) {
        echo 'Finished running UpstreamExtract. </br></br>';
    }
    return false;

}

//Extractor for goMovies_sx
function UpCloudExtract($url, $tSite)
{
    global $timeOut;

    if ($GLOBALS['DEBUG']) {
        echo "Started UpCloudExtract for $tSite. </br></br>";
    }

    // Parse the URL
    $urlParts = parse_url($url);

    if ($urlParts !== false && isset($urlParts['path'])) {
        // Split the path into segments
        $pathSegments = explode('/', $urlParts['path']);

        // Get the last segment (id)
        $id = end($pathSegments);

        // Construct the new URL
        $outputUrl = "{$urlParts['scheme']}://{$urlParts['host']}/ajax/embed-4/getSources?id=$id";

        if ($GLOBALS['DEBUG']) {
            echo "UpCloudExtract - Output URL: $outputUrl </br></br>";
        }
    } else {

        if ($GLOBALS['DEBUG']) {
            echo "UpCloudExtract: Invalid URL for $tSite. </br></br>";
        }

        return false;
    }

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, 'header' =>
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0\r\n" .
            "X-Requested-With: XMLHttpRequest\r\n" . "Referer: https://gomovies.sx/\r\n", ], ]);

        $response = @file_get_contents($outputUrl, false, $context);

        if ($response === false) {
            throw new Exception('HTTP Error: UpCloudExtract');
        }
        if ($GLOBALS['DEBUG']) {
            print_r('UpCloudExtract Json sources: ' . $response . "</br></br>");
        }

        // Decode the JSON response into an associative array
        $data = json_decode($response, true);

        // Decode the JSON response into an associative array
        $data = json_decode($response, true);

        if ($data !== null) {
            if (isset($data['sources'])) {
                if (is_array($data['sources'])) {
                    // Handle multiple sources (an array)
                    $firstSource = $data['sources'][0]; // Get the first source from the array
                } else {
                    // Handle a single source (a string)
                    $firstSource = $data['sources']; // The entire source is a single string
                }

                $getKeyset = extractUpCloudKey();				
				
				
				if ($response === false) {
					throw new Exception('HTTP Error: Couldn\'t get decryption key.');
				}

                return decryptUpcloudSource($firstSource, $getKeyset);
            } else {
                if ($GLOBALS['DEBUG']) {
                    echo "Error: 'sources' key not found. </br></br>";
                }
                return false;
            }
        } else {
            if ($GLOBALS['DEBUG']) {
                echo "Error: Invalid JSON. </br></br>";
            }
            return false;
        }
    }
    catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running UpCloudExtract. </br></br>';
        }
        return false;
    }

	return false;
}

function thepiratebay_org($movieId, $imdbId, $title, $year)
{
    global $timeOut, $maxResolution, $torrentData, $language, $languageMapping, $type, $season, $episode;

    $tSite = 'thepiratebay_org';
	
	if ($GLOBALS['DEBUG']) {
        echo 'Started running thepiratebay_org </br></br>';
    }
	   $key = $movieId . '_thepiratebay';
	   
$thepiratebay = [
    "name" => "The Pirate Bay",
    "enabled" => true,
    "languages" => ["en"],
    "base_url" => "https://apibay.org",
    "fallback_urls" => [],
    "response_type" => "json",
    "owner" => "Aki0782",
    "movie" => [
        "query" => "/q.php?q={query}&cat=207,202,201",
        "keywords" => "{title} {year}"
    ],
    "episode" => [
        "query" => "/q.php?q={query}&cat=208,205",
        "keywords" => [
            "{title} {episodeCode}"
        ]
    ],
    "season" => [
        "query" => "/q.php?q={query}&cat=208,205",
        "keywords" => [
            "{title} {seasonCode}",
            "{title} season"
        ]
    ],
    "json_format" => [
        "title" => "name",
        "seeds" => "seeders",
        "peers" => "leechers",
        "size" => "size",
        "hash" => "info_hash"
    ],
    "title_replacement" => [
        "'s" => "s",
        "\"" => ""
    ]
];

$base_url = $thepiratebay["base_url"];

if ($type == 'movies') {
    $searchQuery = str_replace("{title} {year}", $title . " " . $year, $thepiratebay['movie']['keywords']);
    $apiUrl = $base_url . str_replace("{query}", $searchQuery, $thepiratebay['movie']['query']);
} else if ($type == 'series') {
    $searchQuery = str_replace("{title} {episodeCode}", $title, $thepiratebay['episode']['keywords'][0]);
    $apiUrl = $base_url . str_replace("{query}", $searchQuery, $thepiratebay['episode']['query']);
}

try {
    $context = stream_context_create(['http' => ['timeout' => $timeOut, ], ]);
    $response = @file_get_contents($apiUrl, false, $context);

    if ($response === false) {
        throw new Exception('HTTP Error: thepiratebay');
    }

}
catch (exception $error) {
    if ($GLOBALS['DEBUG']) {
        echo 'Error: ' . $error->getMessage() . "</br></br>";
    }

    return false;
}

// Assuming the response type for thepiratebay is always JSON
$data = json_decode($response, true);

try {
    foreach ($data as $torrent) {
		
        $matchedRes = $torrent[$thepiratebay['json_format']['title']];
        $matchedHash = $torrent[$thepiratebay['json_format']['hash']];

        // Here you might want to extract resolution like 1080p, 720p etc. from the title similar to before
        preg_match('/(2160|1080|720|480|360|240)[pP]/i', $matchedRes, $resolution);
		
		// If resolution wasn't found, set it to 480p
		if (!$resolution) {
			$resolution[0] = '480p';
		}

        if (isset($resolution[0])) {
            if ($GLOBALS['DEBUG']) {
                echo "matchedRes: " . $resolution[0] . "</br></br>";
                echo "matchedHash: " . $matchedHash . "</br></br>";
            }
			$torrentData[] = ['title_long' => $GLOBALS['globalTitle'], 'hash' => $matchedHash, 'quality' => $resolution[0]];			
			
        }
    }	

    return true;
}
catch (exception $error) {
    if ($GLOBALS['DEBUG']) {
        echo 'Error: ' . $error->getMessage() . "</br></br>";
    }

    return false;
}



}

//Decryption for UpCloudExtract
function decryptUpcloudSource($encryptedString, $keySet)
{

    try { 
		
        $ch = curl_init();

        $url = "https://script.google.com/macros/s/AKfycbx5yZILYCNrg2gHFtzHxryKXyr6OKoUWdAKeoqnAUKc4JUWwBvMm5ZsbluqdEOsBVnb9A/exec?keyset=" . urlencode($keySet) . "&text=" . urlencode($encryptedString);		


        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

        $response = curl_exec($ch);

        if ($response === false) {
            throw new Exception("Curl error: " . curl_error($ch));
        }

        curl_close($ch);

        // Parse the JSON response to extract the file URL
        $data = json_decode($response, true);

        if ($data !== null && isset($data[0]['file'])) {
            // Extract the 'file' URL from the first element of the array
            $fileURL = $data[0]['file'];

            return $fileURL;
        } else {
            throw new Exception("Invalid JSON or 'file' key not found in response.");
        }
    }
    catch (exception $error) {
        // Handle the exception here
        echo "Error: " . $error->getMessage();
        return false;
    }
}

function upMovies_to($title, $year)
{
    if ($GLOBALS['DEBUG']) {
        echo 'Started running upMovies_to </br></br>';
    }
	global $timeOut, $maxResolution, $type, $seasonNoPad, $episodeNoPad, $movieId;
	
    $tSite = 'upMovies_to';

    $etitle = str_replace("%20", "+", urlencode($title));   
	
	if ($type == 'movies'){
		$searchQuery = $title . ' (' . $year . ')';
	} else {
		$searchQuery = $title . ' ' . $year . ' season ' . $seasonNoPad;	
	
	}
	
	$searchQuery = str_replace("%20", "+", urlencode($searchQuery));
	$apiUrl = 'https://upmovies.to/search-movies/' . $searchQuery . '.html';
	

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, 'header' =>
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0', ], ]);

        $response = @file_get_contents($apiUrl, false, $context);

        if ($response === false) {
            throw new Exception('HTTP Error: upMovies_to');
        }

    }
    catch (exception $error) {

        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
        }
			logDetails($title, $apiUrl, 'n/a', $type, $movieId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
        return false;
    }

    try {
        // Perform pattern matching to extract movie data
        preg_match('/https:\/\/upmovies\.to\/watch.*?.html/', $response, $matches);

        if (empty($matches)) {
            throw new Exception("No links found on upMovies_to."); // Throw a custom exception
        }

        $response = @file_get_contents($matches[0], false, $context);
		
		if ($response === false) {
            throw new Exception('HTTP Error: upMovies_to');
        }
		
		if ($type == 'series' && preg_match('/(?<=href=")[^"]*?episode-'.$episodeNoPad.'\.html(?=")/s', $response, $matches)){
			$response = @file_get_contents($matches[0], false, $context);
			
		}	else {
			throw new Exception('Couldn\'t locate the episode page on upMovies_to.');
		}


        $extractionFound = false;
        // Perform the regex match
        preg_match_all('/<div class="server_line.*?<\/div>/s', $response, $matches);

        foreach ($matches[0] as $divBlock) {
            // Check if the div block contains the string "ePlayVid"
            if ($GLOBALS['DEBUG']) {
                echo "Looking for a match in div: " . $divBlock . "</br></br>";
            }
            if (strpos($divBlock, 'ePlayVid') !== false) {
                // Define a regex pattern to extract the href URL
                $urlPattern = '/(?<=<a href=")([^"]+)(?=")/';

                if (preg_match($urlPattern, $divBlock, $urlMatches)) {
                    if ($GLOBALS['DEBUG']) {
                        echo 'Page containing ePlayVid: ' . $urlMatches[1] . "</br></br>";

                    }
                    $extractionFound = 'ePlayVid';

                }


            }
            if (strpos($divBlock, 'UpStream') !== false) {
                // Define a regex pattern to extract the href URL
                $urlPattern = '/(?<=<a href=")([^"]+)(?=")/';

                if (preg_match($urlPattern, $divBlock, $urlMatches)) {
                    if ($GLOBALS['DEBUG']) {
                        echo 'Page containing UpStream: ' . $urlMatches[1] . "</br></br>";

                    }
                    $extractionFound = 'UpStream';

                }
			}   
			if (strpos($divBlock, 'FileLions') !== false) {
			// Define a regex pattern to extract the href URL
			$urlPattern = '/(?<=<a href=")([^"]+)(?=")/';

				if (preg_match($urlPattern, $divBlock, $urlMatches)) {
					if ($GLOBALS['DEBUG']) {
						echo 'Page containing FileLions: ' . $urlMatches[1] . "</br></br>";

					}
					$extractionFound = 'FileLions';

				}


            }	
            
            //Loop through links trying to find one.
            if ($extractionFound === false) {

            } elseif ($extractionFound === 'ePlayVid') {
				$srcUrl = decode64UpMovies($urlMatches[1]);
				if ($srcUrl !== false){
				   $extractorReturn = ePlayVidExtract($srcUrl);
				if ($extractorReturn !== false) {
						logDetails($title, $apiUrl, $extractorReturn, $type, $movieId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');					
                    return $extractorReturn;
                }
				}   

            } elseif ($extractionFound === 'UpStream') {
				
				$srcUrl = decode64UpMovies($urlMatches[1]);
				if ($srcUrl !== false){
				   $extractorReturn = UpstreamExtract($srcUrl, 'upMovies_to');
				if ($extractorReturn !== false) {
						logDetails($title, $apiUrl, $extractorReturn, $type, $movieId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');						
                    return $extractorReturn;
                }
				}   
		
            } elseif ($extractionFound === 'FileLions') {
				
				$srcUrl = decode64UpMovies($urlMatches[1]);
				if ($srcUrl !== false){
					
				   $extractorReturn = FilelionsExtract($srcUrl, 'upMovies_to');
				if ($extractorReturn !== false) {
						logDetails($title, $apiUrl, $extractorReturn, $type, $movieId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');						
                    return $extractorReturn;
                }
				}   
		
            }

        }


    }
    catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo "Couldn't locate an extractor for upMovies_to. </br></br>";
        }
			logDetails($title, $apiUrl, 'n/a', $type, $movieId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');		
        return false;
    }
    if ($GLOBALS['DEBUG']) {
        echo "Couldn't locate a link on upMovies_to. </br></br>";
    }
	logDetails($title, $apiUrl, 'n/a', $type, $movieId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');		
	return false;
}
//Base64 Decode for upMovies_to
function decode64UpMovies($url) {
	global $timeOut;
    try {
        $context = stream_context_create([
            'http' => [
                'timeout' => $timeOut, 
                'header' => 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0',
            ], 
        ]);

        $response = @file_get_contents($url, false, $context);

        // Check if the request was successful
        if ($response === false) {
            throw new Exception("Failed to fetch the URL: $url");
        }

        preg_match('#(?<=document\.write\(Base64\.decode\(").*?(?=")#', $response, $matches);

        if (isset($matches[0])) {
            $iframe = base64_decode($matches[0]);
            if (preg_match('#(?<=src=").*?(?=")#', $iframe, $iframeMatches)) {
                return $iframeMatches[0];
            }
        }

        throw new Exception("Couldn't find url in decoded base64 on page.");

    } catch (Exception $e) {        
        return false; // or return "Error: " . $e->getMessage();
    }
}

//Extractor for upMovies_to
function ePlayVidExtract($url)
{
    global $timeOut;

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, 'header' =>
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0', ], ]);

        $response = @file_get_contents($url, false, $context);

        if ($response === false) {
            throw new Exception('HTTP Error: eplayvidExtact');
            if ($GLOBALS['DEBUG']) {
                echo 'Error: ' . $error->getMessage() . "</br></br>";
            }
        }

        if (preg_match('#(?<=<source src=")[\s\S]*?(?=")#', $response, $matches)) {

            if ($GLOBALS['DEBUG']) {
                echo "Video link: " . $matches[0] . "<br><br>";
            }
			//Run link checker before returning.
			$urlData = $matches[0] .
                "|Referer='https://eplayvid.net/'|User-Agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0'|Origin='https://eplayvid.net/'";
				
			$lCheck = checkLinkStatusCode($urlData);
			if ($lCheck == true){
				return 'video_proxy.php?data=' . base64_encode($urlData);
			} else {
				return false;
			}
			
						
        }


    }
    catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running ePlayVid. </br></br>';
        }
        return false;
    }

    return false;

}

function popcornTime($movieId, $imdbId, $title)
{
    global $timeOut, $maxResolution, $torrentData, $type, $season, $episode;
    $tSite = 'popcornTime';

    if ($GLOBALS['DEBUG']) {
        echo 'Started running popcornTime </br></br>';
    }

	 if ($type == 'movies'){
		$apiUrl = 'https://shows.cf/movie/' . $imdbId;		
	 } else {
		$apiUrl = 'https://shows.cf/show/' . $imdbId;
	 }

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut]]);
        $response = @file_get_contents($apiUrl, false, $context);

        if ($response === false) {
            throw new Exception('HTTP Error: popcornTime');
        }

        $data = json_decode($response, true);
		
		if ($type == 'series'){
		//Run for series.
		$filtered = array_filter($data['episodes'], function ($ep) use ($season, $episode) {
        return $ep['season'] == $season && $ep['episode'] == $episode;});
		$torrents = current($filtered)['torrents'] ?? null;		

		} else {

		//Run for movies.
        if (!isset($data['torrents'])) {
            throw new Exception('Data does not meet criteria');
        }

        if ($GLOBALS['DEBUG']) {
            echo 'The Json Response: ' . print_r($response) . '</br></br>';
        }

        // Extract the torrents array
        		
		if (isset($data['torrents']['en'])) {
			$torrents = $data['torrents']['en'];
			
		} else {
			
		if ($GLOBALS['DEBUG']) {
            echo 'Couldn\'t locate any torrents on popcornTime. </br></br>';
        }

		return false;
		}
		}
        		
		// Loop through each torrent available
		if (is_array($torrents) && !empty($torrents)) {
			foreach ($torrents as $resolutionKey => $torrentInfo) {
				
				preg_match('/(?<=urn:btih:)([A-F|a-z\d]{40})/', $torrentInfo['url'], $matchedHash);

				// Check if the regex match was successful
				if (isset($matchedHash[0])) {
					$torrentData[] = [
						'title_long' => $GLOBALS['globalTitle'],
						'hash' => $matchedHash[0],
						'quality' => $resolutionKey
					];
				}
			}
		} else {
			throw new Exception('Data does not meet criteria');
		}
        if ($GLOBALS['DEBUG']) {
            echo 'Torrents: ' . json_encode($torrentData) . "</br></br>";
        }

        return true;

    }
    catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running popcornTime </br></br>';
        }
	
        return false;
    }
}
function theMovieArchive_site($movieId, $title)
{
    global $timeOut, $movieId, $type;

    if ($GLOBALS['DEBUG']) {
        echo 'Started running theMovieArchive_site </br></br>';
    }

    $url = "https://prod.omega.themoviearchive.site/v3/movie/sources/" . $movieId;
    $options = ['http' => ['method' => "GET", 'header' =>
        "Content-Type: application/json"]];

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut]]);
        $response = @file_get_contents($url, false, $context);
        if ($response === false) {
            throw new Exception('HTTP Error: theMovieArchive_site</br></br>');
        }
    }
    catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Failed to fetch movie source data from theMovieArchive_site Error: ' . $error->
                getMessage() . "</br></br>";
            echo 'Finished running theMovieArchive_site </br></br>';

        }
			logDetails($title, $url, 'n/a', 'movie', $movieId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
        return false;
    }

    $statusCode = http_response_code(); // Get the current response status code
    if ($statusCode !== 200) {
        if ($GLOBALS['DEBUG']) {
            echo "Failed to fetch movie source data from theMovieArchive_site Response code: " .
                $statusCode . "<br></br>";
            echo 'Finished running theMovieArchive_site </br></br>';
        }
			logDetails($title, $url, 'n/a', 'movie', $movieId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
        return false;
    }

    $data = json_decode($response, true);

    if ($data && isset($data['sources'])) {
        $foundUrl = false;
        // Define the qualities to check
        $qualitiesToCheck = ['2160', '1080', '720', 'auto'];

        foreach ($data['sources'] as $source) {
            foreach ($source['sources'] as $videoSource) {
                $quality = $videoSource['quality'];
                $vurl = $videoSource['url'];

                if (in_array($quality, $qualitiesToCheck)) {

                    if ($GLOBALS['DEBUG']) {
                        echo 'Video Link: ' . $vurl . "</br></br>";

                    }
						logDetails($title, $url, $vurl, $type, $movieId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');					
                    return $vurl;


                }
            }
        }

        if ($GLOBALS['DEBUG']) {
            echo "No suitable URL found. </br></br>";
        }
        echo 'Finished running theMovieArchive_site </br></br>';
			logDetails($title, $url, 'n/a', 'movie', $movieId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');			
        return false;
    } else {

        if ($GLOBALS['DEBUG']) {
            echo "No sources found in the JSON data.";
        }
        echo 'Finished running theMovieArchive_site </br></br>';
			logDetails($title, $url, 'n/a', 'movie', $movieId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');		
        return false;
    }
}

function torrentGalaxy_to($movieId, $imdbId, $title)
{
    global $timeOut, $maxResolution, $torrentData, $language, $languageMapping, $type, $season, $episode;

    $tSite = 'Torrent Galaxy';
	
	if ($GLOBALS['DEBUG']) {
        echo 'Started running torrentGalaxy_to </br></br>';
    }
	
    $key = $movieId . '_torrentGalaxy_to';
	if ($type == 'movies'){
		$searchQuery = $imdbId;
	} else {
		$searchQuery = preg_replace('/[^a-zA-Z0-9 ]/', '', $title);
	}
	
    $siteLanguage = $languageMapping['TorrentGalaxy'][$language] ?? null;	

	$apiUrl = 'https://torrentgalaxy.to/torrents.php?search=' . $searchQuery . '&nox=2';	

	if ($siteLanguage !== null) {
		$apiUrl .= '&lang=' . $siteLanguage;
	}

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, ], ]);
        $response = @file_get_contents($apiUrl, false, $context);

        if ($response === false) {
            throw new Exception('HTTP Error: torrentGalaxy_to');
        }


    }
    catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
        }

        return false;
    }

    $data = $response;
	

    try {
        // Perform pattern matching to extract torrent data
        preg_match_all('/(?<=tgxtablerow)[\s\S]*?(?=<\/table>)/', $data, $matches);

        if (count($matches[0]) === 0) {
            throw new Exception("No links found on torrentGalaxy_to."); // Throw a custom exception
        }


        // Loop through the 'matches' array
        for ($i = 0; $i < count($matches[0]); $i++) {

            // Extracted data from 'matches'
            $extractedData = $matches[0][$i];

			// Replace '4K' or '4k' with '2160p' before extracting the resolution
			$extractedData = str_ireplace("4K", "2160p", $extractedData);

            // Apply the regex patterns to extract 'matchedRes' and 'matchedHash'
            preg_match('/(2160|1080|720|480|360|240)[pP]/i', $extractedData, $matchedRes);
            preg_match('/(?<=urn:btih:)([A-F|a-z\d]{40})/', $extractedData, $matchedHash);
			
			// If matchedRes wasn't found, set it to 480p
			if (!$matchedRes) {
				$matchedRes[0] = '480p';
			}
			
            // Check if both 'matchedRes' and 'matchedHash' were found
            if ($matchedRes && $matchedRes[0] && $matchedHash && $matchedHash[0]) {
                if ($GLOBALS['DEBUG']) {
                    echo "matchedRes: " . $matchedRes[0] . "</br></br>";
                    echo "matchedHash: " . $matchedHash[0] . "</br></br>";
                }				
								
				$torrentData[] = ['title_long' => $GLOBALS['globalTitle'], 'hash' => $matchedHash[0], 'quality' => $matchedRes[0]];

            }
        }

        return true;
    }
    catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running torrentGalaxy_to </br></br>';
        }

        return false;
    }
}

function smashyStream_com($movieId, $imdbId, $title)
{
    global $timeOut, $maxResolution, $type, $seasonNoPad, $episodeNoPad;

    $tSite = 'Smashy Stream';
	
	if ($GLOBALS['DEBUG']) {
        echo 'Started running smashyStream_com </br></br>';
    }	

	if ($type == 'movies'){
		$searchQuery = $movieId;
	} else {
		$searchQuery = $movieId . '&season=' . $seasonNoPad . '&episode=' . $episodeNoPad;
	}

	$apiUrl = "https://embed.smashystream.com/playere.php?tmdb=$searchQuery";	
	
	try {
		
				$contextOptions = [
			'http' => [
				'method' => "GET",
				'header' => "Accept-Language: en-US,en;q=0.5\r\n" .	
							"Accept: application/json, text/javascript, */*; q=0.01\r\n" .
							"X-Requested-With: XMLHttpRequest\r\n" .							
							"User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/119.0\r\n" .
							"Referer: $apiUrl\r\n",
				'timeout' => $timeOut,
			]
		];		
				
		$context = stream_context_create($contextOptions);
		$response = file_get_contents($apiUrl, false, $context);
		
		if ($response === false) {
            throw new Exception('HTTP Error: smashyStream_com');
		}				

		if(!preg_match_all('/(?<=data-url=")htt.*?tmdb\=/', $response, $urlMatches)){	
		 
			throw new Exception("No links found on smashyStream_com.");		
			
		 }		
		 
		$firstSourceUrl = null;
		
		if (!empty($urlMatches) && is_array($urlMatches[0])) {
			foreach ($urlMatches[0] as $apiUrl) {				

				if ($type == 'movies'){
					$apiUrl = $apiUrl . $movieId;
				} else {
					$apiUrl = $apiUrl . $movieId . '&season=' . $seasonNoPad . '&episode=' . $episodeNoPad;
				}

				$context = stream_context_create($contextOptions);
				$response = @file_get_contents($apiUrl, false, $context);
				

				if ($response !== false) {
					$jsonArray = json_decode($response, true);
					if (isset($jsonArray['sourceUrls']) && is_array($jsonArray['sourceUrls']) && !empty($jsonArray['sourceUrls'][0])) {

						$firstSourceUrl = $jsonArray['sourceUrls'][0];	
						
						if ($GLOBALS['DEBUG']) {
							echo "Video link: " . $firstSourceUrl . "<br><br>";
						}						
						break;
					}
				}	

			}
			
		} else {
			throw new Exception("No links found on smashyStream_com.");
		}	

        
        if(!$firstSourceUrl){
			throw new Exception("No links found on smashyStream_com.");
		} 		
			logDetails($title, $apiUrl, $firstSourceUrl, $type, $imdbId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');      
        return $firstSourceUrl;
  
    } catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running smashyStream_com </br></br>';
        }
			logDetails($title, 'n/a', 'n/a', $type, $imdbId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
        return false;
    }
}

function glodls_to($movieId, $imdbId, $title, $year)
{
    global $timeOut, $maxResolution, $torrentData, $language, $languageMapping, $type, $season, $episode;

    $tSite = 'glodls_to';
	
	if($type == "movies"){
		$searchQuery = preg_replace('/[^a-zA-Z0-9 ]/', '', $title . ' ' . $year);
	} else {
		$searchQuery = preg_replace('/[^a-zA-Z0-9 ]/', '', $title);
	}

	if ($GLOBALS['DEBUG']) {
        echo 'Started running glodls_to </br></br>';
    }
	
    $key = $movieId . '_glodls_to';
	
    $siteLanguage = $languageMapping['Glodls'][$language] ?? null;	

	$apiUrl = 'https://glodls.to/search_results.php?search=' . urlencode($searchQuery) . '&incldead=0&inclexternal=0&sort=id&order=desc';	
	

	if ($siteLanguage !== null) {
		$apiUrl .= '&lang=' . $siteLanguage;
	}
	if ($type == 'series') {
			
		$apiUrl .= '&cat=41';
	} elseif ($type == 'movies') {
			
		$apiUrl .= '&c52=1';
	}
	
	$maxAttempts = 3;
	$attempts = 0;
	$context = stream_context_create(['http' => ['timeout' => $timeOut]]);

	while ($attempts < $maxAttempts) {
		try {
			$response = @file_get_contents($apiUrl, false, $context);

			if ($response === false) {
				throw new Exception('HTTP Error: glodls_to');
			}

			// If we got the response, break out of the loop.
			break;

		} catch (Exception $error) {
			$attempts++;

			if ($GLOBALS['DEBUG']) {
				echo 'Attempt ' . $attempts . ': ' . $error->getMessage() . "<br>";
			}

			// Sleep for a bit before retrying
			sleep(1);

			if ($attempts === $maxAttempts) {
				if ($GLOBALS['DEBUG']) {
					echo 'Max attempts reached, failing...' . "<br>";
				}

				return false;
			}
		}
	}

    $data = $response;

    try {
        // Perform pattern matching to extract torrent data
        preg_match_all('/(?<=ttable_col1)[\s\S]*?(?=<\/tr>)/', $data, $matches);

        if (count($matches[0]) === 0) {
            throw new Exception("No links found on glodls_to."); // Throw a custom exception
        }

         // Loop through the 'matches' array
        for ($i = 0; $i < count($matches[0]); $i++) {
			
			// Extracted data from 'matches'
            $extractedData = $matches[0][$i];		
			
			// Replace '4K' or '4k' with '2160p' before extracting the resolution
			$extractedData = str_ireplace("4K", "2160p", $extractedData);

            // Apply the regex patterns to extract 'matchedRes' and 'matchedHash'
            preg_match('/(2160|1080|720|480|360|240)[pP]/i', $extractedData, $matchedRes);
            preg_match('/(?<=urn:btih:)([A-F|a-z\d]{40})/', $extractedData, $matchedHash);
			
			// If matchedRes wasn't found, set it to 480p
			if (!$matchedRes) {
				$matchedRes[0] = '480p';
			}
			
            // Check if both 'matchedRes' and 'matchedHash' were found
            if ($matchedRes && $matchedRes[0] && $matchedHash && $matchedHash[0]) {
                if ($GLOBALS['DEBUG']) {
                    echo "matchedRes: " . $matchedRes[0] . "</br></br>";
                    echo "matchedHash: " . $matchedHash[0] . "</br></br>";
                }

			$torrentData[] = ['title_long' => $GLOBALS['globalTitle'], 'hash' => $matchedHash[0], 'quality' => $matchedRes[0]];		
			
            }
        }

        return true;
    }
    catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running glodls_to </br></br>';
        }

        return false;
    }
}

function magnetdl_com($movieId, $imdbId, $title, $year)
{
    global $timeOut, $maxResolution, $torrentData, $language, $languageMapping, $type, $season, $episode;

    $tSite = 'magnetdl_com';
	
	if ($GLOBALS['DEBUG']) {
        echo 'Started running magnetdl_com </br></br>';
    }
	
    $key = $movieId . '_magnetdl_com';
	
	$titleNoPeriods = $title;
	$titleNoPeriods = str_replace('.', ' ', $titleNoPeriods);
	if($type == "movies"){
		$searchQuery = $title . ' (' . $year . ')';
	} else {
		$searchQuery = $title;
	}
	
	$apiUrl = 'https://www.magnetdl.com/search/?q=' . $searchQuery;	

	if ($type == 'series') {
			
		$apiUrl .= '&m=1&x=35&y=17';
	} elseif ($type == 'movies') {
			
		$apiUrl .= '&m=1&x=38&y=19';
	}

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, ], ]);
        $response = @file_get_contents($apiUrl, false, $context);

        if ($response === false) {
            throw new Exception('HTTP Error: magnetdl_com');
        }


    }
    catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
        }

        return false;
    }

    $data = $response;
	

    try {
        // Perform pattern matching to extract torrent data
        preg_match_all('/(?<=class="m")[\s\S]*?(?=<\/tr>)/', $data, $matches);

        if (count($matches[0]) === 0) {
            throw new Exception("No links found on magnetdl_com."); // Throw a custom exception
        }
		
        // Loop through the 'matches' array
        for ($i = 0; $i < count($matches[0]); $i++) {

            // Extracted data from 'matches'
            $extractedData = $matches[0][$i];
			
			// Replace '4K' or '4k' with '2160p' before extracting the resolution
			$extractedData = str_ireplace("4K", "2160p", $extractedData);

            // Apply the regex patterns to extract 'matchedRes' and 'matchedHash'
            preg_match('/(2160|1080|720|480|360|240)[pP]/i', $extractedData, $matchedRes);
            preg_match('/(?<=urn:btih:)([A-F|a-z\d]{40})/', $extractedData, $matchedHash);
			
			// If matchedRes wasn't found, set it to 480p
			if (!$matchedRes) {
				$matchedRes[0] = '480p';
			}
			
            // Check if both 'matchedRes' and 'matchedHash' were found
            if ($matchedRes && $matchedRes[0] && $matchedHash && $matchedHash[0]) {
                if ($GLOBALS['DEBUG']) {
                    echo "matchedRes: " . $matchedRes[0] . "</br></br>";
                    echo "matchedHash: " . $matchedHash[0] . "</br></br>";
                }
                
                $torrentData[] = ['title_long' => $GLOBALS['globalTitle'], 'hash' => $matchedHash[0], 'quality' =>
                    $matchedRes[0]];
            }
        }

        return true;
    }
    catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running magnetdl_com </br></br>';
        }

        return false;
    }
}

function torrentDownload_info($movieId, $imdbId, $title, $year)
{
    global $timeOut, $maxResolution, $torrentData, $language, $languageMapping, $type, $season, $episode;

    $tSite = 'torrentDownload_info';
	
	if ($GLOBALS['DEBUG']) {
        echo 'Started running torrentDownload_info </br></br>';
    }
	
    $key = $movieId . '_torrentDownload_info';
	
	if($type == "movies"){
		$searchQuery = preg_replace('/[^a-zA-Z0-9 ]/', '', $title . ' ' . $year);
	} else {
		$searchQuery = preg_replace('/[^a-zA-Z0-9 ]/', '', $title);
	}

	$apiUrl = 'https://www.torrentdownload.info/search?q=' . $searchQuery;	

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, ], ]);
        $response = @file_get_contents($apiUrl, false, $context);

        if ($response === false) {
            throw new Exception('HTTP Error: torrentDownload_info');
        }


    }
    catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
        }

        return false;
    }

    $data = $response;
	

    try {
        // Perform pattern matching to extract torrent data
        preg_match_all('/(?<=<td class="tdleft">)[\s\S]*?(?=<\/tr>)/', $data, $matches);

        if (count($matches[0]) === 0) {
            throw new Exception("No links found on torrentDownload_info."); // Throw a custom exception
        }

 
        // Loop through the 'matches' array
        for ($i = 3; $i < count($matches[0]); $i++) {

            // Extracted data from 'matches'
            $extractedData = $matches[0][$i];
					
			// Replace '4K' or '4k' with '2160p' before extracting the resolution
			$extractedData = str_ireplace("4K", "2160p", $extractedData);

            // Apply the regex patterns to extract 'matchedRes' and 'matchedHash'
            preg_match('/(2160|1080|720|480|360|240)[pP]/i', $extractedData, $matchedRes);
            preg_match('/(?<="\/)([A-F|a-z\d]{40})(?=\/)/', $extractedData, $matchedHash);
			
			// If matchedRes wasn't found, set it to 480p
			if (!$matchedRes) {
				$matchedRes[0] = '480p';
			}
			
            // Check if both 'matchedRes' and 'matchedHash' were found
            if ($matchedRes && $matchedRes[0] && $matchedHash && $matchedHash[0]) {
                if ($GLOBALS['DEBUG']) {
                    echo "matchedRes: " . $matchedRes[0] . "</br></br>";
                    echo "matchedHash: " . $matchedHash[0] . "</br></br>";
                }
				
				$torrentData[] = ['title_long' => $GLOBALS['globalTitle'], 'hash' => $matchedHash[0], 'quality' => $matchedRes[0]];
            }
        }

        return true;
    }
    catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running torrentDownload_info </br></br>';
        }

        return false;
    }
}

function bitLordSearch_com($movieId, $imdbId, $title, $year)
{
    global $timeOut, $maxResolution, $torrentData, $type, $season, $episode;
    $tSite = 'bitLordSearch_com';

    if ($GLOBALS['DEBUG']) {
        echo 'Started running bitLordSearch_com </br></br>';
    }

    try {
		
			$options = [
			'http' => [
				'method' => 'GET',
				'header' => [
					'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/118.0',
					'Origin: https://bitlordsearch.com/',
					//'Connection: keep-alive',
					'Referer: https://bitlordsearch.com/',
					'Content-type: application/x-www-form-urlencoded',					
				],
				'timeout' => $timeOut
			]
		];
		
		 $apiUrl = "https://bitlordsearch.com/search";
		 if ($type == 'movies'){
			$apiUrl .= '?q='.urlencode($title . ' (' . $year . ')').'&offset=0&limit=50&filters[field]=seeds&filters[sort]=desc&filters[time]=0&filters[category]=3&filters[adult]=false&filters[risky]=false';		
		 } else {
			$apiUrl .= '?q='.urlencode($title).'&offset=0&limit=50&filters[field]=seeds&filters[sort]=desc&filters[time]=0&filters[category]=4&filters[adult]=false&filters[risky]=false';
		 }
		
		// Fetch the website content
		$context = stream_context_create($options);
		$content = @file_get_contents($apiUrl, false, $context);
		
		if ($content === false) {
            throw new Exception('HTTP Error: bitLordSearch');
        }
		
	} catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
        }

        return false;
    }
		
    $data = $content;
	

    try {
        // Perform pattern matching to extract torrent data
        preg_match_all('/(?<=<tr class="bls-row")[\s\S]*?(?=<\/tr>)/', $data, $matches);

        if (count($matches[0]) === 0) {
            throw new Exception("No links found on bitLordSearch_com."); // Throw a custom exception
        }


        // Loop through the 'matches' array
        for ($i = 0; $i < count($matches[0]); $i++) {

            // Extracted data from 'matches'
            $extractedData = $matches[0][$i];

			// Replace '4K' or '4k' with '2160p' before extracting the resolution
			$extractedData = str_ireplace("4K", "2160p", $extractedData);

            // Apply the regex patterns to extract 'matchedRes' and 'matchedHash'
            preg_match('/(2160|1080|720|480|360|240)[pP]/i', $extractedData, $matchedRes);
            preg_match('/(?<=urn:btih:)([A-F|a-z\d]{40})/', $extractedData, $matchedHash);
			
			// If matchedRes wasn't found, set it to 480p
			if (!$matchedRes) {
				$matchedRes[0] = '480p';
			}
			
            // Check if both 'matchedRes' and 'matchedHash' were found
            if ($matchedRes && $matchedRes[0] && $matchedHash && $matchedHash[0]) {
                if ($GLOBALS['DEBUG']) {
                    echo "matchedRes: " . $matchedRes[0] . "</br></br>";
                    echo "matchedHash: " . $matchedHash[0] . "</br></br>";
                }				
								
				$torrentData[] = ['title_long' => $GLOBALS['globalTitle'], 'hash' => $matchedHash[0], 'quality' => $matchedRes[0]];

            }
        }

        return true;
    }
    catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running bitLordSearch_com </br></br>';
        }

        return false;
    }		
}

function ezTV_re($movieId, $imdbId, $title)
{
    global $timeOut, $maxResolution, $torrentData, $language, $languageMapping, $type, $season, $episode;

    $tSite = 'EZTV';
	
	if ($GLOBALS['DEBUG']) {
        echo 'Started running ezTV_re </br></br>';
    }
	
    $key = $movieId . '_ezTV_re';
	
	$searchQuery = preg_replace('/[^a-zA-Z0-9 ]/', '', $title);
	
	$apiUrl = 'https://eztv.re/search/?q1=' . urlencode($searchQuery) . '&search=Search';	

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, ], ]);
        $response = @file_get_contents($apiUrl, false, $context);		
		

        if ($response === false) {
            throw new Exception('HTTP Error: ezTV_re');
        }


    }
    catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
        }
        return false;
    }

    $data = $response;

	

    try {
        // Perform pattern matching to extract torrent data
        preg_match_all('/(?<=<tr name="hover" class="forum_header_border">)[\s\S]*?(?=<\/tr>)/', $data, $matches);
		

        if (count($matches[0]) === 0) {
            throw new Exception("No links found on ezTV_re."); // Throw a custom exception
        }

        // Loop through the 'matches' array
		for ($i = 0; $i < count($matches[0]); $i++) {

			// Extracted data from 'matches'
			$extractedData = $matches[0][$i];

			// Check if extracted data contains the title, if not skip this iteration
			preg_match('/(?<=class="epinfo">).*?(?=<\/a>)/i', $extractedData, $matchedTitle);
			
			
			if (isset($matchedTitle[0])) {
				$episodeTitle = preg_replace("/[^a-z0-9 ]/", "", strtolower($matchedTitle[0]));
				$searchTitle = preg_replace("/[^a-z0-9 ]/", "", strtolower($title));

				if (strpos($episodeTitle, $searchTitle) === false) {
					continue;
				}
			}

			// Replace '4K' or '4k' with '2160p' before extracting the resolution
			$extractedData = str_ireplace("4K", "2160p", $extractedData);							

			// Apply the regex patterns to extract 'matchedRes' and 'matchedHash'
			preg_match('/(2160|1080|720|480|360|240)[pP]/i', $extractedData, $matchedRes);
			preg_match('/(?<=urn:btih:)([A-F|a-z\d]{40})/', $extractedData, $matchedHash);

			// If matchedRes wasn't found, set it to 480p
			if (!$matchedRes) {
				$matchedRes[0] = '480p';
			}
			

			// Check if 'matchedHash' was found
			if ($matchedHash && $matchedHash[0]) {
				if ($GLOBALS['DEBUG']) {
					echo "matchedRes: " . $matchedRes[0] . "</br></br>";
					echo "matchedHash: " . $matchedHash[0] . "</br></br>";
				}
				
				$torrentData[] = ['title_long' => $GLOBALS['globalTitle'], 'hash' => $matchedHash[0], 'quality' => $matchedRes[0]];
			}
		}
		if (!empty($torrentData)){
			
			
			return true;
			
		} else {
			return false;
		}
    }
    catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running ezTV_re </br></br>';
        }
        return false;
    }
}

function yts_mx($movieId, $imdbId, $title)
{
    global $timeOut, $maxResolution, $torrentData;
    $tSite = 'Yts';

    if ($GLOBALS['DEBUG']) {
        echo 'Started running yts_mx </br></br>';
    }

    $apiUrl = 'https://yts.mx/api/v2/list_movies.json?query_term=' . $imdbId .
        '&sort_by=seeds&order_by=desc';

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, ], ]);
        $response = @file_get_contents($apiUrl, false, $context);

        if ($response === false) {
            throw new Exception('HTTP Error: yts_mx');
        }

        $data = json_decode($response, true);

        if (!isset($data['status']) || $data['status'] !== 'ok' || !isset($data['data']) ||
            !isset($data['data']['movies']) || count($data['data']['movies']) === 0) {
            throw new Exception('Data does not meet criteria');
        }


    }
    catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Finished running yts_mx </br></br>';
            echo 'Error: ' . $error->getMessage() . "</br></br>";
        }
        return false;
    }


	try {
		$movie = $data['data']['movies'][0];
		$torrents = $movie['torrents'];

		// Loop through each torrent entry
		foreach ($torrents as $torrent) {
			if (!isset($torrent['hash'])) {
				// Skip this torrent if it doesn't have a hash
				continue;
			}
			
			$quality = $torrent['quality'] ?? '1080';
			
			$torrentData[] = [
				'title_long' => $GLOBALS['globalTitle'],
				'hash' => $torrent['hash'],
				'quality' => $quality
			];
		}

		if ($GLOBALS['DEBUG']) {
			echo 'Torrents: ' . json_encode($torrentData) . "</br></br>";
		}	
        
        return true;

    }
    catch (exception $error) {
        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running yts_mx </br></br>';
        }
        return false;
    }
}

function shegu_net_links($title, $year)
{
    if ($GLOBALS['DEBUG']) {
        echo 'Started running shegu_net_links </br></br>';
    }

    global $maxResolution, $type, $seasonNoPad, $episodeNoPad, $movieId;
    $movieIdShe = null; // Initialize $movieIdShe to null

    // Define constants
    $iv = base64_decode("d0VpcGhUbiE=");
    $key = base64_decode("MTIzZDZjZWRmNjI2ZHk1NDIzM2FhMXc2");
    $urls = [base64_decode("aHR0cHM6Ly9zaG93Ym94LnNoZWd1Lm5ldC9hcGkvYXBpX2NsaWVudC9pbmRleC8="),
        base64_decode("aHR0cHM6Ly9tYnBhcGkuc2hlZ3UubmV0L2FwaS9hcGlfY2xpZW50L2luZGV4Lw=="), ];
    $appName = base64_decode("bW92aWVib3g=");
    $appId = base64_decode("Y29tLnRkby5zaG93Ym94");

    $searchParams = ["module" => "Search3", "page" => "1", "type" => "all",
        "keyword" => $title, "pagelimit" => "20",
        ];

    $searchResponse = shegu_net_request($searchParams, false);

    if (isset($searchResponse['msg']) && $searchResponse['msg'] ===
        'no search result') {
        if ($GLOBALS['DEBUG']) {
            echo 'Search shegu_net_request Response: </br></br>';
            print_r($searchResponse);
            echo '</br></br>';
            echo 'Finished running shegu_net_links </br></br>';

        }
			logDetails($title, 'n/a', 'n/a', $type, $movieId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
        return false;
    }

    if ($GLOBALS['DEBUG']) {
        echo 'Search shegu_net_request Response: </br></br>';
        print_r($searchResponse);
        echo "</br></br>";
    }

    foreach ($searchResponse['data'] as $movie) {
        if ($movie['year'] == $year) {
            $movieIdShe = $movie['id'];
            break; // exit the loop once the correct year is found
        }
    }

    if ($movieIdShe !== null) {
        // $movieIdShe contains the id of the movie with the matching year
        if ($GLOBALS['DEBUG']) {
            echo "Movie ID: " . $movieIdShe . '</br></br>';
        }
    } else {
        if ($GLOBALS['DEBUG']) {
            echo "No movie found for the specified year.</br></br>";
            echo 'Finished running shegu_net_links </br></br>';
        }
			logDetails($title, 'n/a', 'n/a', $type, $movieId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');		
        return false;
    }

if ($type == 'movies'){
    // Call the sub-function again to get the download URLs using the movie ID
$urlParams = [
    "module" => "Movie_downloadurl_v3",
    "mid"    => $movieIdShe,
    "oss"    => "1",
    "group"  => "",
    // ...
];

} else {
	  // Call the sub-function again to get the download URLs using the tv ID
$urlParams = [
    "module"  => "TV_downloadurl_v3",
    "tid"     => $movieIdShe,
    "season"  => $seasonNoPad,
    "episode" => $episodeNoPad,
    "oss"     => "1",
    "group"   => ""
];

}
		
		
    $urlResponse = shegu_net_request($urlParams, false);


    // Process the URLs and return the appropriate one based on $maxResolution
    if (isset($urlResponse['data']['list'])) {

        $urls = $urlResponse['data']['list'];
        if ($GLOBALS['DEBUG']) {
            echo 'Get Links shegu_net_request Response: </br></br>';
            print_r($urlResponse);
            echo "</br><br>";
        }

    } else {
        if ($GLOBALS['DEBUG']) {
            echo 'Failed to get links from shegu_net_request. </br></br>';
            echo 'Finished running shegu_net_links </br></br>';
        }
			logDetails($title, 'n/a', 'n/a', $type, $movieId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');	
        return false;
    }
    function convertQualityToInt($quality)
    {
        // If the quality is '4K', return 2160
        if (strtolower($quality) == '4k') {
            return 2160;
        }

        // Remove the 'p' or 'P' character and convert the remaining string to an integer
        return intval(str_ireplace('p', '', $quality));
    }

    // Initialize variables
    $closestDifference = PHP_INT_MAX;
    $closestQuality = null;
    $closestMovie = null;

    // Loop through the array of movies
    foreach ($urls as $movie) {

        if (empty($movie['path'])) {
            continue;
        }

        // Convert the real_quality value to an integer for comparison
        $realQuality = convertQualityToInt($movie['real_quality']);

        // Calculate the difference between the real_quality and the maxResolution
        $difference = abs($realQuality - $maxResolution);

        if ($GLOBALS['DEBUG']) {
            echo "Movie video path: " . $movie['path'] . "<br><br>";
        }

        // Check if this movie is a closer match than the previous closest match
        if ($difference < $closestDifference) {
            $closestQuality = $realQuality;
            $closestDifference = $difference;
            $closestMovie = $movie;
        }
    }

    // Check if a closest match was found
    if ($closestMovie !== null) {
        // $closestMovie contains the movie version with the closest available quality

        if ($GLOBALS['DEBUG']) {
            echo "Closest Quality: " . $closestQuality . "</br><br>";
            echo "Movie Path: " . $closestMovie['path'] . "</br><br>";

        }

    } else {
        if ($GLOBALS['DEBUG']) {
            echo "No movie found with the closest quality.</br><br>";
        }
    }

    if (isset($closestMovie['path'])) {
			logDetails($title, 'n/a', $closestMovie['path'], $type, $movieId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');	
        return $closestMovie['path'];
    } else {
        if ($GLOBALS['DEBUG']) {
            echo 'Finished running shegu_net_links </br></br>';

        }
			logDetails($title, 'n/a', 'n/a', $type, $movieId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');			
        return false;
    }
}

function shegu_net_request($data, $useSecondUrl = false)
{
    global $timeOut;
    // Define constants
    $iv = base64_decode("d0VpcGhUbiE=");
    $key = base64_decode("MTIzZDZjZWRmNjI2ZHk1NDIzM2FhMXc2");
    $urls = [base64_decode("aHR0cHM6Ly9zaG93Ym94LnNoZWd1Lm5ldC9hcGkvYXBpX2NsaWVudC9pbmRleC8="),
        base64_decode("aHR0cHM6Ly9tYnBhcGkuc2hlZ3UubmV0L2FwaS9hcGlfY2xpZW50L2luZGV4Lw=="), ];
    $appName = base64_decode("bW92aWVib3g=");
    $appId = base64_decode("Y29tLnRkby5zaG93Ym94");

    // Helper function to encrypt data using 3DES
    $encrypt = function ($data, $key, $iv)
    {
        return openssl_encrypt($data, 'des-ede3-cbc', $key, 0, $iv);
    }
    ;

    // Helper function to get verify token
    $getVerify = function ($encryptedData, $appName, $key)
    {
        return $encryptedData ? md5(md5($appName) . $key . $encryptedData) : null;
    }
    ;

    // Helper function to get the current timestamp plus 12 hours
    $getExpiredDate = function ()
    {
        return time() + 60 * 60 * 12;
    }
    ;

    // Define request parameters
    $params = ["childmode" => "0", "app_version" => "11.5", "appid" => $appId,
        "lang" => "en", "expired_date" => (string )time() + 60 * 60 * 12, "platform" =>
        "android", "channel" => "Website", "uid" => "", // ... (other parameters)
        ];

    // Merge input data with default parameters
    $requestData = array_merge($params, $data);

    // Encrypt the request data
    $encryptedData = $encrypt(json_encode($requestData), $key, $iv);

    // Get the app_key and verify token
    $appKey = md5($appName);
    $verify = $getVerify($encryptedData, $appName, $key);

    // Base64 encode the payload
    $payload = base64_encode(json_encode(['app_key' => $appKey, 'verify' => $verify,
        'encrypt_data' => $encryptedData]));

    // Choose the URL based on the $useSecondUrl flag
    $url = $useSecondUrl ? $urls[1] : $urls[0];

    // Define additional parameters to be sent in the request body
    $bodyParams = ['data' => $payload, 'appid' => '27', 'platform' => 'android',
        'version' => '129', 'medium' => 'Website', ];

    // Initialize cURL session
    $ch = curl_init($url);

    // Set cURL options
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($bodyParams));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Platform: android',
        'Content-Type: application/x-www-form-urlencoded', ]);
    curl_setopt($ch, CURLOPT_REFERER, 'https://movie-web.app');
    // Execute cURL session and get the response
    $timeoutSeconds = $timeOut; // Adjust this value as needed
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeoutSeconds);
    // Set a timeout for the connection phase (in seconds)
    $connectTimeoutSeconds = $timeOut; // Adjust this value as needed
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $connectTimeoutSeconds);
    $response = curl_exec($ch);

    // Check for cURL errors and handle them
    if (curl_errno($ch)) {
        $errorMessage = 'cURL Error: ' . curl_error($ch);
        if ($GLOBALS['DEBUG']) {
            echo $errorMessage . "<br>";
        }
        throw new Exception($errorMessage);
    }

    // Close cURL session
    curl_close($ch);

    // Check for response errors and handle them
    if (!$response) {
        $errorMessage = 'HTTP Error: Failed to fetch movie source data.';
        if ($GLOBALS['DEBUG']) {
            echo $errorMessage . "<br>";
        }
        throw new Exception($errorMessage);
    }

    // Return the response
    return json_decode($response, true);
}

function superEmbed_stream($imdbId, $title, $year)
{
	    global $timeOut, $maxResolution, $type, $seasonNoPad, $episodeNoPad;
		
    if ($GLOBALS['DEBUG']) {
        echo 'Started running superEmbed_stream </br></br>';
    }
    global $timeOut;
    global $maxResolution;
    $tSite = 'superEmbed_stream';
	
	//$url = "https://multiembed.mov/directstream.php?video_id=" . $imdbId;
	$url = "https://multiembed.mov/?video_id=" . $imdbId;

	if ($type != "movies") {
		$url .= "&s=" . $seasonNoPad . "&e=" . $episodeNoPad;
	}

    try {
		$options = [
			'http' => [
				'method' => "GET",
				'header' => "Referer: https://streambucket.net/\r\n" .
							"User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/118.0\r\n",
				'timeout' => $timeOut,
			]
		];
		$context = stream_context_create($options);

		$content = @file_get_contents($url, false, $context);	
		

		if (preg_match('/(?<=decodeURIComponent\(escape\(r\)\))[\s\S]*?\)/', $content, $matches)) {
			
			$extractedString = $matches[0];
			
			if ($GLOBALS['DEBUG']) {
				echo 'Encrypted data extracted: ' . $extractedString . "</br></br>";
			}

		if (preg_match('/\((.*)\)/', $extractedString, $matches)) {
			
			$extracted = str_getcsv($matches[1]);

			$decryptedData = superEmbedDecodeString($extracted[0], $extracted[2], $extracted[1], $extracted[3], $extracted[4]);
			if (preg_match('/(?<=file:").*?(?=")/', $decryptedData, $matches)) {
				
				logDetails($title, $url, isset($matches[0]) && $matches[0] !== '' ? $matches[0] : 'n/a'
				, $type, $imdbId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
				return $matches[0];
			} else {
				logDetails($title, $url, 'n/a', $type, $imdbId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '', $logFilePath = 'detailed_log.html');
				throw new Exception('Couldn\'t find the file link on superEmbed_stream.');
			}				
		
		} else {
			throw new Exception('Couldn\'t locate the encrypted host on superEmbed_stream.');
		}	   
		} else {			

			//Try and get the list of sources.
			if (preg_match('/(?<=document\.referrer\);var w=btoa\(").*?play.*?(?=")/', $content, $matches) && preg_match('/(?<=play=)(.*)/', $matches[0], $token)) {	

				$url = "https://streambucket.net/?play=" . urlencode($token[1]);

				$options = [
					'http' => [
						'method' => 'POST',
						'header' => "Referer: https://streambucket.net/\r\n" .
									"User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/118.0\r\n" .
									"X-Requested-With: XMLHttpRequest\r\n",
						'content' => 'button-click=ZEhKMVpTLVF0LVBTLVF0TmpnNExTLVF5TkRndEwtMC1WMk8tMGc1LVB6VXdPREl5T0RZLTU%3D&button-referer=',
						'timeout' => $timeOut,
					],
				];
				$context = stream_context_create($options);
				$content = @file_get_contents($url, false, $context);
				
				
				
				if (preg_match('/(?<=load_sources\(").*?(?="\))/', $content, $token2)) {	
					if ($GLOBALS['DEBUG']) {
						echo 'Found the 2nd token: ' . $token2[0] . '</br></br>';
					}
				} else {
					throw new Exception('Couldn\'t locate the 2nd token on superEmbed_stream.');
				}
				
				$url = "https://streambucket.net/response.php";

				$options = [
					'http' => [
						'method' => 'POST',
						'header' => "Referer: https://streambucket.net/\r\n" .
									"User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/118.0\r\n" .
									"X-Requested-With: XMLHttpRequest\r\n",
						'content' => 'token=' . urlencode($token2[0]),
						'timeout' => $timeOut,
					],
				];
				$context = stream_context_create($options);
				$content = @file_get_contents($url, false, $context);
				
	
				
				if (preg_match_all('/<li data-id="[\s\S]*?<\/li>/', $content, $servers)) {

					if ($GLOBALS['DEBUG']) {
						echo 'Found the list of servers: </br>';
					}
					// Loop through servers to find a matching extractor.
					foreach ($servers as $serverGroup) {
						foreach ($serverGroup as $server) {

							if (!is_string($server)) {
								continue;
							}

							// Extract data-id value
							preg_match('/data-id="([^"]+)"/', $server, $dataIdMatches);
							$dataId = $dataIdMatches[1] ?? null;

							// Extract data-server value
							preg_match('/data-server="(\d+)"/', $server, $dataServerMatches);
							$dataServer = $dataServerMatches[1] ?? null;

							// Extract server name
							preg_match('/server-image server-(\w+).*?<\/div>\s*(\w+)/', $server, $serverNameMatches);
							$serverName = $serverNameMatches[2] ?? null;

							$formUrl = "https://streambucket.net/playvideo.php?video_id=" . urlencode($dataId) . "&server_id=" . urlencode($dataServer) . "&token=" . urlencode($token2[0]) . "&init=0";

							$options = [
								'http' => [
									'method' => "GET",
									'header' => "Referer: https://streambucket.net/\r\n" .
												"User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/118.0\r\n",
									'timeout' => $timeOut,
								]
							];
							$context = stream_context_create($options);

							if ($GLOBALS['DEBUG']) {
								echo "Server Name: $serverName, Data ID: $dataId, Data Server: $dataServer<br>";
							}

							// Run UpstreamExtract
							if ($serverName == 'upstream') {

								$content = @file_get_contents($formUrl, false, $context);
								
								if (preg_match('/(?<=src=")http.*upstream.*?(?=")/', $content, $upstreamUrl)) {
									if ($GLOBALS['DEBUG']) {
										echo 'Found upstream url: ' . $upstreamUrl[0] . '</br></br>';
									}
									$upstreamDirect = UpstreamExtract($upstreamUrl[0], 'superEmbed_stream');
									if ($upstreamDirect !== false) {
										logDetails($title, $upstreamUrl[0], isset($upstreamDirect) && $upstreamDirect !== '' ? $upstreamDirect : 'n/a'
										, $type, $imdbId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');

										return $upstreamDirect;
									}
								} else {
										logDetails($title, 'n/a', 'n/a', $type, $imdbId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
									if ($GLOBALS['DEBUG']) {
										echo 'Couldn\'t locate the upstream url for superEmbed_stream.</br>';
									}

								}

							}

							// Run voe extraction.
							if ($serverName == 'voe') {

								$content = @file_get_contents($formUrl, false, $context);
								
								if (preg_match('/(?<=src=")http.*voe.*?(?=")/', $content, $voeUrl)) {						
									
									$DirectLink = VoeExtract($voeUrl[0], 'superEmbed_stream');											

								}
								if ($upstreamDirect) {
									if ($GLOBALS['DEBUG']) {
										echo 'Found voe url: ' . $voeDirect[0] . '</br></br>';
										
									}
										logDetails($title, $voeUrl[0], isset($DirectLink) && $DirectLink !== '' ? $DirectLink : 'n/a'
										, $type, $imdbId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');

										return $DirectLink;
								} else {
										logDetails($title, 'n/a', 'n/a', $type, $imdbId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
									if ($GLOBALS['DEBUG']) {
										echo 'Couldn\'t locate the voe url for superEmbed_stream.</br></br>';
									}

								}

							}
							
							// Run jwstream extraction.
							//Disabled for now until I figure out its proxying.
							if ($serverName == '!!jwstream') {

								$content = @file_get_contents($formUrl, false, $context);
								
								if (preg_match('/(?<=src=")http.*2embed.*?(?=")/', $content, $jwstreamUrl)) {
									
									if (strpos($jwstreamUrl[0], '/player/') === false) {
										// Replace '/tv/' with '/player/tv/' only if '/player/' is not already there
										$jwstreamUrl[0] = str_replace('/tv/', '/player/tv/', $jwstreamUrl[0]);
									}
									
									$content = @file_get_contents($jwstreamUrl[0], false, $context);

								}
																
								if (preg_match('/(?<=file":").*?(?=","type")/', $content, $jwstreamDirect)) {
									if ($GLOBALS['DEBUG']) {
										echo 'Found jwstream url: ' . $jwstreamDirect[0] . '</br></br>';
										
									}   
										$jwstreamDirect[0] = str_replace('\\', '', $jwstreamDirect[0]);
										
										logDetails($title, $jwstreamUrl[0], isset($jwstreamDirect[0]) && $jwstreamDirect[0] !== '' ? $jwstreamDirect[0] : 'n/a'
										, $type, $imdbId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');						
																			
										return $jwstreamDirect[0];
								} else {
										logDetails($title, 'n/a', 'n/a', $type, $imdbId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
									if ($GLOBALS['DEBUG']) {
										echo 'Couldn\'t locate the jwstream url for superEmbed_stream.</br></br>';
									}

								}

							}
							
							// Run streamwish extraction.
							if ($serverName == 'streamwish') {

								$content = file_get_contents($formUrl, false, $context);
								
								if (preg_match('/(?<=src=")http.*streamwish.*?(?=")/', $content, $streamwishUrl)) {
									
									$content = @file_get_contents($streamwishUrl[0], false, $context);

								}
								if (preg_match('/(?<=file:").*?(?=")/', $content, $streamwishDirect)) {
									if ($GLOBALS['DEBUG']) {
										echo 'Found streamwish url: ' . $streamwishDirect[0] . '</br></br>';
										
									}
										logDetails($title, $streamwishUrl[0], isset($streamwishDirect[0]) && $streamwishDirect[0] !== '' ? $streamwishDirect[0] : 'n/a'
										, $type, $imdbId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
								
										return $streamwishDirect[0];
								} else {
										logDetails($title, 'n/a', 'n/a', $type, $imdbId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
									if ($GLOBALS['DEBUG']) {
										echo 'Couldn\'t locate the streamwish url for superEmbed_stream.</br></br>';
									}

								}

							}
							
							// Run mixdrop extraction.
							if ($serverName == 'mixdrop') {
								$content = @file_get_contents($formUrl, false, $context);
								
								if (preg_match('/(?<=src=")http.*mixdrop.*?(?=")/', $content, $mixdropUrl)) {
									
									$content = @file_get_contents($mixdropUrl[0], false, $context);

								}
								
								if (preg_match('#\beval\(function\(p,a,c,k,e,d\).*?\}\)\)#', $content, $matches)) {
									$unpacker = new JavaScriptUnpacker();
									
									// Use the methods of the JavaScriptUnpacker class as needed
									$unpackedCode = $unpacker->unpack($matches[0]);

								} 
								if (!empty($unpackedCode) && preg_match('/MDCore\.wurl="([^"]+)"/', $unpackedCode, $matches)){
									
									$mixdropDirect = 'https:' . $matches[1];
									
									if ($GLOBALS['DEBUG']) {
										echo 'Found mixdrop url: ' . $mixdropDirect . '</br></br>';
									}
									
									
									if ($GLOBALS['DEBUG']) {
										echo "Video link: " . $mixdropDirect . "<br><br>";
									}
									//Run link checker before returning.
									$urlData = $mixdropDirect .
										"|Referer='" . $mixdropUrl[0] . "'|User-Agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0'";
										
									$lCheck = checkLinkStatusCode($urlData);
									if ($lCheck == true){
										logDetails($title, $mixdropUrl[0], isset($mixdropDirect) && $mixdropDirect !== '' ? $mixdropDirect : 'n/a'
										, $type, $imdbId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');										
	
										return 'video_proxy.php?data=' . base64_encode($urlData);
									}
									
								} else {
										logDetails($title, 'n/a', 'n/a', $type, $imdbId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
									if ($GLOBALS['DEBUG']) {
										echo 'Couldn\'t locate the packed JS on mixdrop for superEmbed_stream.</br></br>';
									}

								}

							}

							// Run filelions extraction.
							if ($serverName == 'filelions') {

								$content = @file_get_contents($formUrl, false, $context);
								
								if (preg_match('/(?<=src=")http.*filelions.*?(?=")/', $content, $filelionsUrl)) {
									
									$content = @file_get_contents($filelionsUrl[0], false, $context);

								}
								
								if (preg_match('#\beval\(function\(p,a,c,k,e,d\).*?\)\)\)#', $content, $matches)) {
									$unpacker = new JavaScriptUnpacker();
									
									// Use the methods of the JavaScriptUnpacker class as needed
									$unpackedCode = $unpacker->unpack($matches[0]);

								} 
								if (!empty($unpackedCode) && preg_match('/(?<=file:").*?(?=")/', $unpackedCode, $matches)){
									
									$filelionsDirect = $matches[0];
									
									if ($GLOBALS['DEBUG']) {
										echo 'Found filelions url: ' . $filelionsDirect . '</br></br>';
									}									
									
									logDetails($title, $filelionsUrl[0], isset($filelionsDirect) && $filelionsDirect !== '' ? $filelionsDirect : 'n/a'
									, $type, $imdbId, 'successful', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');			
													
									return $filelionsDirect;
									
								} else {
										logDetails($title, 'n/a', 'n/a', $type, $imdbId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
									if ($GLOBALS['DEBUG']) {
										echo 'Couldn\'t locate the packed JS on filelions for superEmbed_stream.</br></br>';
									}

								}

							}							
						}

					}

				} else {
					throw new Exception('Couldn\'t get the source list on superEmbed_stream.');
				}
				
				
			} else {
				throw new Exception('Couldn\'t get the source list on superEmbed_stream.');
			}
		}

    }
    catch (exception $error) {

        if ($GLOBALS['DEBUG']) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
        }
			logDetails($title, 'n/a', 'n/a', $type, $imdbId, 'failed', $type === 'series' ? $seasonNoPad : '', $type === 'series' ? $episodeNoPad : '');
        return false;
    }

    return false;
}

//Decryption for superEmbed_stream
function superEmbedBaseConvert($value, $fromBase, $toBase) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+/';
    $fromCharacters = substr($characters, 0, $fromBase);
    $toCharacters = substr($characters, 0, $toBase);
    $decimalValue = 0;

    // Reversing the string and converting from the base $fromBase to decimal
    for ($i = 0; $i < strlen($value); $i++) {
        $decimalValue += strpos($fromCharacters, $value[$i]) * pow($fromBase, strlen($value) - $i - 1);
    }

    // Converting from decimal to the base $toBase
    $result = '';
    while ($decimalValue > 0) {
        $result = $toCharacters[$decimalValue % $toBase] . $result;
        $decimalValue = intdiv($decimalValue, $toBase);
    }
    
    return $result ?: '0';
}
//Decryption for superEmbed_stream
function superEmbedDecodeString($encodedString, $dictionary, $fromBase, $shift, $index) {
    $decoded = '';
    $len = strlen($encodedString);
    for ($i = 0; $i < $len; $i++) {
        $temp = '';
        while ($i < $len && $encodedString[$i] !== $dictionary[$index]) {
            $temp .= $encodedString[$i];
            $i++;
        }
        $temp = str_replace(str_split($dictionary), range(0, strlen($dictionary) - 1), $temp);
        $decoded .= chr(superEmbedBaseConvert($temp, $index, 10) - $shift);
    }
    return rawurldecode($decoded);
}

////////////////////////////// Caching ///////////////////////////////

function writeToCache($key, $value)
{
    global $expirationDuration;

    // Specify the cache file path
    $cacheFilePath = 'cache.json';

    // Check if the cache file exists or create it if not
    if (!file_exists($cacheFilePath)) {
        file_put_contents($cacheFilePath, '{}');
    }

    // Get the current timestamp
    $now = time();
    $expirationTime = $now + $expirationDuration;

    // Serialize the value to a JSON string
    $serializedValue = json_encode($value);

    // Read existing cache data
    $cacheData = json_decode(file_get_contents($cacheFilePath), true) ? : [];

    // Update the cache data with the new value
    $cacheData[$key] = ['value' => $serializedValue, 'expirationTime' => $expirationTime, ];

    // Write the updated cache data back to the file
    file_put_contents($cacheFilePath, json_encode($cacheData));

    if ($GLOBALS['DEBUG']) {
        echo 'Added to Cache - Key: ' . $key . ' Value: ' . json_encode($value) .
            "</br></br>";
    }
}

function readFromCache($key)
{
    // Specify the cache file path
    $cacheFilePath = 'cache.json';

    // Check if the cache file exists or create it if not
    if (!file_exists($cacheFilePath)) {
        file_put_contents($cacheFilePath, '{}');
    }

    // Read existing cache data
    $cacheData = json_decode(file_get_contents($cacheFilePath), true) ? : [];

    if (isset($cacheData[$key])) {
        $parsedData = $cacheData[$key];

        // Get the current timestamp
        $now = time();

        // Check if the data has expired
        if ($now <= $parsedData['expirationTime']) {
            // Deserialize the JSON string back to an object
            $deserializedValue = json_decode($parsedData['value'], true);

            if ($GLOBALS['DEBUG']) {
                echo 'Read from Cache - Key: ' . $key . ' - Value: ' . json_encode($deserializedValue) .
                    "</br></br>";
            }

            return $deserializedValue;
        } else {
            // Data has expired, remove it from the cache
            unset($cacheData[$key]);

            // Write the updated cache data back to the file
            file_put_contents($cacheFilePath, json_encode($cacheData));
        }
    }

    // Cache miss or expired data, or the cache file doesn't exist
    return null;
}

function cleanupCacheFiles()
{
    global $cacheSize;
    // List of cache files to check
    $cacheFiles = ['html_cache.txt', 'cache.json', 'access.log'];

    foreach ($cacheFiles as $file) {
        // Check if file exists
        if (file_exists($file)) {
            // Get file size in bytes
            $fileSize = filesize($file);

            $maxSize = $cacheSize * 1024 * 1024;

            // If file size is greater than 30 MB, clear the file
            if ($fileSize > $maxSize) {
                if ($GLOBALS['DEBUG']) {
                    echo "Cache file $file is larger than " . $cacheSize .
                        "MB. Clearing the file.<br>";
                }

                // Clear the file contents
                file_put_contents($file, '');
            }
        }
    }
}

////////////////////////////// Logging ///////////////////////////////

function logDetails($title, $site, $videoUrl, $type, $TMDB, $status, $season = 'n/a', $episode = 'n/a', $logFilePath = 'detailed_log.html') {
    // Backtrace to find the caller function
    $backtrace = debug_backtrace();
    $callerFunction = isset($backtrace[1]['function']) ? $backtrace[1]['function'] : 'n/a';
	$time = date('Y-m-d H:i:s');
    
    // Set 'n/a' if season or episode is empty
    $season = !empty($season) ? $season : 'n/a';
    $episode = !empty($episode) ? $episode : 'n/a';

    // Determine the domain and base path
    $domain = 'http://localhost';
    if (php_sapi_name() != 'cli') {
        $domain = isset($_SERVER['HTTP_HOST']) ? 'http://' . $_SERVER['HTTP_HOST'] : $domain;
        $basePath = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/') . '/';
    } else {
        $basePath = '/';
    }
		
	// Create the access URL
	$accessUrl = $domain . $basePath . basename($_SERVER['SCRIPT_NAME']);

	// Append 'dev=true' only if it's not already in the query string
	if (!empty($_SERVER['QUERY_STRING'])) {
		// If the query string exists, append it, and add 'dev=true' if it's not part of the query string
		$accessUrl .= '?' . $_SERVER['QUERY_STRING'];
		if (strpos($_SERVER['QUERY_STRING'], 'dev=true') === false) {
			$accessUrl .= '&dev=true';
		}
	} else {
		// If there is no query string, just add '?dev=true'
		$accessUrl .= '?dev=true';
	}

    // Styles for the table
    $style = "<style>
        table { width: 100%; border-collapse: collapse; table-layout: fixed; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; overflow: hidden; text-overflow: ellipsis;}		
        th { background-color: #f2f2f2; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        a { color: #0645ad; text-decoration: none; }
        a:hover { text-decoration: underline; }
        .status-success { color: green; }
        .status-failed { color: red; }
    </style>";

    // DOMDocument setup
    $doc = new DOMDocument();
    @$doc->loadHTMLFile($logFilePath) || @$doc->loadHTML('<html><head><title>Detailed Logs</title><meta http-equiv="refresh" content="5" />' . $style . '</head><body><table><thead></thead><tbody></tbody></table></body></html>');

    // Get or create the table and tbody
    $table = $doc->getElementsByTagName('table')->item(0);
    $tbody = $table->getElementsByTagName('tbody')->item(0);

    // Create header if it does not exist
    if ($table->getElementsByTagName('thead')->item(0)->childNodes->length === 0) {
        $headers = ['Time', 'Function', 'Status', 'Title', 'Site', 'Video URL', 'Access URL', 'Type', 'Movie ID', 'Season', 'Episode'];
        $headerRow = $doc->createElement('tr');
        foreach ($headers as $header) {
            $th = $doc->createElement('th', $header);
            $headerRow->appendChild($th);
        }
        $table->getElementsByTagName('thead')->item(0)->appendChild($headerRow);
    }

    // Create a new row
    $row = $doc->createElement('tr');
    $rowData = [$time, $callerFunction, $status, $title, $site, $videoUrl, $accessUrl, $type, $TMDB, $season, $episode];

	foreach ($rowData as $index => $data) {
		$td = $doc->createElement('td');
		$td->setAttribute('style', 'max-width: 200px; overflow: hidden; text-overflow: ellipsis;');

		// Correctly handle URLs; skip creating an anchor element if the data is 'n/a'
		if (in_array($index, [4, 5, 6]) && $data !== 'n/a') { // For Site URL, Video URL, and Access URL
			$a = $doc->createElement('a');
			$a->setAttribute('href', $data);
			$a->setAttribute('target', '_blank');
			$a->appendChild($doc->createTextNode($data));
			$td->appendChild($a);
		} else { // For non-URLs or 'n/a', just set the text content
			$td->textContent = $data;
			if ($index == 2) { // Additional styling for Status column
				$td->setAttribute('style', 'max-width: 200px; overflow: hidden; text-overflow: ellipsis; color: ' . ($data === 'successful' ? 'green' : ($data === 'failed' ? 'red' : 'black')) . ';');
			}
		}
		$row->appendChild($td);
	}

    // Insert the new row at the top of the tbody
    if ($tbody->childNodes->length > 0) {
        $tbody->insertBefore($row, $tbody->childNodes->item(0));
    } else {
        $tbody->appendChild($row);
    }

    // Keep only the latest 300 rows in tbody
    while ($tbody->childNodes->length > 300) {
        $tbody->removeChild($tbody->lastChild);
    }

    // Save the updated HTML to the file
    $doc->saveHTMLFile($logFilePath);
}




?>