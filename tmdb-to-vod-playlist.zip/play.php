<?php
// Created By gogetta.teams@gmail.com
// Please leave this in this script.
// https://github.com/gogetta69/TMDB-To-VOD-Playlist/

require_once 'JavaScriptUnpacker.php';
require_once 'config.php';

if (DEBUG !== true) {
    error_reporting(0);	
} else {
	accessLog();
}	

////////////////////////////// Run Script ///////////////////////////////

cleanupCacheFiles(); // Check cache cleanup
//Run the script.
$expirationDuration = $expirationHours * 3600;

if (isset($_GET['movieId']) && !empty($_GET['movieId'])) {
    $movieId = $_GET['movieId'];

    $type = $_GET['type'] ?? 'movies';
    $episodeData = isset($_GET['data']) ? base64_decode($_GET['data']) : '';
} else {
    echo 'The movieId parameter was not passed or is empty!';
    exit();
}

$torrentData = [];
//Run movies
if ($type == 'movies') {	
if (movieDetails_TMDB($movieId, $apiKey, $useRealDebrid) !== false) {
    http_response_code(404);
    echo "The requested resource was not found.";
	exit();
} else {
    echo "Should have redirected to the video.";
	exit();
}
//Run series
} elseif ($type == 'series'){
	$episodeData = explode(':', $episodeData);
	$subEpData = explode('/', $episodeData[1]);
	
	$movieId = $subEpData[0];
	
	//Store season number
	$seasonNoPad = $subEpData[2];
	$subEpData[2] = str_pad($subEpData[2], 2, "0", STR_PAD_LEFT);
	$season = $subEpData[2];
	//Store episode number
	$episodeNoPad = $subEpData[4];
	$subEpData[4] = str_pad($subEpData[4], 2, "0", STR_PAD_LEFT);
	$episode = $subEpData[4];
	$episodeId = 's'.$subEpData[2].'e'.$subEpData[4];
	seriesDetails_TMDB($movieId, $apiKey, $useRealDebrid, $episodeData);
}


////////////////////////////// List of Functions ///////////////////////////////

////////////////////////////// The Movie Database ///////////////////////////////

function movieDetails_TMDB($movieId, $apiKey, $useRealDebrid)
{
    global $userDefinedOrder, $language;

    // Define the cache key
    $key = $movieId . '_tmdb_url';

    // Try to read the URL from cache
    $cachedUrl = readFromCache($key);

    // If the URL is found in cache and hasn't expired, perform a 301 redirect
    if ($cachedUrl !== null) {
        if (DEBUG) {
            echo "Service: Pulled from the cache - Url: " . $cachedUrl . "</br></br>";
            echo 'Debugging: Redirection to the video would have taken place here.</br></br>';
            exit();
        } else {
            header("HTTP/1.1 301 Moved Permanently");
            header("Location: $cachedUrl");
            exit();
        }
    }

    $baseUrl = 'https://api.themoviedb.org/3/movie/';
    $url = $baseUrl . $movieId . '?api_key=' . $apiKey . '&language=' . $language;

    $response = @file_get_contents($url);

    if ($response !== false) {
        $movieData = json_decode($response, true);
        $imdbId = $movieData['imdb_id'];
        $title = $movieData['title'];
        $year = substr($movieData['release_date'], 0, 4);

        if ($imdbId) {
            if (DEBUG) {
                // Log the extracted information
                echo 'IMDb ID: ' . $imdbId . "</br></br>";
                echo 'Title: ' . $title . "</br></br>";
                echo 'Year: ' . $year . "</br></br>";
            }


            $predefinedFunctions = ['theMovieArchive_site', 'shegu_net_links',
                'torrentSites', 'goMovies_sx', 'upMovies_to'];

            $successfulFunctionName = '';

            // Iterate through the user-defined order and execute functions accordingly
            foreach ($userDefinedOrder as $functionName) {
                if (in_array($functionName, $predefinedFunctions) && function_exists($functionName)) {
                    // Check if Real Debrid functions should run
                    if (!$useRealDebrid && in_array($functionName, ['torrentSites'])) {
                        continue; // Skip Real Debrid functions if not needed
                    }

                    // Define an array of parameters to pass to the function
                    $params = [$movieId, $imdbId, $title, $year];

                    if ($functionName == 'torrentSites') {
                        $params = [$movieId, $imdbId, $title, $year];
                    }

                    if ($functionName == 'shegu_net_links') {
                        $params = [$title, $year];
                    }


                    if ($functionName == 'theMovieArchive_site') {
                        $params = [$movieId, $title];
                    }
					
					if ($functionName == 'goMovies_sx') {
                        $params = [$title, $year];
                    }
					
					if ($functionName == 'upMovies_to') {
                        $params = [$title, $year];
                    }					

                    // Call the function with appropriate arguments
                    $result = call_user_func_array($functionName, $params);

                    // Check the result and continue or stop based on success
                    if ($result !== false) {
                        // Store the successful function name
                        $successfulFunctionName = $functionName;

                        if ($functionName !== 'torrentSites') {
							if (strpos($result, 'video_proxy.php') === false){
								$lCheck = checkLinkStatusCode($result);
							} else {
								$lCheck = true;
							}
                        } else {
                            $lCheck = true;
                        }

                        if (DEBUG) {
                            // Log the extracted information with the successful function name
                            if ($lCheck !== false) {
                                echo "Service: " . $successfulFunctionName . ' - Url: ' . $result . "</br></br>";
                                echo 'Debugging: Redirection to the video would have taken place here.</br></br>';
                                writeToCache($key, $result);
                                exit();
                            }
                        } else {
                            // Put write to the cache here
                            if ($lCheck !== false) {
                                writeToCache($key, $result);
                                header("HTTP/1.1 301 Moved Permanently");
                                header("Location: $cachedUrl");
                                exit();
                            }
                        }
                    }
                }
            }
            http_response_code(404);
            echo "The requested resource was not found.";
            exit();

        } else {
            if (DEBUG) {
                echo 'IMDb ID not found for the movie.' . "</br></br>";
            }
            http_response_code(404);
            echo "The requested resource was not found.";
            exit();
        }
    } else {
        if (DEBUG) {
            echo 'Error: Unable to retrieve movie details.' . "</br></br>";
        }
        http_response_code(404);
        echo "The requested resource was not found.";
        exit();
    }
}

function seriesDetails_TMDB($movieId, $apiKey, $useRealDebrid, $episodeData)
{	
    global $userDefinedOrder, $episodeId, $language;
	

    // Define the cache key
    $key = $movieId . '_series_' . $episodeId . '_url';

    // Try to read the URL from cache
    $cachedUrl = readFromCache($key);

    // If the URL is found in cache and hasn't expired, perform a 301 redirect
    if ($cachedUrl !== null) {
        if (DEBUG) {
            echo "Service: Pulled from the cache - Url: " . $cachedUrl . "</br></br>";
            echo 'Debugging: Redirection to the video would have taken place here.</br></br>';
            exit();
        } else {
            header("HTTP/1.1 301 Moved Permanently");
            header("Location: $cachedUrl");
            exit();
        }
    }

    $baseUrl = 'https://api.themoviedb.org/3/tv/';
    $url = $baseUrl . $movieId . '?api_key=' . $apiKey . '&language=' . $language;

    $response = @file_get_contents($url);

    if ($response !== false) {
        $seriesData = json_decode($response, true);
        $imdbId = $episodeData[0];
		$title = $seriesData['name'];
        $setitle = $seriesData['name'].' '.$episodeId;
        $year = substr($seriesData['first_air_date'], 0, 4);

        if ($imdbId) {
            if (DEBUG) {
                // Log the extracted information
                echo 'IMDb ID: ' . $imdbId . "</br></br>";
                echo 'Title: ' . $title . "</br></br>";
                echo 'Year: ' . $year . "</br></br>";
            }	
	
            $predefinedFunctions = ['shegu_net_links',
                'torrentSites', 'goMovies_sx'];

            $successfulFunctionName = '';

            // Iterate through the user-defined order and execute functions accordingly
            foreach ($userDefinedOrder as $functionName) {
                if (in_array($functionName, $predefinedFunctions) && function_exists($functionName)) {
                    // Check if Real Debrid functions should run
                    if (!$useRealDebrid && in_array($functionName, ['torrentSites'])) {
                        continue; // Skip Real Debrid functions if not needed
                    }

                    // Define an array of parameters to pass to the function
                    $params = [$movieId, $imdbId, $setitle, $year];

                    if ($functionName == 'torrentSites') {
                        $params = [$movieId, $imdbId, $setitle];
                    }

                    if ($functionName == 'shegu_net_links') {
                        $params = [$title, $year];
                    }

					
					if ($functionName == 'goMovies_sx') {
                        $params = [$title, $year];
                    }

                    // Call the function with appropriate arguments
                    $result = call_user_func_array($functionName, $params);

                    // Check the result and continue or stop based on success
                    if ($result !== false) {
                        // Store the successful function name
                        $successfulFunctionName = $functionName;

                        if ($functionName !== 'torrentSites') {
                            $lCheck = checkLinkStatusCode($result);
                        } else {
                            $lCheck = true;
                        }

                        if (DEBUG) {
                            // Log the extracted information with the successful function name
                            if ($lCheck !== false) {
                                echo "Service: " . $successfulFunctionName . ' - Url: ' . $result . "</br></br>";
                                echo 'Debugging: Redirection to the video would have taken place here.</br></br>';
                                writeToCache($key, $result);
                                exit();
                            }
                        } else {
                            // Put write to the cache here
                            if ($lCheck !== false) {
                                writeToCache($key, $result);
                                header("HTTP/1.1 301 Moved Permanently");
                                header("Location: $cachedUrl");
                                exit();
                            }
                        }
                    }
                }
            }
            http_response_code(404);
            echo "The requested resource was not found.";
            exit();

        } else {
            if (DEBUG) {
                echo 'IMDb ID not found for the movie.' . "</br></br>";
            }
            http_response_code(404);
            echo "The requested resource was not found.";
            exit();
        }
    } else {
        if (DEBUG) {
            echo 'Error: Unable to retrieve movie details.' . "</br></br>";
        }
        http_response_code(404);
        echo "The requested resource was not found.";
        exit();
    }
}


////////////////////////////// Real Debrid ///////////////////////////////

function addMagnetLink_RD($torrents, $magnetLink, $tSite)
{
    global $PRIVATE_TOKEN;

    try {
        $url = 'https://api.real-debrid.com/rest/1.0/torrents/addMagnet';
        $postData = 'magnet=' . urlencode($magnetLink);
        $headers = ['Authorization: Bearer ' . $PRIVATE_TOKEN,
            'Content-Type: application/x-www-form-urlencoded', ];
        $options = ['http' => ['method' => 'POST', 'header' => implode("\r\n", $headers),
            'content' => $postData, ], ];
        $context = stream_context_create($options);
        $response = file_get_contents($url, false, $context);
        $statusCode = http_response_code();
        if ($statusCode !== 200 && $statusCode !== 201) {
            if (DEBUG) {
                echo 'HTTP Error Code: ' . $statusCode . "</br></br>";
                echo 'Error Response: ' . $response . "</br></br>";
            }
            return;
        }
        $data = json_decode($response, true);
        $id = $data['id'];
        $uri = urldecode($data['uri']);
        if (DEBUG) {
            echo 'ID: ' . $id . "</br></br>";
            echo 'URI: ' . $uri . "</br></br>";
        }
        return selectMultipleFiles_RD($torrents, $id, $tSite);
    }
    catch (exception $e) {
        if (DEBUG) {
            echo "Error in addMagnetLink_RD: " . $e->getMessage() . "</br></br>";
        }
        return; // Continue execution of the script
    }
}

function selectFile_RD($torrentId, $fileId)
{
    global $PRIVATE_TOKEN;	

    try {
        $url = 'https://api.real-debrid.com/rest/1.0/torrents/selectFiles/' . $torrentId;
        $postData = 'files=' . $fileId;
        $headers = ['Authorization: Bearer ' . $PRIVATE_TOKEN,
            'Content-Type: application/x-www-form-urlencoded', ];
        $options = ['http' => ['method' => 'POST', 'header' => implode("\r\n", $headers),
            'content' => $postData, ], ];
        $context = stream_context_create($options);
        $response = file_get_contents($url, false, $context);
        $statusCode = http_response_code();
        // Define the array of error codes
        $errorCodes = [202 => 'Action already done', 400 =>
            'Bad Request (see error message)', 401 => 'Bad token (expired, invalid)', 403 =>
            'Permission denied (account locked, not premium)', 404 =>
            'Wrong parameter (invalid file id(s)) / Unknown resource (invalid id)',
            // Add more error codes as needed
            ];



        // Check if the status code is in the array of error codes
        if (array_key_exists($statusCode, $errorCodes)) {
            if (DEBUG) {
                echo 'HTTP Error Code: ' . $statusCode . "</br></br>";
            }

            // Output the error description
            echo 'Reason: ' . $errorCodes[$statusCode] . "</br></br>";

            echo 'Error Response: ' . $response . "</br></br>";
        }

		if (DEBUG) {				
			print_r('selectFile_RD - Response: ' .  $statusCode . "</br></br>");
		}

    }
    catch (exception $e) {
        if (DEBUG) {
            echo "Error in selectFile_RD: " . $e->getMessage() . "</br></br>";
        }
        return; // Continue execution of the script
    }
}

function selectMultipleFiles_RD($torrents, $torrentId, $tSite)
{
    global $PRIVATE_TOKEN, $type, $episodeId;

    try {
        $url = 'https://api.real-debrid.com/rest/1.0/torrents/info/' . $torrentId;
        $headers = ['Authorization: Bearer ' . $PRIVATE_TOKEN,
            'Content-Type: application/x-www-form-urlencoded', ];
        $options = ['http' => ['method' => 'GET', 'header' => implode("\r\n", $headers), ], ];
        $context = stream_context_create($options);
        $response = file_get_contents($url, false, $context);
        $statusCode = http_response_code();
        if ($statusCode === 200) {
            if (DEBUG) {
                echo 'HTTP Response Content: ' . $response . "</br></br>";
            }
        } else {
            if (DEBUG) {
                echo 'HTTP Error Code: ' . $statusCode . "</br></br>";
                echo 'Error Response: ' . $response . "</br></br>";
            }
            return;
        }
        $data = json_decode($response, true);
        $files = $data['files'];
		
		// Exclude files with the word 'sample' in their path
		$files = array_filter($files, function($file) {
			return stripos($file['path'], 'sample') === false;
		});
				
		//Select the file by $episodeId (s01e03) 
		if ($type == 'series'){
			$files = array_filter($files, function($file) use ($episodeId) {
				// Convert both strings to lowercase for a case-insensitive check
				return stripos(strtolower($file['path']), strtolower($episodeId)) !== false;
			});
		}
		

        $mp4FileIndex = findMp4FileIndex($files);
        if ($mp4FileIndex !== -1) {
            selectFile_RD($torrentId, $files[$mp4FileIndex]['id']);
        } else {
            $videoFileIndex = findAnyVideoFileIndex($files);
            if ($videoFileIndex !== -1) {
                selectFile_RD($torrentId, $files[$videoFileIndex]['id']);
            } else {
                if (DEBUG) {
                    echo 'No video files found in the torrent.' . "</br></br>";
                }
            }
        }
        return getDlLink_RD($torrents, $torrentId, $tSite);
    }
    catch (exception $e) {
        if (DEBUG) {
            echo "Error in selectMultipleFiles_RD: " . $e->getMessage() . "</br></br>";
        }
        return; // Continue execution of the script
    }
}

function getDlLink_RD($torrents, $torrentId, $tSite)
{
    global $PRIVATE_TOKEN;

    try {
        $url = 'https://api.real-debrid.com/rest/1.0/torrents/info/' . $torrentId;
        $headers = ['Authorization: Bearer ' . $PRIVATE_TOKEN,
            'Content-Type: application/x-www-form-urlencoded', ];
        $options = ['http' => ['method' => 'GET', 'header' => implode("\r\n", $headers), ], ];
        $context = stream_context_create($options);
        $response = file_get_contents($url, false, $context);
        $statusCode = http_response_code();
        if ($statusCode === 200) {
            $data = json_decode($response, true);
            $linksArray = $data['links'];
            if ($linksArray && count($linksArray) > 0) {
                $firstLink = $linksArray[0];
                $payload = ['link' => $firstLink, 'remote' => 0, ];
                $context = stream_context_create(['http' => ['method' => 'POST', 'header' =>
                    implode("\r\n", $headers), 'content' => http_build_query($payload), ], ]);
                $unrestrictResponse = file_get_contents('https://api.real-debrid.com/rest/1.0/unrestrict/link', false,
                    $context);
                $unrestrictData = json_decode($unrestrictResponse, true);
                $downloadLink = $unrestrictData['download'];
                if (DEBUG) {				
                    echo 'getDlLink_RD - Video link: ' . $downloadLink . "</br></br>";
                }
                $fileNameMatch = preg_match('#/([^/]+)$#', $downloadLink, $fileNameMatches);
                if ($fileNameMatch) {
                    $filenameNoExt = urldecode($fileNameMatches[1]);
                } else {
                    $filenameNoExt = 'Unknown';
                }
                return $downloadLink;
            } else {
                if (DEBUG) {
					//print_r($response . "</br></br>");
                    echo 'getDlLink_RD: No links found in the array.' . "</br></br>";
                }
                return false;
            }
        } else {
            if (DEBUG) {
                echo 'HTTP Error Code: ' . $statusCode . "</br></br>";
                echo 'Error Response: ' . $response . "</br></br>";
            }
        }
    }
    catch (exception $e) {
        if (DEBUG) {
            echo "Error in getDlLink_RD: " . $e->getMessage() . "</br></br>";
        }
        return false;
    }
}

////////////////////////////// Processing ///////////////////////////////

function torrentSites($movieId, $imdbId, $title, $year=null){
global $timeOut, $maxResolution, $torrentData, $type, $season, $episode;

magnetdl_com($movieId, $imdbId, $title, $year);

//bitLordSearch_com($movieId, $imdbId, $title, $year);	
thepiratebay_org($movieId, $imdbId, $title, $year);
torrentDownload_info($movieId, $imdbId, $title, $year);
popcornTime($movieId, $imdbId, $title);	
torrentGalaxy_to($movieId, $imdbId, $title);
glodls_to($movieId, $imdbId, $title, $year);

if($type == "series"){
ezTV_re($movieId, $imdbId, $title);	
}
if($type == "movies"){
yts_mx($movieId, $imdbId, $title);
}
if (!empty($torrentData)){
return selectHashByPreferences($torrentData, $maxResolution, 'torrentSites');
} else {
return false;	
}
}

function checkLinkStatusCode($url)
{
	    // Check if the URL is empty
    if (empty($url)) {
        if (DEBUG) {
            echo 'Link Checker - URL is empty.</br></br>';
        }
        return false;
    }
    // Check if the URL contains headers (i.e., "|")
    if (strpos($url, '|') !== false) {
        // Split the URL into the actual URL and headers (if "|" is present)
        list($actualUrl, $headersStr) = explode('|', $url, 2);

        // Trim any leading or trailing spaces from the headers
        $headersStr = trim($headersStr);

        // Initialize the headers array
        $headers = [];

        if (!empty($headersStr)) {
            // Convert headers to the correct format
            $headersArr = explode('|', $headersStr);

            foreach ($headersArr as $header) {
                list($headerName, $headerValue) = explode('=', $header, 2);
                $headers[] = $headerName . ': ' . $headerValue;
            }
        }

        // Create context options for the stream context
        $contextOptions = ['http' => ['header' => implode("\r\n", $headers)]];
        $context = stream_context_create($contextOptions);

        // Send a HEAD request to the actual URL with the extracted headers
        $responseHeaders = get_headers($actualUrl, 1, $context);

        if ($responseHeaders !== false) {
            // Extract the HTTP status code from the first header
            $httpStatus = explode(' ', $responseHeaders[0], 3);

            if (isset($httpStatus[1]) && ($httpStatus[1] == '404' || $httpStatus[1] == '503' ||
                $httpStatus[1] == '500' || $httpStatus[1] == '400')) {
                if (DEBUG) {
                    echo 'Link Checker - The URL returned a ' . $httpStatus[1] .
                        ' status (Not Found).';
                }
                return false;
            } else {
                if (DEBUG) {
                    echo 'Link Checker - Successful: The URL is accessible.</br></br>';
                }
                return true;
            }
        }

        if (DEBUG) {
            echo 'Link Checker - Failed to fetch the URL or an error occurred.</br></br>';
        }
        return false;
    } else {
        // No headers, send a HEAD request to the URL without headers
        $responseHeaders = get_headers($url);

        if ($responseHeaders !== false) {
            // Extract the HTTP status code from the first header
            $httpStatus = explode(' ', $responseHeaders[0], 3);

            if (isset($httpStatus[1]) && ($httpStatus[1] == '404' || $httpStatus[1] == '503' ||
                $httpStatus[1] == '500' || $httpStatus[1] == '400')) {
                if (DEBUG) {
                    echo 'Link Checker - The URL returned a ' . $httpStatus[1] .
                        ' status (Not Found).</br></br>';
                }
                return false;
            } else {
                if (DEBUG) {
                    echo 'Link Checker - Successful: The URL is accessible.</br></br>';
                }
                return true;
            }
        }

        if (DEBUG) {
            echo 'Link Checker - Failed to fetch the URL or an error occurred. </br></br>';
        }
        return false;
    }
}

function selectHashByPreferences($torrents, $maxResolution, $tSite)
{
    global $PRIVATE_TOKEN;

    $selectedHash = null;
    $highestResolutionBelowMax = 0;
    $lowestResolutionAboveMax = INF;

	// Extract hashes from the torrents array
	$hashes = array_map(function ($torrent) {
		if (isset($torrent['hash'])) {
			return strtolower($torrent['hash']);
		}
		return null;
	}, $torrents);
	
	$hashes = array_filter($hashes, function($value) {
    return $value !== null; //
	});
	

    // Form the hash string for the API request
    $hashString = implode("/", $hashes);
    // Define the API URL
    $url = "https://api.real-debrid.com/rest/1.0/torrents/instantAvailability/{$hashString}";
    if (DEBUG) {
        echo "Combine hashes to send to RD - The formed url: " . $url . "</br></br>";
    }
    // Define the headers for the API request
    $headers = ["Authorization: Bearer {$PRIVATE_TOKEN}", ];

    // Create context for file_get_contents with headers
    $context = stream_context_create(['http' => ['method' => "GET", 'header' =>
        implode("\r\n", $headers), ]]);

    // Send the API request and decode the JSON response
    $response = file_get_contents($url, false, $context);
    $availabilityData = json_decode($response, true);

    // Filter the torrents array based on availability and video file extension
    $torrents = array_filter($torrents, function ($torrent)use ($availabilityData)
    {
		if (isset($torrent['hash'])) {
			$hash = strtolower($torrent['hash']);
		}
            // Convert the hash from the torrents array to lowercase
            $availabilityData = array_change_key_case($availabilityData, CASE_LOWER);
            // Convert all keys in availabilityData to lowercase

		if (isset($hash) && isset($availabilityData[$hash]['rd']) && is_array($availabilityData[$hash]['rd'])) {
			foreach ($availabilityData[$hash]['rd'] as $files) {
				if (is_array($files)) {
					foreach ($files as $file) {
						if (isset($file['filename']) && is_string($file['filename'])) {
							$filename = $file['filename'];
							$extension = pathinfo($filename, PATHINFO_EXTENSION);
							if (in_array($extension, ['mkv', 'mp4', 'avi', 'mov', 'flv', 'wmv', 'mpeg', 'mpg'])) { 
								return true;
							}
						}
					}
				}
			}
		}
        return false; }
    );


    foreach ($torrents as $torrent) {
        $resolution = extractResolution($torrent['quality']);
        if (DEBUG) {
            echo $resolution . ' vs ' . $maxResolution . "</br></br>";
        }
        // If resolution matches maxResolution, select the hash and exit the loop
        if ($resolution === $maxResolution) {
            $selectedHash = $torrent['hash'];
            if (DEBUG) {
                echo 'Checking Details | Resolution: ' . $resolution . ' - Hash: ' . $selectedHash .
                    "</br></br>";
            }
            return addMagnetLink_RD($torrents, 'magnet:?xt=urn:btih:' . $torrent['hash'], $tSite);
        }

        // If the resolution is less than maxResolution but greater than highestResolutionBelowMax
        if ($resolution < $maxResolution && $resolution > $highestResolutionBelowMax) {
            $selectedHash = $torrent['hash'];
            $highestResolutionBelowMax = $resolution;
            if (DEBUG) {
                echo 'Checking Details | Resolution: ' . $resolution . ' - Hash: ' . $selectedHash .
                    "</br></br>";
            }
        }

        // If the resolution is above maxResolution but less than lowestResolutionAboveMax
        if ($resolution > $maxResolution && $resolution < $lowestResolutionAboveMax) {
            $selectedHash = $torrent['hash'];
            $lowestResolutionAboveMax = $resolution;
            if (DEBUG) {
                echo 'Selected Details | Resolution: ' . $resolution . ' - Hash: ' . $selectedHash .
                    "</br></br>";
            }
        }
    }

    // If a hash with the desired resolution was found, return it
    if ($selectedHash) {
        if (DEBUG) {
            echo 'Chosen Hash: ' . $selectedHash . "</br></br>";
        }
        return addMagnetLink_RD($torrents, 'magnet:?xt=urn:btih:' . $selectedHash, $tSite);
    }

    // If no torrents were found with a resolution below the maxResolution, select the lowest available resolution.
    $lowestAvailableResolution = INF;
    foreach ($torrents as $torrent) {
        $resolution = extractResolution($torrent['quality']);
        if ($resolution < $lowestAvailableResolution) {
            $selectedHash = $torrent['hash'];
            $lowestAvailableResolution = $resolution;
        }
    }

    if (DEBUG) {
        echo 'Selected Hash: ' . $selectedHash . "</br></br>";
    }
    return addMagnetLink_RD($torrents, 'magnet:?xt=urn:btih:' . $selectedHash, $tSite);
}

function extractResolution($quality)
{
    $regex = '/(\d+)P/i';
    preg_match($regex, $quality, $match);

    if ($match && $match[1]) {
        return intval($match[1]);
    }
    return null;
}

function findMp4FileIndex($files)
{
    foreach ($files as $index => $file) {
        if (substr($file['path'], -4) === '.mp4') {
            return $index; // Return the index of the MP4 file
        }
    }
    return - 1; // Return -1 if no MP4 file is found
}

function findAnyVideoFileIndex($files)
{
    foreach ($files as $index => $file) {
        if (isVideoFile($file['path'])) {
            return $index; // Return the index of the video file
        }
    }
    return - 1; // Return -1 if no video file is found
}

function isVideoFile($filePath)
{
    $videoExtensions = ['mkv', 'mp4', 'avi', 'mov', 'flv', 'wmv', '.mpeg', '.mpg'];
    foreach ($videoExtensions as $extension) {
        if (substr($filePath, -strlen($extension)) === $extension) {
            return true;
        }
    }
    return false;
}

////////////////////////////// Video Link Extractors ///////////////////////////////

function goMovies_sx($title, $year)
{
	    global $timeOut, $maxResolution, $type, $seasonNoPad, $episodeNoPad;
		
    if (DEBUG) {
        echo 'Started running goMovies_sx </br></br>';
    }
    global $timeOut;
    global $maxResolution;
    $tSite = 'goMovies_sx';

    $apiUrl = 'https://gomovies.sx/ajax/search';

    try {
        $postData = json_encode(['keyword' => $title, ]);

        $ch = curl_init();

        // Set cURL options
        curl_setopt($ch, CURLOPT_URL, $apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeOut);
        curl_setopt($ch, CURLOPT_USERAGENT,
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0');
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

        $response = curl_exec($ch);


        if ($response === false) {
            throw new Exception('HTTP Error: goMovies_sx');
        }


        $doc = new DOMDocument();
        $doc->loadHTML($response);

        $divElements = $doc->getElementsByTagName('div');
        $matchingHref = null;

        $divElements = $doc->getElementsByTagName('a');


        foreach ($divElements as $a) {
            // Check if this <a> element has the expected class "nav-item"
            if ($a->getAttribute('class') == 'nav-item') {
                // Find the title and year elements within this <a> element
                $titleElement = $a->getElementsByTagName('h3')->item(0);
                $yearElement = $a->getElementsByTagName('span')->item(0);				

                if (DEBUG) {
                    echo "Looking for a match by class: nav-item </br></br>";
                }

                // Check if the title and year match your criteria
				if (strtolower(trim($title)) == strtolower(trim($titleElement->textContent)) &&
					($type != 'movies' || strtolower(trim($year)) == strtolower(trim($yearElement->textContent)))){

                    // Get the href link
                    if ($a->getAttribute('href')) {
                        $Pagehref = "https://gomovies.sx" . $a->getAttribute('href');
                        if (preg_match('/(\d+)$/', $Pagehref, $matches)) {
                            $number = $matches[0];
                            if (DEBUG) {
                                echo "Located watch id $number on goMovies_sx </br></br>";
                            }
							
							if ($type == "movies"){

								$url = "https://gomovies.sx/ajax/movie/episodes/" . $number;
							} else {
								
								$url = "https://gomovies.sx/ajax/season/list/" . $number;
							}
                            $context = stream_context_create(['http' => ['timeout' => $timeOut, 'header' =>
                                "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0\r\n",
                                "X-Requested-With: XMLHttpRequest"], ]);

                            $response = @file_get_contents($url, false, $context);					
													
							if ($type == "series"){
								$pattern = '/<a\s+data-id="(\d+)"\s*[^>]*\s*>Season\s+' . $seasonNoPad . '<\/a>/';
							if(!preg_match($pattern, $response, $matches)){
								throw new Exception('Couldn\'t locate season id on goMovies_sx');						 
							} else {
							if (DEBUG) {
								 echo 'Located season id: ' . $matches[1] . "</br></br>";
							 }
							 $url ='https://gomovies.sx/ajax/season/episodes/' . $matches[1];
							 $response = @file_get_contents($url, false, $context);
							 $pattern = '/<a\s+id="episode-(\d+)"\s*[^>]*\s*Eps\s+' .$episodeNoPad.'\:/';
							if(!preg_match($pattern, $response, $matches)){
								throw new Exception('Couldn\'t episode id on goMovies_sx');						 
							} else {
							if (DEBUG) {
								 echo 'Located episode id: ' . $matches[1] . "</br></br>";
							 }
							 $url ='https://gomovies.sx/ajax/episode/servers/' . $matches[1];
							 $response = @file_get_contents($url, false, $context);
							}								
							}
							}
							
                            if (DEBUG) {
                                print_r('Video servers located: ' . $response . "</br></br>");
                            }
                            if ($response === false) {
                                throw new Exception('HTTP Error: goMovies_sx');
                            }
                            $doc = new DOMDocument();
                            $doc->loadHTML($response);

                            $xpath = new DOMXPath($doc);

                            $liElements = $xpath->query('//li[@class="nav-item"]');

                            if ($liElements !== null) {
                                foreach ($liElements as $li) {
                                    // Find the <a> element within the current <li> element
                                    $aElement = $xpath->query('.//a', $li)->item(0);

                                    if ($aElement !== null) {
                                        $title = $aElement->getAttribute('title');
										if($type == 'movies'){
											$dataLinkid = $aElement->getAttribute('data-linkid');
										} else {
											 $dataLinkid = $aElement->getAttribute('data-id');
										}
                                        // Check if the title matches "UpCloud" and perform actions accordingly

                                        if (strpos($title, 'UpCloud') !== false) {
                                            
                                            if (DEBUG) {
                                                echo 'Page containing UpCloud: ' . $dataLinkid . "</br></br>";

                                            }
                                            $url = "https://gomovies.sx/ajax/sources/" . $dataLinkid;
                                            $response = @file_get_contents($url, false, $context);
                                            if ($response === false) {
                                                throw new Exception('HTTP Error: goMovies_sx');
                                            }

                                            // Decode the JSON data into an associative array
                                            $data = json_decode($response, true);

                                            if ($data !== null && isset($data['link'])) {
                                                if (DEBUG) {
                                                    print_r('The returned Json for UpCloud: ' . $response . "</br></br>");
                                                }
                                                //Run UpCloud extractor here.
                                                $returnExtractor = UpCloudExtract($data['link'], $tSite);
                                                if ($returnExtractor !== false) {
                                                    return $returnExtractor;
                                                }

                                            } else {
                                                throw new Exception('Couldn\'t find the Json on UpCloud for goMovies_sx');
                                            }

                                        }
                                        // Check if the title matches "Upstream" and perform actions accordingly
                                        if ($title === 'Upstream') {
                                            if (DEBUG) {
                                                echo 'Page containing Upstream: ' . $dataLinkid . "</br></br>";

                                            }
                                            $url = "https://gomovies.sx/ajax/sources/" . $dataLinkid;
                                            $response = @file_get_contents($url, false, $context);
                                            if ($response === false) {
                                                throw new Exception('HTTP Error: goMovies_sx');
                                            }

                                            // Decode the JSON data into an associative array
                                            $data = json_decode($response, true);


                                            if ($data !== null && isset($data['link'])) {
                                                if (DEBUG) {
                                                    print_r('The returned Json for Upstream: ' . $response . "</br></br>");
                                                }
                                                //Run Upstream extractor here.
                                                $returnExtractor = UpstreamExtract($data['link'], $tSite);

                                                if ($returnExtractor !== false) {
                                                    return $returnExtractor;
                                                }


                                            } else {
                                                throw new Exception('Couldn\'t find the Json on Upstream for goMovies_sx');
                                            }

                                        }

                                    } else {
                                        throw new Exception('Couldn\'t locate links on goMovies_sx');
                                    }
                                }
                            } else {
                                if (DEBUG) {
                                    echo "No <li> elements with class 'nav-item' found.\n";
                                }
                            }


                        } else {
                            throw new Exception('Couldn\'t get the watch id on goMovies_sx');
                        }

                    }
                }
            }
        }

    }
    catch (exception $error) {

        if (DEBUG) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
        }

        return false;
    }

    return false;
}

//Extractor for goMovies_sx
function UpstreamExtract($url, $tSite)
{
    global $timeOut;

    $unpacker = new JavaScriptUnpacker();
    if (DEBUG) {
        echo "Started UpstreamExtract for $tSite. </br></br>";
    }

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, 'header' =>
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0\r\n" .
            "Referer: https://" . str_replace('_', '.', strtolower($tSite)), ], ]);

        $response = @file_get_contents($url, false, $context);


        if ($response === false) {
            throw new Exception('HTTP Error: UpstreamExtract');
            if (DEBUG) {
                echo 'Error: ' . $error->getMessage() . "</br></br>";
            }
        }

        if (preg_match('#\beval\(function\(p,a,c,k,e,d\).*?\)\)\)#', $response, $matches)) {

            // Use the methods of the JavaScriptUnpacker class as needed
            $unpackedCode = $unpacker->unpack($matches[0]);			


		if (preg_match('#(?<=sources:\[{file:").*?upstream.*?(?="}])#', $unpackedCode, $matches)) {
			$sourceUrl = $matches[0];

			// Check if the URL starts with 'http' indicating it's a complete URL
			if (strpos($sourceUrl, 'http') !== 0) {  // It's not a full URL, so we will try to extract the domain
				if (preg_match('#image:"(https?://[^/]+)#', $unpackedCode, $imageMatches)) {
					$domain = $imageMatches[1];
					$sourceUrl = $domain . $sourceUrl;  // Append the relative URL to the domain to form the full URL
				} else {
					throw new Exception('Couldn\'t extract the domain from image URL on Upstream');
				}
			}

			if (DEBUG) {
				echo "Video link: " . $sourceUrl . "<br><br>";
			}
			return $sourceUrl;

		} else {
			throw new Exception('Couldn\'t extract the source links on Upstream');
		}

    }
	}
    catch (exception $error) {
        if (DEBUG) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running UpstreamExtract. </br></br>';
        }
        return false;
    }
    if (DEBUG) {
        echo 'Finished running UpstreamExtract. </br></br>';
    }
    return false;

}

//Extractor for goMovies_sx
function UpCloudExtract($url, $tSite)
{
    global $timeOut;

    if (DEBUG) {
        echo "Started UpCloudExtract for $tSite. </br></br>";
    }

    // Parse the URL
    $urlParts = parse_url($url);

    if ($urlParts !== false && isset($urlParts['path'])) {
        // Split the path into segments
        $pathSegments = explode('/', $urlParts['path']);

        // Get the last segment (id)
        $id = end($pathSegments);

        // Construct the new URL
        $outputUrl = "{$urlParts['scheme']}://{$urlParts['host']}/ajax/embed-4/getSources?id=$id";

        if (DEBUG) {
            echo "UpCloudExtract - Output URL: $outputUrl </br></br>";
        }
    } else {

        if (DEBUG) {
            echo "UpCloudExtract: Invalid URL for $tSite. </br></br>";
        }

        return false;
    }

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, 'header' =>
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0\r\n" .
            "X-Requested-With: XMLHttpRequest\r\n" . "Referer: https://gomovies.sx/\r\n", ], ]);

        $response = @file_get_contents($outputUrl, false, $context);

        if ($response === false) {
            throw new Exception('HTTP Error: UpCloudExtract');
        }
        if (DEBUG) {
            print_r('UpCloudExtract Json sources: ' . $response . "</br></br>");
        }

        // Decode the JSON response into an associative array
        $data = json_decode($response, true);

        // Decode the JSON response into an associative array
        $data = json_decode($response, true);

        if ($data !== null) {
            if (isset($data['sources'])) {
                if (is_array($data['sources'])) {
                    // Handle multiple sources (an array)
                    $firstSource = $data['sources'][0]; // Get the first source from the array
                } else {
                    // Handle a single source (a string)
                    $firstSource = $data['sources']; // The entire source is a single string
                }

                $getKeyset = @file_get_contents('https://raw.githubusercontent.com/enimax-anime/key/e4/key.txt');

                return decryptUpcloudSource($firstSource, json_decode($getKeyset)) .
                    "</br></br>";
            } else {
                if (DEBUG) {
                    echo "Error: 'sources' key not found. </br></br>";
                }
                return false;
            }
        } else {
            if (DEBUG) {
                echo "Error: Invalid JSON. </br></br>";
            }
            return false;
        }
    }
    catch (exception $error) {
        if (DEBUG) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running UpCloudExtract. </br></br>';
        }
        return false;
    }


}

function thepiratebay_org($movieId, $imdbId, $title, $year)
{
    global $timeOut, $maxResolution, $torrentData, $language, $languageMapping, $type, $season, $episode;

    $tSite = 'thepiratebay_org';
	
	if (DEBUG) {
        echo 'Started running thepiratebay_org </br></br>';
    }
	   $key = $movieId . '_thepiratebay';
	   
$thepiratebay = [
    "name" => "The Pirate Bay",
    "enabled" => true,
    "languages" => ["en"],
    "base_url" => "https://apibay.org",
    "fallback_urls" => [],
    "response_type" => "json",
    "owner" => "Aki0782",
    "movie" => [
        "query" => "/q.php?q={query}&cat=207,202,201",
        "keywords" => "{title} {year}"
    ],
    "episode" => [
        "query" => "/q.php?q={query}&cat=208,205",
        "keywords" => [
            "{title} {episodeCode}"
        ]
    ],
    "season" => [
        "query" => "/q.php?q={query}&cat=208,205",
        "keywords" => [
            "{title} {seasonCode}",
            "{title} season"
        ]
    ],
    "json_format" => [
        "title" => "name",
        "seeds" => "seeders",
        "peers" => "leechers",
        "size" => "size",
        "hash" => "info_hash"
    ],
    "title_replacement" => [
        "'s" => "s",
        "\"" => ""
    ]
];

$base_url = $thepiratebay["base_url"];

if ($type == 'movies') {
    $searchQuery = str_replace("{title} {year}", $title . " " . $year, $thepiratebay['movie']['keywords']);
    $apiUrl = $base_url . str_replace("{query}", $searchQuery, $thepiratebay['movie']['query']);
} else if ($type == 'series') {
    $searchQuery = str_replace("{title} {episodeCode}", $title, $thepiratebay['episode']['keywords'][0]);
    $apiUrl = $base_url . str_replace("{query}", $searchQuery, $thepiratebay['episode']['query']);
}

try {
    $context = stream_context_create(['http' => ['timeout' => $timeOut, ], ]);
    $response = @file_get_contents($apiUrl, false, $context);

    if ($response === false) {
        throw new Exception('HTTP Error: thepiratebay');
    }

}
catch (exception $error) {
    if (DEBUG) {
        echo 'Error: ' . $error->getMessage() . "</br></br>";
    }
    return false;
}

// Assuming the response type for thepiratebay is always JSON
$data = json_decode($response, true);

try {
    foreach ($data as $torrent) {
		
        $matchedRes = $torrent[$thepiratebay['json_format']['title']];
        $matchedHash = $torrent[$thepiratebay['json_format']['hash']];

        // Here you might want to extract resolution like 1080p, 720p etc. from the title similar to before
        preg_match('/(2160|1080|720|480|360|240)[pP]/i', $matchedRes, $resolution);

        if (isset($resolution[0])) {
            if (DEBUG) {
                echo "matchedRes: " . $resolution[0] . "</br></br>";
                echo "matchedHash: " . $matchedHash . "</br></br>";
            }
            $torrentData[] = ['title_long' => $title, 'hash' => $matchedHash, 'quality' => $resolution[0]];
        }
    }

    return true;
}
catch (exception $error) {
    if (DEBUG) {
        echo 'Error: ' . $error->getMessage() . "</br></br>";
    }
    return false;
}



}

//Decryption for UpCloudExtract
function decryptUpcloudSource($encryptedString, $keySet)
{
    try {
        $key = "";
        $modifiedEncryptedString = $encryptedString;

        foreach ($keySet as $range) {
            $start = $range[0];
            $length = $range[1] - $start;

            // Extract characters without modifying original string
            $key .= substr($encryptedString, $start, $length);
        }

        // Now, modify the string by removing extracted characters in reverse order
        // This ensures we don't disturb the start indices of subsequent ranges
        for ($i = count($keySet) - 1; $i >= 0; $i--) {
            $start = $keySet[$i][0];
            $length = $keySet[$i][1] - $start;

            $modifiedEncryptedString = substr_replace($modifiedEncryptedString, '', $start,
                $length);
        }

        $ch = curl_init();

        $url = "https://script.google.com/macros/s/AKfycbwTjf9_jWqniBQUPv5bbqvS1Cmyqa2kY1IRIyW3sLkS7NssMXWxFQgKmGxjT0S4gVoRgg/exec?key=" .
            urlencode($key) . "&text=" . urlencode(utf8_encode($modifiedEncryptedString));

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

        $response = curl_exec($ch);

        if ($response === false) {
            throw new Exception("Curl error: " . curl_error($ch));
        }

        curl_close($ch);

        // Parse the JSON response to extract the file URL
        $data = json_decode($response, true);

        if ($data !== null && isset($data[0]['file'])) {
            // Extract the 'file' URL from the first element of the array
            $fileURL = $data[0]['file'];

            return $fileURL;
        } else {
            throw new Exception("Invalid JSON or 'file' key not found in response.");
        }
    }
    catch (exception $error) {
        // Handle the exception here
        echo "Error: " . $error->getMessage();
        return false;
    }
}

function upMovies_to($title, $year)
{
    if (DEBUG) {
        echo 'Started running upMovies_to </br></br>';
    }
    global $timeOut;
    global $maxResolution;
    $tSite = 'upMovies_to';

    $etitle = str_replace("%20", "+", urlencode($title));

    $apiUrl = 'https://upmovies.to/search-movies/' . $etitle . ' (' . $year .
        ').html';

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, 'header' =>
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0', ], ]);

        $response = @file_get_contents($apiUrl, false, $context);

        if ($response === false) {
            throw new Exception('HTTP Error: upMovies_to');
        }

    }
    catch (exception $error) {

        if (DEBUG) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
        }

        return false;
    }

    try {
        // Perform pattern matching to extract torrent data
        preg_match('/https:\/\/upmovies\.to\/watch.*?.html/', $response, $matches);

        if (empty($matches)) {
            throw new Exception("No links found on upMovies_to."); // Throw a custom exception
        }

        $response = @file_get_contents($matches[0], false, $context);

        if ($response === false) {
            throw new Exception('HTTP Error: upMovies_to');
        }

        $extractionFound = false;
        // Perform the regex match
        preg_match_all('/<div class="server_line">.*?<\/div>/s', $response, $matches);

        foreach ($matches[0] as $divBlock) {
            // Check if the div block contains the string "ePlayVid"
            if (DEBUG) {
                echo "Looking for a match in div: " . $divBlock . "</br></br>";
            }
            if (strpos($divBlock, 'ePlayVid') !== false) {
                // Define a regex pattern to extract the href URL
                $urlPattern = '/<a href="([^"]+)"/';

                if (preg_match($urlPattern, $divBlock, $urlMatches)) {
                    if (DEBUG) {
                        echo 'Page containing ePlayVid: ' . $urlMatches[1] . "</br></br>";

                    }
                    $extractionFound = 'ePlayVid';

                }


            }
            if (strpos($divBlock, 'UpStream') !== false) {
                // Define a regex pattern to extract the href URL
                $urlPattern = '/<a href="([^"]+)"/';

                if (preg_match($urlPattern, $divBlock, $urlMatches)) {
                    if (DEBUG) {
                        echo 'Page containing UpStream: ' . $urlMatches[1] . "</br></br>";

                    }
                    $extractionFound = 'UpStream';

                }


            }
            //Loop through links trying to find one.
            if ($extractionFound === false) {

            } elseif ($extractionFound === 'ePlayVid') {
				$srcUrl = decode64UpMovies($urlMatches[1]);
				if ($srcUrl !== false){
				   $extractorReturn = ePlayVidExtract($srcUrl);
				if ($extractorReturn !== false) {
                    return $extractorReturn;
                }
				}   

            } elseif ($extractionFound === 'UpStream') {
				
				$srcUrl = decode64UpMovies($urlMatches[1]);
				if ($srcUrl !== false){
				   $extractorReturn = UpstreamExtract($srcUrl, 'upMovies_to');
				if ($extractorReturn !== false) {
                    return $extractorReturn;
                }
				}   
		
            }

        }


    }
    catch (exception $error) {
        if (DEBUG) {
            echo "Couldn't locate an extractor for upMovies_to. </br></br>";
        }
        return false;
    }
    if (DEBUG) {
        echo "Couldn't locate a link on upMovies_to. </br></br>";
    }
}
//Base64 Decode for upMovies_to
function decode64UpMovies($url) {
	global $timeOut;
    try {
        $context = stream_context_create([
            'http' => [
                'timeout' => $timeOut, 
                'header' => 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0',
            ], 
        ]);

        $response = @file_get_contents($url, false, $context);

        // Check if the request was successful
        if ($response === false) {
            throw new Exception("Failed to fetch the URL: $url");
        }

        preg_match('#(?<=document\.write\(Base64\.decode\(").*?(?=")#', $response, $matches);

        if (isset($matches[0])) {
            $iframe = base64_decode($matches[0]);
            if (preg_match('#(?<=src=").*?(?=")#', $iframe, $iframeMatches)) {
                return $iframeMatches[0];
            }
        }

        throw new Exception("Couldn't find url in decoded base64 on page.");

    } catch (Exception $e) {        
        return false; // or return "Error: " . $e->getMessage();
    }
}

//Extractor for upMovies_to
function ePlayVidExtract($url)
{
    global $timeOut;

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, 'header' =>
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0', ], ]);

        $response = @file_get_contents($url, false, $context);

        if ($response === false) {
            throw new Exception('HTTP Error: eplayvidExtact');
            if (DEBUG) {
                echo 'Error: ' . $error->getMessage() . "</br></br>";
            }
        }

        if (preg_match('#(?<=<source src=")[\s\S]*?(?=")#', $response, $matches)) {

            if (DEBUG) {
                echo "Video link: " . $matches[0] . "<br><br>";
            }
			//Run link checker before returning.
			$urlData = $matches[0] .
                "|Referer='https://eplayvid.net/'|User-Agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0'|Origin='https://eplayvid.net/'";
				
			$lCheck = checkLinkStatusCode($urlData);
			if ($lCheck == true){
				return 'video_proxy.php?data=' . base64_encode($urlData);
			} else {
				return false;
			}
			
						
        }


    }
    catch (exception $error) {
        if (DEBUG) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running ePlayVid. </br></br>';
        }
        return false;
    }

    return false;

}

function popcornTime($movieId, $imdbId, $title)
{
    global $timeOut, $maxResolution, $torrentData, $type, $season, $episode;
    $tSite = 'popcornTime';

    if (DEBUG) {
        echo 'Started running popcornTime </br></br>';
    }

	 if ($type == 'movies'){
		$apiUrl = 'https://shows.cf/movie/' . $imdbId;		
	 } else {
		$apiUrl = 'https://shows.cf/show/' . $imdbId;
	 }

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut]]);
        $response = @file_get_contents($apiUrl, false, $context);

        if ($response === false) {
            throw new Exception('HTTP Error: popcornTime');
        }

        $data = json_decode($response, true);
		
		if ($type == 'series'){
		//Run for series.
		$filtered = array_filter($data['episodes'], function ($ep) use ($season, $episode) {
        return $ep['season'] == $season && $ep['episode'] == $episode;});
		$torrents = current($filtered)['torrents'] ?? null;
		
		
		} else {

		//Run for movies.
        if (!isset($data['torrents'])) {
            throw new Exception('Data does not meet criteria');
        }

        if (DEBUG) {
            echo 'The Json Response: ' . print_r($response) . '</br></br>';
        }

        // Extract the torrents array
        		
		if (isset($data['torrents']['en'])) {
			$torrents = $data['torrents']['en'];
			
		} else {
			
		if (DEBUG) {
            echo 'Couldn\'t locate any torrents on popcornTime. </br></br>';
        }
		return false;
		}
		}
        		
	
		// Loop through each torrent available
		if (is_array($torrents) && !empty($torrents)) {
			foreach ($torrents as $resolutionKey => $torrentInfo) {
				preg_match('/(?<=urn:btih:)([A-F|a-z\d]{40})/', $torrentInfo['url'], $matchedHash);

				// Check if the regex match was successful
				if (isset($matchedHash[0])) {
					$torrentData[] = [
						'title_long' => $title,
						'hash' => $matchedHash[0],
						'quality' => $resolutionKey
					];
				}
			}
		} else {
			throw new Exception('Data does not meet criteria');
		}
        if (DEBUG) {
            echo 'Torrents: ' . json_encode($torrentData) . "</br></br>";
        }
        //exit();
        // Call the function to handle the successful response
        return true;

    }
    catch (exception $error) {
        if (DEBUG) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running popcornTime </br></br>';
        }
        return false;
    }
}
function theMovieArchive_site($movieId, $title)
{
    global $timeOut;

    if (DEBUG) {
        echo 'Started running theMovieArchive_site </br></br>';
    }

    $url = "https://prod.omega.themoviearchive.site/v3/movie/sources/" . $movieId;
    $options = ['http' => ['method' => "GET", 'header' =>
        "Content-Type: application/json"]];

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut]]);
        $response = @file_get_contents($url, false, $context);
        if ($response === false) {
            throw new Exception('HTTP Error: theMovieArchive_site</br></br>');
        }
    }
    catch (exception $error) {
        if (DEBUG) {
            echo 'Failed to fetch movie source data from theMovieArchive_site Error: ' . $error->
                getMessage() . "</br></br>";
            echo 'Finished running theMovieArchive_site </br></br>';

        }

        return false;
    }

    $statusCode = http_response_code(); // Get the current response status code
    if ($statusCode !== 200) {
        if (DEBUG) {
            echo "Failed to fetch movie source data from theMovieArchive_site Response code: " .
                $statusCode . "<br></br>";
            echo 'Finished running theMovieArchive_site </br></br>';
        }

        return false;
    }

    $data = json_decode($response, true);

    if ($data && isset($data['sources'])) {
        $foundUrl = false;
        // Define the qualities to check
        $qualitiesToCheck = ['2160', '1080', '720', 'auto'];

        foreach ($data['sources'] as $source) {
            foreach ($source['sources'] as $videoSource) {
                $quality = $videoSource['quality'];
                $url = $videoSource['url'];

                if (in_array($quality, $qualitiesToCheck)) {

                    if (DEBUG) {
                        echo 'Video Link: ' . $url . "</br></br>";

                    }
                    return $url;


                }
            }
        }

        if (DEBUG) {
            echo "No suitable URL found. </br></br>";
        }
        echo 'Finished running theMovieArchive_site </br></br>';
        return false;
    } else {

        if (DEBUG) {
            echo "No sources found in the JSON data.";
        }
        echo 'Finished running theMovieArchive_site </br></br>';
        return false;
    }
}

function torrentGalaxy_to($movieId, $imdbId, $title)
{
    global $timeOut, $maxResolution, $torrentData, $language, $languageMapping, $type, $season, $episode;

    $tSite = 'Torrent Galaxy';
	
	if (DEBUG) {
        echo 'Started running torrentGalaxy_to </br></br>';
    }
	
    $key = $movieId . '_torrentGalaxy_to';
	if ($type == 'movies'){
		$searchQuery = $imdbId;
	} else {
		$searchQuery = $title;
	}
	
    $siteLanguage = $languageMapping['TorrentGalaxy'][$language] ?? null;	

	$apiUrl = 'https://torrentgalaxy.to/torrents.php?search=' . $searchQuery . '&nox=2';	

	if ($siteLanguage !== null) {
		$apiUrl .= '&lang=' . $siteLanguage;
	}

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, ], ]);
        $response = @file_get_contents($apiUrl, false, $context);

        if ($response === false) {
            throw new Exception('HTTP Error: torrentGalaxy_to');
        }


    }
    catch (exception $error) {
        if (DEBUG) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
        }
        return false;
    }

    $data = $response;
	

    try {
        // Perform pattern matching to extract torrent data
        preg_match_all('/(?<=tgxtablerow)[\s\S]*?(?=<\/table>)/', $data, $matches);

        if (count($matches[0]) === 0) {
            throw new Exception("No links found on torrentGalaxy_to."); // Throw a custom exception
        }

 
        // Loop through the 'matches' array
        for ($i = 0; $i < count($matches[0]); $i++) {

            // Extracted data from 'matches'
            $extractedData = $matches[0][$i];
			
			// Replace '4K' or '4k' with '2160p' before extracting the resolution
			$extractedData = str_ireplace("4K", "2160p", $extractedData);

            // Apply the regex patterns to extract 'matchedRes' and 'matchedHash'
            preg_match('/(2160|1080|720|480|360|240)[pP]/i', $extractedData, $matchedRes);
            preg_match('/(?<=urn:btih:)([A-F|a-z\d]{40})/', $extractedData, $matchedHash);
			
            // Check if both 'matchedRes' and 'matchedHash' were found
            if ($matchedRes && $matchedRes[0] && $matchedHash && $matchedHash[0]) {
                if (DEBUG) {
                    echo "matchedRes: " . $matchedRes[0] . "</br></br>";
                    echo "matchedHash: " . $matchedHash[0] . "</br></br>";
                }
                // Create an object and add it to the 'torrentData' array
                $torrentData[] = ['title_long' => $title, 'hash' => $matchedHash[0], 'quality' =>
                    $matchedRes[0]];
            }
        }
        
        return true;
    }
    catch (exception $error) {
        if (DEBUG) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running torrentGalaxy_to </br></br>';
        }
        return false;
    }
}

function glodls_to($movieId, $imdbId, $title, $year)
{
    global $timeOut, $maxResolution, $torrentData, $language, $languageMapping, $type, $season, $episode;

    $tSite = 'glodls_to';
	
	if($type == "movies"){
		$searchQuery = $title . ' (' . $year . ')';
	} else {
		$searchQuery = $title;
	}
	
	if (DEBUG) {
        echo 'Started running glodls_to </br></br>';
    }
	
    $key = $movieId . '_glodls_to';
	
    $siteLanguage = $languageMapping['Glodls'][$language] ?? null;	

	$apiUrl = 'https://glodls.to/search_results.php?search=' . urlencode($searchQuery) . '&incldead=0&inclexternal=0&sort=id&order=desc';	
	

	if ($siteLanguage !== null) {
		$apiUrl .= '&lang=' . $siteLanguage;
	}
	if ($type == 'series') {
			
		$apiUrl .= '&cat=41';
	} elseif ($type == 'movies') {
			
		$apiUrl .= '&c52=1';
	}
	
    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, ], ]);
        $response = @file_get_contents($apiUrl, false, $context);


        if ($response === false) {
            throw new Exception('HTTP Error: glodls_to');
        }


    }
    catch (exception $error) {
        if (DEBUG) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
        }
        return false;
    }

    $data = $response;

    try {
        // Perform pattern matching to extract torrent data
        preg_match_all('/(?<=ttable_col1)[\s\S]*?(?=<\/tr>)/', $data, $matches);

        if (count($matches[0]) === 0) {
            throw new Exception("No links found on glodls_to."); // Throw a custom exception
        }

         // Loop through the 'matches' array
        for ($i = 0; $i < count($matches[0]); $i++) {

            // Extracted data from 'matches'
            $extractedData = $matches[0][$i];
			
			// Replace '4K' or '4k' with '2160p' before extracting the resolution
			$extractedData = str_ireplace("4K", "2160p", $extractedData);

            // Apply the regex patterns to extract 'matchedRes' and 'matchedHash'
            preg_match('/(2160|1080|720|480|360|240)[pP]/i', $extractedData, $matchedRes);
            preg_match('/(?<=urn:btih:)([A-F|a-z\d]{40})/', $extractedData, $matchedHash);
			
            // Check if both 'matchedRes' and 'matchedHash' were found
            if ($matchedRes && $matchedRes[0] && $matchedHash && $matchedHash[0]) {
                if (DEBUG) {
                    echo "matchedRes: " . $matchedRes[0] . "</br></br>";
                    echo "matchedHash: " . $matchedHash[0] . "</br></br>";
                }
                // Create an object and add it to the 'torrentData' array
                $torrentData[] = ['title_long' => $title, 'hash' => $matchedHash[0], 'quality' =>
                    $matchedRes[0]];
            }
        }
        
        return true;
    }
    catch (exception $error) {
        if (DEBUG) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running glodls_to </br></br>';
        }
        return false;
    }
}

function magnetdl_com($movieId, $imdbId, $title, $year)
{
    global $timeOut, $maxResolution, $torrentData, $language, $languageMapping, $type, $season, $episode;

    $tSite = 'magnetdl_com';
	
	if (DEBUG) {
        echo 'Started running magnetdl_com </br></br>';
    }
	
    $key = $movieId . '_magnetdl_com';
	
	if($type == "movies"){
		$searchQuery = $title . ' (' . $year . ')';
	} else {
		$searchQuery = $title;
	}
	
	$apiUrl = 'https://www.magnetdl.com/search/?q=' . $searchQuery;	

	if ($type == 'series') {
			
		$apiUrl .= '&m=1&x=35&y=17';
	} elseif ($type == 'movies') {
			
		$apiUrl .= '&m=1&x=38&y=19';
	}

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, ], ]);
        $response = @file_get_contents($apiUrl, false, $context);

        if ($response === false) {
            throw new Exception('HTTP Error: magnetdl_com');
        }


    }
    catch (exception $error) {
        if (DEBUG) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
        }
        return false;
    }

    $data = $response;
	

    try {
        // Perform pattern matching to extract torrent data
        preg_match_all('/(?<=class="m")[\s\S]*?(?=<\/tr>)/', $data, $matches);

        if (count($matches[0]) === 0) {
            throw new Exception("No links found on magnetdl_com."); // Throw a custom exception
        }

 
        // Loop through the 'matches' array
        for ($i = 0; $i < count($matches[0]); $i++) {

            // Extracted data from 'matches'
            $extractedData = $matches[0][$i];
			
			// Replace '4K' or '4k' with '2160p' before extracting the resolution
			$extractedData = str_ireplace("4K", "2160p", $extractedData);

            // Apply the regex patterns to extract 'matchedRes' and 'matchedHash'
            preg_match('/(2160|1080|720|480|360|240)[pP]/i', $extractedData, $matchedRes);
            preg_match('/(?<=urn:btih:)([A-F|a-z\d]{40})/', $extractedData, $matchedHash);
			
            // Check if both 'matchedRes' and 'matchedHash' were found
            if ($matchedRes && $matchedRes[0] && $matchedHash && $matchedHash[0]) {
                if (DEBUG) {
                    echo "matchedRes: " . $matchedRes[0] . "</br></br>";
                    echo "matchedHash: " . $matchedHash[0] . "</br></br>";
                }
                // Create an object and add it to the 'torrentData' array
                $torrentData[] = ['title_long' => $title, 'hash' => $matchedHash[0], 'quality' =>
                    $matchedRes[0]];
            }
        }
        
        return true;
    }
    catch (exception $error) {
        if (DEBUG) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running magnetdl_com </br></br>';
        }
        return false;
    }
}

function torrentDownload_info($movieId, $imdbId, $title, $year)
{
    global $timeOut, $maxResolution, $torrentData, $language, $languageMapping, $type, $season, $episode;

    $tSite = 'torrentDownload_info';
	
	if (DEBUG) {
        echo 'Started running torrentDownload_info </br></br>';
    }
	
    $key = $movieId . '_torrentDownload_info';
	
	if($type == "movies"){
		$searchQuery = $title . ' (' . $year . ')';
	} else {
		$searchQuery = $title;
	}

	$apiUrl = 'https://www.torrentdownload.info/search?q=' . $searchQuery;	

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, ], ]);
        $response = @file_get_contents($apiUrl, false, $context);

        if ($response === false) {
            throw new Exception('HTTP Error: torrentDownload_info');
        }


    }
    catch (exception $error) {
        if (DEBUG) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
        }
        return false;
    }

    $data = $response;
	

    try {
        // Perform pattern matching to extract torrent data
        preg_match_all('/(?<=<td class="tdleft">)[\s\S]*?(?=<\/tr>)/', $data, $matches);

        if (count($matches[0]) === 0) {
            throw new Exception("No links found on torrentDownload_info."); // Throw a custom exception
        }

 
        // Loop through the 'matches' array
        for ($i = 3; $i < count($matches[0]); $i++) {

            // Extracted data from 'matches'
            $extractedData = $matches[0][$i];
			$noHtmlData = trim(preg_replace('/<[^>]*>/', '', $extractedData));
			
			if (strpos($noHtmlData, $title) !== false) {
				continue;
			}

									
			// Replace '4K' or '4k' with '2160p' before extracting the resolution
			$extractedData = str_ireplace("4K", "2160p", $extractedData);

            // Apply the regex patterns to extract 'matchedRes' and 'matchedHash'
            preg_match('/(2160|1080|720|480|360|240)[pP]/i', $extractedData, $matchedRes);
            preg_match('/(?<="\/)([A-F|a-z\d]{40})(?=\/)/', $extractedData, $matchedHash);
			
            // Check if both 'matchedRes' and 'matchedHash' were found
            if ($matchedRes && $matchedRes[0] && $matchedHash && $matchedHash[0]) {
                if (DEBUG) {
                    echo "matchedRes: " . $matchedRes[0] . "</br></br>";
                    echo "matchedHash: " . $matchedHash[0] . "</br></br>";
                }
                // Create an object and add it to the 'torrentData' array
                $torrentData[] = ['title_long' => $title, 'hash' => $matchedHash[0], 'quality' =>
                    $matchedRes[0]];
            }
        }
        
        return true;
    }
    catch (exception $error) {
        if (DEBUG) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running torrentDownload_info </br></br>';
        }
        return false;
    }
}

//Blocked while coding it.
function bitLordSearch_com($movieId, $imdbId, $title, $year)
{
    global $timeOut, $maxResolution, $torrentData, $type, $season, $episode;
    $tSite = 'bitLordSearch_com';

    if (DEBUG) {
        echo 'Started running bitLordSearch_com </br></br>';
    }

    try {
		
			$options = [
			'http' => [
				'method' => 'GET',
				'header' => [
					'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/118.0',
					'Origin: https://bitlordsearch.com/',
					//'Connection: keep-alive',
					'Referer: https://bitlordsearch.com/',
					'Content-type: application/x-www-form-urlencoded',					
				],
				'timeout' => $timeOut
			]
		];
		
		// Fetch the website content
		$context = stream_context_create($options);
		$content = @file_get_contents('https://bitlordsearch.com/', false, $context);

		// Match the token parts using regex
		preg_match_all("/var ([\w\d]+) = '([^']+)'/", $content, $initialMatch);
		preg_match_all("/{$initialMatch[1][0]} \+= '([^']+)'/", $content, $subsequentMatches);

		$token = $initialMatch[2][0] . implode('', $subsequentMatches[1]);
		
		if (empty($token)) {
			throw new Exception('Couldn\'t get the request token.');
		}
		
		$phpsessid = null;
		$device_view = null;

		foreach ($http_response_header as $header) {
			// Search for the PHPSESSID cookie
			if (preg_match('/^Set-Cookie: PHPSESSID=(.*?);/', $header, $matches)) {
				$phpsessid = $matches[1];
			}
			// Search for the device_view cookie
			if (preg_match('/^Set-Cookie: device_view=(.*?);/', $header, $matches)) {
				$device_view = $matches[1];
			}
		}

		if ($phpsessid && $device_view) {
			$cookie = "PHPSESSID=$phpsessid; device_view=$device_view";

		} else {
			throw new Exception('Couldn\'t get session cookies.');
		}
		
		$apiUrl = "https://bitlordsearch.com/get_list";
		 if ($type == 'movies'){
			$postData = 'query='.urlencode($title . ' (' . $year . ')').'&offset=0&limit=50&filters[field]=seeds&filters[sort]=desc&filters[time]=0&filters[category]=3&filters[adult]=false&filters[risky]=false';		
		 } else {
			$postData = 'query='.urlencode($title).'&offset=0&limit=50&filters[field]=seeds&filters[sort]=desc&filters[time]=0&filters[category]=4&filters[adult]=false&filters[risky]=false';
		 }
		
		// Define the custom headers and POST data
		$options = [
			'http' => [
				'method' => 'POST',
				'header' => [
					'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/118.0',
					'Origin: https://bitlordsearch.com/',
					//'Connection: keep-alive',
					'Referer: https://bitlordsearch.com/',
					'Content-type: application/x-www-form-urlencoded',
					'X-Requested-With: XMLHttpRequest',
					'X-Request-Token: ' . $token,
					'Cookie: ' . $cookie
				],
				'content' => $postData,
				'timeout' => $timeOut
			]
		];


		
		$context = stream_context_create($options);
		
        $response = @file_get_contents($apiUrl, false, $context);
		
		print_r($options);
		print_r($response);
		exit();

        if ($response === false) {
            throw new Exception('HTTP Error: bitLordSearch');
        }

        $data = json_decode($response, true);
		
		if ($type == 'series'){
		//Run for series.
		$filtered = array_filter($data['episodes'], function ($ep) use ($season, $episode) {
        return $ep['season'] == $season && $ep['episode'] == $episode;});
		$torrents = current($filtered)['torrents'] ?? null;
		
		
		} else {

		//Run for movies.
        if (!isset($data['torrents'])) {
            throw new Exception('Data does not meet criteria');
        }

        if (DEBUG) {
            echo 'The Json Response: ' . print_r($response) . '</br></br>';
        }

        // Extract the torrents array
        		
		if (isset($data['torrents']['en'])) {
			$torrents = $data['torrents']['en'];
			
		} else {
			
		if (DEBUG) {
            echo 'Couldn\'t locate any torrents on bitLordSearch. </br></br>';
        }
		return false;
		}
		}
        		
	
		// Loop through each torrent available
		if (is_array($torrents) && !empty($torrents)) {
			foreach ($torrents as $resolutionKey => $torrentInfo) {
				preg_match('/(?<=urn:btih:)([A-F|a-z\d]{40})/', $torrentInfo['url'], $matchedHash);

				// Check if the regex match was successful
				if (isset($matchedHash[0])) {
					$torrentData[] = [
						'title_long' => $title,
						'hash' => $matchedHash[0],
						'quality' => $resolutionKey
					];
				}
			}
		} else {
			throw new Exception('Data does not meet criteria');
		}
        if (DEBUG) {
            echo 'Torrents: ' . json_encode($torrentData) . "</br></br>";
        }
        //exit();
        // Call the function to handle the successful response
        return true;

    }
    catch (exception $error) {
        if (DEBUG) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running bitLordSearch </br></br>';
        }
        return false;
    }
}

function ezTV_re($movieId, $imdbId, $title)
{
    global $timeOut, $maxResolution, $torrentData, $language, $languageMapping, $type, $season, $episode;

    $tSite = 'EZTV';
	
	if (DEBUG) {
        echo 'Started running ezTV_re </br></br>';
    }
	
    $key = $movieId . '_ezTV_re';

	
	$apiUrl = 'https://eztv.re/search/?q1=' . urlencode($title) . '&search=Search';	

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, ], ]);
        $response = @file_get_contents($apiUrl, false, $context);

        if ($response === false) {
            throw new Exception('HTTP Error: ezTV_re');
        }


    }
    catch (exception $error) {
        if (DEBUG) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
        }
        return false;
    }

    $data = $response;

	

    try {
        // Perform pattern matching to extract torrent data
        preg_match_all('/(?<=<tr name="hover" class="forum_header_border">)[\s\S]*?(?=<\/tr>)/', $data, $matches);
		

        if (count($matches[0]) === 0) {
            throw new Exception("No links found on ezTV_re."); // Throw a custom exception
        }

        // Loop through the 'matches' array
		for ($i = 0; $i < count($matches[0]); $i++) {

			// Extracted data from 'matches'
			$extractedData = $matches[0][$i];

			// Check if extracted data contains the title, if not skip this iteration
			preg_match('/(?<=class="epinfo">).*?(?=<\/a>)/i', $extractedData, $matchedTitle);
			
			
			if (isset($matchedTitle[0])) {
				$episodeTitle = preg_replace("/[^a-z0-9 ]/", "", strtolower($matchedTitle[0]));
				$searchTitle = preg_replace("/[^a-z0-9 ]/", "", strtolower($title));

				if (strpos($episodeTitle, $searchTitle) === false) {
					continue;
				}
			}

			// Replace '4K' or '4k' with '2160p' before extracting the resolution
			$extractedData = str_ireplace("4K", "2160p", $extractedData);							

			// Apply the regex patterns to extract 'matchedRes' and 'matchedHash'
			preg_match('/(2160|1080|720|480|360|240)[pP]/i', $extractedData, $matchedRes);
			preg_match('/(?<=urn:btih:)([A-F|a-z\d]{40})/', $extractedData, $matchedHash);

			// If matchedRes wasn't found, set it to 480p
			if (!$matchedRes) {
				$matchedRes[0] = '480p';
			}
			

			// Check if 'matchedHash' was found
			if ($matchedHash && $matchedHash[0]) {
				if (DEBUG) {
					echo "matchedRes: " . $matchedRes[0] . "</br></br>";
					echo "matchedHash: " . $matchedHash[0] . "</br></br>";
				}
				// Create an object and add it to the 'torrentData' array
				$torrentData[] = ['title_long' => $title, 'hash' => $matchedHash[0], 'quality' => $matchedRes[0]];
			}
		}
		if (!empty($torrentData)){
			
			// Call the function to handle the successful response
			return true;
			
		} else {
			return false;
		}
    }
    catch (exception $error) {
        if (DEBUG) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running ezTV_re </br></br>';
        }
        return false;
    }
}

function yts_mx($movieId, $imdbId, $title)
{
    global $timeOut, $maxResolution, $torrentData;
    $tSite = 'Yts';

    if (DEBUG) {
        echo 'Started running yts_mx </br></br>';
    }

    $apiUrl = 'https://yts.mx/api/v2/list_movies.json?query_term=' . $imdbId .
        '&sort_by=seeds&order_by=desc';

    try {
        $context = stream_context_create(['http' => ['timeout' => $timeOut, ], ]);
        $response = @file_get_contents($apiUrl, false, $context);

        if ($response === false) {
            throw new Exception('HTTP Error: yts_mx');
        }

        $data = json_decode($response, true);

        if (!isset($data['status']) || $data['status'] !== 'ok' || !isset($data['data']) ||
            !isset($data['data']['movies']) || count($data['data']['movies']) === 0) {
            throw new Exception('Data does not meet criteria');
        }


    }
    catch (exception $error) {
        if (DEBUG) {
            echo 'Finished running yts_mx </br></br>';
            echo 'Error: ' . $error->getMessage() . "</br></br>";
        }
        return false;
    }


    try {
		$movie = $data['data']['movies'][0];
		$torrents = $movie['torrents'];

		// Extract relevant data from torrents and then filter out those without a hash
		$torrentData[] = array_filter(array_map(function ($torrent) use ($movie) {
			if (!isset($torrent['hash'])) {
				return false; // Skip this torrent
			}
			return [
				'title_long' => $movie['title_long'],
				'hash' => $torrent['hash'],
				'quality' => isset($torrent['quality']) ? $torrent['quality'] : null
			];
		}, $torrents));


        if (DEBUG) {
            echo 'Torrents: ' . json_encode($torrentData) . "</br></br>";
        }
        
        return true;

    }
    catch (exception $error) {
        if (DEBUG) {
            echo 'Error: ' . $error->getMessage() . "</br></br>";
            echo 'Finished running yts_mx </br></br>';
        }
        return false;
    }
}

function shegu_net_links($title, $year)
{
    if (DEBUG) {
        echo 'Started running shegu_net_links </br></br>';
    }

    global $maxResolution, $type, $seasonNoPad, $episodeNoPad;
    $movieId = null; // Initialize $movieId to null

    // Define constants
    $iv = base64_decode("d0VpcGhUbiE=");
    $key = base64_decode("MTIzZDZjZWRmNjI2ZHk1NDIzM2FhMXc2");
    $urls = [base64_decode("aHR0cHM6Ly9zaG93Ym94LnNoZWd1Lm5ldC9hcGkvYXBpX2NsaWVudC9pbmRleC8="),
        base64_decode("aHR0cHM6Ly9tYnBhcGkuc2hlZ3UubmV0L2FwaS9hcGlfY2xpZW50L2luZGV4Lw=="), ];
    $appName = base64_decode("bW92aWVib3g=");
    $appId = base64_decode("Y29tLnRkby5zaG93Ym94");

    $searchParams = ["module" => "Search3", "page" => "1", "type" => "all",
        "keyword" => $title, "pagelimit" => "20",
        ];

    $searchResponse = shegu_net_request($searchParams, false);

    if (isset($searchResponse['msg']) && $searchResponse['msg'] ===
        'no search result') {
        if (DEBUG) {
            echo 'Search shegu_net_request Response: </br></br>';
            print_r($searchResponse);
            echo '</br></br>';
            echo 'Finished running shegu_net_links </br></br>';

        }
        return false;
    }

    if (DEBUG) {
        echo 'Search shegu_net_request Response: </br></br>';
        print_r($searchResponse);
        echo "</br></br>";
    }

    foreach ($searchResponse['data'] as $movie) {
        if ($movie['year'] == $year) {
            $movieId = $movie['id'];
            break; // exit the loop once the correct year is found
        }
    }

    if ($movieId !== null) {
        // $movieId contains the id of the movie with the matching year
        if (DEBUG) {
            echo "Movie ID: " . $movieId . '</br></br>';
        }
    } else {
        if (DEBUG) {
            echo "No movie found for the specified year.</br></br>";
            echo 'Finished running shegu_net_links </br></br>';
        }
        return false;
    }

if ($type == 'movies'){
    // Call the sub-function again to get the download URLs using the movie ID
$urlParams = [
    "module" => "Movie_downloadurl_v3",
    "mid"    => $movieId,
    "oss"    => "1",
    "group"  => "",
    // ...
];

} else {
	  // Call the sub-function again to get the download URLs using the tv ID
$urlParams = [
    "module"  => "TV_downloadurl_v3",
    "tid"     => $movieId,
    "season"  => $seasonNoPad,
    "episode" => $episodeNoPad,
    "oss"     => "1",
    "group"   => ""
];

}
		
		
    $urlResponse = shegu_net_request($urlParams, false);


    // Process the URLs and return the appropriate one based on $maxResolution
    if (isset($urlResponse['data']['list'])) {

        $urls = $urlResponse['data']['list'];
        if (DEBUG) {
            echo 'Get Links shegu_net_request Response: </br></br>';
            print_r($urlResponse);
            echo "</br><br>";
        }

    } else {
        if (DEBUG) {
            echo 'Failed to get links from shegu_net_request. </br></br>';
            echo 'Finished running shegu_net_links </br></br>';
        }
        return false;
    }
    function convertQualityToInt($quality)
    {
        // If the quality is '4K', return 2160
        if (strtolower($quality) == '4k') {
            return 2160;
        }

        // Remove the 'p' or 'P' character and convert the remaining string to an integer
        return intval(str_ireplace('p', '', $quality));
    }

    // Initialize variables
    $closestDifference = PHP_INT_MAX;
    $closestQuality = null;
    $closestMovie = null;

    // Loop through the array of movies
    foreach ($urls as $movie) {

        if (empty($movie['path'])) {
            continue;
        }

        // Convert the real_quality value to an integer for comparison
        $realQuality = convertQualityToInt($movie['real_quality']);

        // Calculate the difference between the real_quality and the maxResolution
        $difference = abs($realQuality - $maxResolution);

        if (DEBUG) {
            echo "Movie video path: " . $movie['path'] . "<br><br>";
        }

        // Check if this movie is a closer match than the previous closest match
        if ($difference < $closestDifference) {
            $closestQuality = $realQuality;
            $closestDifference = $difference;
            $closestMovie = $movie;
        }
    }

    // Check if a closest match was found
    if ($closestMovie !== null) {
        // $closestMovie contains the movie version with the closest available quality

        if (DEBUG) {
            echo "Closest Quality: " . $closestQuality . "</br><br>";
            echo "Movie Path: " . $closestMovie['path'] . "</br><br>";

        }

    } else {
        if (DEBUG) {
            echo "No movie found with the closest quality.</br><br>";
        }
    }

    if (isset($closestMovie['path'])) {
        return $closestMovie['path'];
    } else {
        if (DEBUG) {
            echo 'Finished running shegu_net_links </br></br>';

        }
        return false;
    }
}

function shegu_net_request($data, $useSecondUrl = false)
{
    global $timeOut;
    // Define constants
    $iv = base64_decode("d0VpcGhUbiE=");
    $key = base64_decode("MTIzZDZjZWRmNjI2ZHk1NDIzM2FhMXc2");
    $urls = [base64_decode("aHR0cHM6Ly9zaG93Ym94LnNoZWd1Lm5ldC9hcGkvYXBpX2NsaWVudC9pbmRleC8="),
        base64_decode("aHR0cHM6Ly9tYnBhcGkuc2hlZ3UubmV0L2FwaS9hcGlfY2xpZW50L2luZGV4Lw=="), ];
    $appName = base64_decode("bW92aWVib3g=");
    $appId = base64_decode("Y29tLnRkby5zaG93Ym94");

    // Helper function to encrypt data using 3DES
    $encrypt = function ($data, $key, $iv)
    {
        return openssl_encrypt($data, 'des-ede3-cbc', $key, 0, $iv);
    }
    ;

    // Helper function to get verify token
    $getVerify = function ($encryptedData, $appName, $key)
    {
        return $encryptedData ? md5(md5($appName) . $key . $encryptedData) : null;
    }
    ;

    // Helper function to get the current timestamp plus 12 hours
    $getExpiredDate = function ()
    {
        return time() + 60 * 60 * 12;
    }
    ;

    // Define request parameters
    $params = ["childmode" => "0", "app_version" => "11.5", "appid" => $appId,
        "lang" => "en", "expired_date" => (string )time() + 60 * 60 * 12, "platform" =>
        "android", "channel" => "Website", "uid" => "", // ... (other parameters)
        ];

    // Merge input data with default parameters
    $requestData = array_merge($params, $data);

    // Encrypt the request data
    $encryptedData = $encrypt(json_encode($requestData), $key, $iv);

    // Get the app_key and verify token
    $appKey = md5($appName);
    $verify = $getVerify($encryptedData, $appName, $key);

    // Base64 encode the payload
    $payload = base64_encode(json_encode(['app_key' => $appKey, 'verify' => $verify,
        'encrypt_data' => $encryptedData]));

    // Choose the URL based on the $useSecondUrl flag
    $url = $useSecondUrl ? $urls[1] : $urls[0];

    // Define additional parameters to be sent in the request body
    $bodyParams = ['data' => $payload, 'appid' => '27', 'platform' => 'android',
        'version' => '129', 'medium' => 'Website', ];

    // Initialize cURL session
    $ch = curl_init($url);

    // Set cURL options
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($bodyParams));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Platform: android',
        'Content-Type: application/x-www-form-urlencoded', ]);
    curl_setopt($ch, CURLOPT_REFERER, 'https://movie-web.app');
    // Execute cURL session and get the response
    $timeoutSeconds = $timeOut; // Adjust this value as needed
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeoutSeconds);
    // Set a timeout for the connection phase (in seconds)
    $connectTimeoutSeconds = $timeOut; // Adjust this value as needed
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $connectTimeoutSeconds);
    $response = curl_exec($ch);

    // Check for cURL errors and handle them
    if (curl_errno($ch)) {
        $errorMessage = 'cURL Error: ' . curl_error($ch);
        if (DEBUG) {
            echo $errorMessage . "<br>";
        }
        throw new Exception($errorMessage);
    }

    // Close cURL session
    curl_close($ch);

    // Check for response errors and handle them
    if (!$response) {
        $errorMessage = 'HTTP Error: Failed to fetch movie source data.';
        if (DEBUG) {
            echo $errorMessage . "<br>";
        }
        throw new Exception($errorMessage);
    }

    // Return the response
    return json_decode($response, true);
}

////////////////////////////// Caching ///////////////////////////////

function writeToCache($key, $value)
{
    global $expirationDuration;

    // Specify the cache file path
    $cacheFilePath = 'cache.json';

    // Check if the cache file exists or create it if not
    if (!file_exists($cacheFilePath)) {
        file_put_contents($cacheFilePath, '{}');
    }

    // Get the current timestamp
    $now = time();
    $expirationTime = $now + $expirationDuration;

    // Serialize the value to a JSON string
    $serializedValue = json_encode($value);

    // Read existing cache data
    $cacheData = json_decode(file_get_contents($cacheFilePath), true) ? : [];

    // Update the cache data with the new value
    $cacheData[$key] = ['value' => $serializedValue, 'expirationTime' => $expirationTime, ];

    // Write the updated cache data back to the file
    file_put_contents($cacheFilePath, json_encode($cacheData));

    if (DEBUG) {
        echo 'Added to Cache - Key: ' . $key . ' Value: ' . json_encode($value) .
            "</br></br>";
    }
}

function readFromCache($key)
{
    // Specify the cache file path
    $cacheFilePath = 'cache.json';

    // Check if the cache file exists or create it if not
    if (!file_exists($cacheFilePath)) {
        file_put_contents($cacheFilePath, '{}');
    }

    // Read existing cache data
    $cacheData = json_decode(file_get_contents($cacheFilePath), true) ? : [];

    if (isset($cacheData[$key])) {
        $parsedData = $cacheData[$key];

        // Get the current timestamp
        $now = time();

        // Check if the data has expired
        if ($now <= $parsedData['expirationTime']) {
            // Deserialize the JSON string back to an object
            $deserializedValue = json_decode($parsedData['value'], true);

            if (DEBUG) {
                echo 'Read from Cache - Key: ' . $key . ' - Value: ' . json_encode($deserializedValue) .
                    "</br></br>";
            }

            return $deserializedValue;
        } else {
            // Data has expired, remove it from the cache
            unset($cacheData[$key]);

            // Write the updated cache data back to the file
            file_put_contents($cacheFilePath, json_encode($cacheData));
        }
    }

    // Cache miss or expired data, or the cache file doesn't exist
    return null;
}

function cleanupCacheFiles()
{
    global $cacheSize;
    // List of cache files to check
    $cacheFiles = ['html_cache.txt', 'cache.json'];

    foreach ($cacheFiles as $file) {
        // Check if file exists
        if (file_exists($file)) {
            // Get file size in bytes
            $fileSize = filesize($file);

            $maxSize = $cacheSize * 1024 * 1024;

            // If file size is greater than 30 MB, clear the file
            if ($fileSize > $maxSize) {
                if (DEBUG) {
                    echo "Cache file $file is larger than " . $cacheSize .
                        "MB. Clearing the file.<br>";
                }

                // Clear the file contents
                file_put_contents($file, '');
            }
        }
    }
}


?>