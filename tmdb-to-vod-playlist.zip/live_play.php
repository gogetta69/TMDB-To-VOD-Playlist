<?php
function getLiveStream($streamId) {

    if (!$streamId) {
        echo "Missing 'streamId' parameter";
        return;
    }
	

	$jsonFilePath = "channels/live_playlist.json";

	$jsonContent = file_get_contents($jsonFilePath);

	$data = json_decode($jsonContent, true);

	$urlParam = $data[$streamId]['direct_source'];
	
    $getHeaders = [
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0",
        "Accept: */*",
        "Accept-Language: en-US,en;q=0.5",
        //"Accept-Encoding: gzip, deflate, br",
        "X-Requested-With: XMLHttpRequest",
        "Origin: https://thetvapp.to",
        "Connection: keep-alive",
        "Referer: https://thetvapp.to"
    ];
	


		$ch = curl_init($urlParam);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $getHeaders);
		

		curl_setopt($ch, CURLOPT_HEADER, true);  // <-- This is to capture the response headers
		curl_setopt($ch, CURLOPT_ENCODING, "");
		$response = curl_exec($ch);
		$headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
		$responseHeaders = substr($response, 0, $headerSize);
		$body = substr($response, $headerSize);  // <-- This is the actual content/body of the response

		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

		if ($httpCode === 200) {
			
		// Check if the source url is on the page and redirect if it is.			
		if (preg_match('/source:\s*"([^"]+)"/', $body, $matches)) {
			$fileUrl = $matches[1];

			// 302 redirect to the found URL
			header('Location: ' . $matches[1], true, 302);
			exit;
		}	
		
		// Check if the defuscateString is on the page and redirect if it is.			
		if (preg_match('/(?<=file: window\.defuscateString)\(.*?\)(?=,)/', $body, $matches)) {
			$defuscateString = $matches[0];	
			
			if (preg_match("/(?<=\(').*?(?='\))/", $defuscateString, $matches)) {
				
				$i = 'Iyixx5fqoeKET6W8FCB1tK'; 
				$l = base64_decode($matches[0]);
				$o = '';


			for ($c = 0; $c < strlen($l); $c++) {
				$o .= chr(ord($l[$c]) ^ ord($i[$c % strlen($i)]));
			}	

			// 302 redirect to the found URL
			header('Location: ' . $o, true, 302);
			exit;
			
			}	
		}	
		
		// Check if the file url is on the page and redirect if it is.	
		if (preg_match("/file:\s*'([^']+)'/", $body, $matches)) {
			$fileUrl = $matches[1];
			
			// 302 redirect to the found URL
			header('Location: ' . $matches[1], true, 302);
			exit;
		}		
		// Check if the encryption is on the page and redirect if it is.
		if (preg_match('/(?<=<meta name="encryption" content=").*?(?=">)/', $body, $matches)) {
			
			$i = 'Try9-Stubble9'; 
			$l = base64_decode($matches[0]);
			$o = '';

			for ($c = 0; $c < strlen($l); $c++) {
				$o .= chr(ord($l[$c]) ^ ord($i[$c % strlen($i)]));
			}

            header("Location: " . $o, true, 302);
            exit();
        }
			
			// If all the others fail try the old way and send the token.
			preg_match('/<meta name="csrf-token" content="([^"]+)">/', $body, $csrfTokenMatch);
			$csrfToken = $csrfTokenMatch[1] ?? null;			
	

			preg_match('/url: "([^"]+)"/', $body, $urlMatch);
			$urlValue = $urlMatch[1] ?? null;
			
			preg_match_all('/set-cookie: (.*?);/i', $responseHeaders, $cookieMatches);

			$allCookies = $cookieMatches[1];
			$cookieString = implode('; ', $allCookies);
			
			

        $postUrl = "https://thetvapp.to" . $urlValue;
		
        $postHeaders = [
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0",
            "Accept: */*",
            "Accept-Language: en-US,en;q=0.5",
            //"Accept-Encoding: gzip, deflate, br",
            "X-CSRF-TOKEN: " . $csrfToken,
            "X-Requested-With: XMLHttpRequest",
            "Origin: https://thetvapp.to",
            "Connection: keep-alive",
            //"Referer: " . $postUrl,
            "Cookie: " . $cookieString,
            "Sec-Fetch-Dest: empty",
            "Sec-Fetch-Mode: cors",
            "Sec-Fetch-Site: same-origin",
			"Pragma: no-cache",
			"TE: trailers"
        ];

        $ch = curl_init($postUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $postHeaders);
        curl_setopt($ch, CURLOPT_POST, true);

        $postResponse = curl_exec($ch);
		
		

        if (preg_match('/https:\/\/.*?expires=[0-9]*/', $postResponse, $dynamicUrlMatch)) {
            // Perform a 301 redirect to the extracted URL
            header("Location: " . $dynamicUrlMatch[0], true, 302);
            exit();
        } else {
            echo "Error: Unable to extract dynamic URL. POST Response: " . $postResponse;
            return;
        }
    } else {
        echo "Error: Unable to fetch the URL. Response code: " . $httpCode;
        return;
    }
}

echo getLiveStream($_GET['streamId']);
?>
